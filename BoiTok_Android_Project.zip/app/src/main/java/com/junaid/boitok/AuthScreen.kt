package com.junaid.boitok

import android.widget.Toast
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun toast(ctx: android.content.Context, m: String) =
    Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

// ------------------------------------------------------------ brand icons (Google / Facebook / Apple)
private fun brand(name: String, parts: List<Pair<String, Color>>): ImageVector {
    val b = ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
    parts.forEach { (d, c) -> b.addPath(pathData = PathParser().parsePathString(d).toNodes(), fill = SolidColor(c)) }
    return b.build()
}

private val GoogleG = brand("google", listOf(
    "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1z" to Color(0xFF4285F4),
    "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" to Color(0xFF34A853),
    "M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.07H2.18A10.99 10.99 0 0 0 1 12c0 1.78.43 3.45 1.18 4.93l3.66-2.84z" to Color(0xFFFBBC05),
    "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" to Color(0xFFEA4335)
))
private val FacebookF = brand("facebook", listOf(
    "M12 0a12 12 0 1 0 0 24a12 12 0 1 0 0-24z" to Color(0xFF1877F2),
    "M13.5 21v-7.5h2.5l.4-3h-2.9V8.6c0-.87.25-1.46 1.5-1.46h1.5V4.46A20 20 0 0 0 14.4 4.3c-2.2 0-3.7 1.34-3.7 3.8v2.4H8.2v3h2.5V21z" to Color.White
))
private val AppleLogo = brand("apple", listOf(
    "M16.37 12.6c-.02-2.1 1.72-3.1 1.8-3.15-1-1.43-2.5-1.63-3.05-1.65-1.3-.13-2.54.77-3.2.77-.66 0-1.67-.75-2.75-.73-1.4.02-2.7.82-3.43 2.08-1.47 2.54-.38 6.3 1.05 8.36.7 1 1.53 2.14 2.62 2.1 1.05-.04 1.45-.68 2.72-.68s1.63.68 2.74.66c1.13-.02 1.85-1.03 2.54-2.04.8-1.17 1.13-2.3 1.15-2.36-.03-.01-2.2-.84-2.23-3.36zM14.3 6.4c.58-.7.97-1.68.86-2.65-.83.03-1.84.55-2.43 1.25-.53.62-1 1.62-.87 2.57.93.07 1.87-.47 2.44-1.17z" to Color(0xFF111111)
))

// ------------------------------------------------------------ pieces
@Composable
private fun AuthField(
    label: String,
    icon: ImageVector,
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Text,
    error: String? = null
) {
    var focused by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    Column(modifier) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF2A303C))
        Spacer(Modifier.height(7.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(50.dp)
                .drawBehind {
                    if (focused) drawRoundRect(
                        Blue.copy(alpha = 0.12f),
                        topLeft = Offset(-4.dp.toPx(), -4.dp.toPx()),
                        size = Size(size.width + 8.dp.toPx(), size.height + 8.dp.toPx()),
                        cornerRadius = CornerRadius(20.dp.toPx())
                    )
                }
                .clip(shape)
                .background(if (focused) Color.White else FieldBg)
                .border(
                    1.4.dp,
                    if (error != null) Red else if (focused) Blue else FieldBorder,
                    shape
                )
                .padding(horizontal = 15.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = if (focused) Blue else Color(0xFF8A93A3), modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(11.dp))
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) Text(placeholder, fontSize = 14.5.sp, color = Color(0xFF9AA3B2))
                    BasicTextField(
                        value = value,
                        onValueChange = onChange,
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 14.5.sp, color = Ink, fontWeight = FontWeight.Normal),
                        cursorBrush = SolidColor(Blue),
                        visualTransformation = if (password && !show) PasswordVisualTransformation() else VisualTransformation.None,
                        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
                        modifier = Modifier
                            .fillMaxWidth()
                            .onFocusChanged { focused = it.isFocused }
                    )
                }
                if (password) {
                    Icon(
                        if (show) IEye else IEyeOff, null,
                        tint = Color(0xFF8A93A3),
                        modifier = Modifier
                            .size(20.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { show = !show }
                    )
                }
            }
        }
        if (error != null) {
            Spacer(Modifier.height(5.dp))
            Text(error, fontSize = 11.5.sp, color = Red, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun CheckBox(checked: Boolean, onToggle: () -> Unit) {
    Box(
        Modifier
            .size(18.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (checked) Blue else Color.White)
            .border(1.4.dp, if (checked) Blue else Color(0xFFC6D2E4), RoundedCornerShape(6.dp))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onToggle() },
        contentAlignment = Alignment.Center
    ) {
        if (checked) Icon(ICheck, null, tint = Color.White, modifier = Modifier.size(12.dp))
    }
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(17.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .shadow(10.dp, shape, ambientColor = Blue, spotColor = Blue)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(BlueLight, BlueDark)))
            .clickable { onClick() },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Color.White, fontSize = 15.5.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Icon(IArrow, null, tint = Color.White, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun DividerLabel(text: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).height(1.dp).background(Color(0xFFEDF1F7)))
        Text(text, fontSize = 11.5.sp, color = Color(0xFFA2ABBA), modifier = Modifier.padding(horizontal = 12.dp))
        Box(Modifier.weight(1f).height(1.dp).background(Color(0xFFEDF1F7)))
    }
}

@Composable
private fun SocialButton(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(15.dp)
    Row(
        modifier
            .height(50.dp)
            .shadow(2.dp, shape, ambientColor = Color(0x1A28508F), spotColor = Color(0x1A28508F))
            .clip(shape)
            .background(Color.White)
            .border(1.4.dp, FieldBorder, shape)
            .clickable { onClick() },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(icon, null, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1D2330))
    }
}

@Composable
private fun StrengthBar(score: Int) {
    val col = when (score) { 1 -> Red; 2 -> Amber; else -> Green }
    val label = when (score) { 1 -> "Weak"; 2 -> "Fair"; 3 -> "Strong"; else -> "Very strong" }
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        for (i in 1..4) {
            Box(
                Modifier
                    .weight(1f)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (score >= i) col else FieldBorder)
            )
            if (i < 4) Spacer(Modifier.width(5.dp))
        }
        Text(
            if (score == 0) "" else label,
            fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = col,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

// ------------------------------------------------------------ screen
@Composable
fun AuthScreen(store: AuthStore, onAuthed: (User, Boolean) -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) } // 0 sign in, 1 sign up

    var siEmail by remember { mutableStateOf("") }
    var siPass by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(true) }
    var siEmailErr by remember { mutableStateOf<String?>(null) }
    var siPassErr by remember { mutableStateOf<String?>(null) }

    var suName by remember { mutableStateOf("") }
    var suEmail by remember { mutableStateOf("") }
    var suPass by remember { mutableStateOf("") }
    var agree by remember { mutableStateOf(false) }
    var suNameErr by remember { mutableStateOf<String?>(null) }
    var suEmailErr by remember { mutableStateOf<String?>(null) }
    var suPassErr by remember { mutableStateOf<String?>(null) }
    var suAgreeErr by remember { mutableStateOf(false) }

    var forgot by remember { mutableStateOf(false) }

    val headerH by animateDpAsState(if (tab == 0) 190.dp else 140.dp, label = "hdr")
    val soon = { n: String -> toast(ctx, "$n দিয়ে লগইন শীঘ্রই আসছে") }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFD6E7FF), Color(0xFFEAF2FF), Color(0xFFF6F9FF))))
    ) {
        // soft glow blobs
        Box(
            Modifier.offset((-90).dp, (-80).dp).size(320.dp)
                .background(Brush.radialGradient(listOf(Color(0xBFFFFFFF), Color(0x00FFFFFF))), CircleShape)
        )
        Box(
            Modifier.align(Alignment.TopEnd).offset(100.dp, (-20).dp).size(280.dp)
                .background(Brush.radialGradient(listOf(Color(0x471F78F4), Color(0x001F78F4))), CircleShape)
        )
        // decorative covers
        Image(
            painterResource(R.drawable.cov_rose), null,
            modifier = Modifier.offset((-20).dp, headerH - 96.dp).size(80.dp, 100.dp).rotate(-14f)
        )
        Image(
            painterResource(R.drawable.cov_path), null,
            modifier = Modifier.align(Alignment.TopEnd).offset(20.dp, headerH - 96.dp).size(80.dp, 100.dp).rotate(14f)
        )

        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            // logo
            Column(
                Modifier.fillMaxWidth().height(headerH - 20.dp).padding(top = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(painterResource(R.drawable.logo_t), null, modifier = Modifier.size(54.dp, 58.dp), contentScale = ContentScale.Fit)
                Text(
                    buildAnnotatedString {
                        append("Boi")
                        withStyle(SpanStyle(color = Blue)) { append("Tok") }
                    },
                    fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink
                )
            }
            // sheet
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .shadow(16.dp, RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp), ambientColor = Color(0x331E46A0), spotColor = Color(0x331E46A0))
                    .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                    .background(Color.White)
                    .verticalScroll(rememberScrollState())
                    .navigationBarsPadding()
                    .padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 20.dp)
            ) {
                // tabs
                Row(
                    Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFEEF3FB)).padding(4.dp)
                ) {
                    listOf("Sign In", "Sign Up").forEachIndexed { i, t ->
                        val on = tab == i
                        val s = RoundedCornerShape(11.dp)
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .then(if (on) Modifier.shadow(2.dp, s) else Modifier)
                                .clip(s)
                                .background(if (on) Color.White else Color.Transparent)
                                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { tab = i },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(t, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (on) Color(0xFF0F5FE0) else Color(0xFF7B8597))
                        }
                    }
                }

                if (tab == 0) {
                    Spacer(Modifier.height(24.dp))
                    Text("Welcome back", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("আপনার অ্যাকাউন্টে সাইন ইন করুন", fontSize = 13.sp, color = Color(0xFF6B7482), modifier = Modifier.padding(top = 4.dp))
                    AuthField("Email address", IMail, siEmail, { siEmail = it; siEmailErr = null }, "reader@example.com",
                        Modifier.padding(top = 20.dp), keyboard = KeyboardType.Email, error = siEmailErr)
                    AuthField("Password", ILock, siPass, { siPass = it; siPassErr = null }, "Enter your password",
                        Modifier.padding(top = 18.dp), password = true, error = siPassErr)
                    Row(
                        Modifier.fillMaxWidth().padding(top = 18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { rememberMe = !rememberMe }
                        ) {
                            CheckBox(rememberMe) { rememberMe = !rememberMe }
                            Text("Remember me", fontSize = 12.5.sp, fontWeight = FontWeight.Medium, color = Color(0xFF4A5262), modifier = Modifier.padding(start = 8.dp))
                        }
                        Text("Forgot password?", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Blue,
                            modifier = Modifier.clickable { forgot = true })
                    }
                    Spacer(Modifier.height(22.dp))
                    PrimaryButton("Sign In") {
                        var ok = true
                        if (!isValidEmail(siEmail)) { siEmailErr = "সঠিক ইমেইল ঠিকানা দিন"; ok = false }
                        if (siPass.isEmpty()) { siPassErr = "পাসওয়ার্ড দিন"; ok = false }
                        if (ok) {
                            val u = store.login(siEmail, siPass)
                            if (u == null) {
                                siPassErr = if (store.exists(siEmail)) "পাসওয়ার্ড ভুল হয়েছে" else "এই ইমেইলে কোনো অ্যাকাউন্ট নেই — Sign Up করুন"
                            } else onAuthed(u, rememberMe)
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    DividerLabel("or continue with")
                    Spacer(Modifier.height(20.dp))
                } else {
                    Spacer(Modifier.height(22.dp))
                    Text("Create account", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("বইটক-এ যোগ দিন, মাত্র এক মিনিটেই", fontSize = 13.sp, color = Color(0xFF6B7482), modifier = Modifier.padding(top = 4.dp))
                    AuthField("Full name", IUser, suName, { suName = it; suNameErr = null }, "Your full name",
                        Modifier.padding(top = 18.dp), error = suNameErr)
                    AuthField("Email address", IMail, suEmail, { suEmail = it; suEmailErr = null }, "reader@example.com",
                        Modifier.padding(top = 14.dp), keyboard = KeyboardType.Email, error = suEmailErr)
                    Column(Modifier.padding(top = 14.dp)) {
                        AuthField("Password", ILock, suPass, { suPass = it; suPassErr = null }, "Minimum 8 characters",
                            password = true, error = suPassErr)
                        StrengthBar(passwordScore(suPass))
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.Top) {
                        Box(Modifier.padding(top = 1.dp)) { CheckBox(agree) { agree = !agree; suAgreeErr = false } }
                        Text(
                            buildAnnotatedString {
                                append("I agree to the ")
                                withStyle(SpanStyle(color = Blue, fontWeight = FontWeight.SemiBold)) { append("Terms of Service") }
                                append(" and ")
                                withStyle(SpanStyle(color = Blue, fontWeight = FontWeight.SemiBold)) { append("Privacy Policy") }
                            },
                            fontSize = 12.sp, lineHeight = 17.sp,
                            color = if (suAgreeErr) Red else Color(0xFF5A6373),
                            modifier = Modifier.padding(start = 9.dp)
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton("Create Account") {
                        var ok = true
                        if (suName.trim().length < 2) { suNameErr = "আপনার নাম লিখুন"; ok = false }
                        if (!isValidEmail(suEmail)) { suEmailErr = "সঠিক ইমেইল ঠিকানা দিন"; ok = false }
                        else if (store.exists(suEmail)) { suEmailErr = "এই ইমেইলে আগেই অ্যাকাউন্ট আছে — Sign In করুন"; ok = false }
                        if (suPass.length < 8) { suPassErr = "পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে"; ok = false }
                        if (!agree) { suAgreeErr = true; ok = false }
                        if (ok) onAuthed(store.register(suName, suEmail, suPass), true)
                    }
                    Spacer(Modifier.height(18.dp))
                    DividerLabel("or sign up with")
                    Spacer(Modifier.height(14.dp))
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SocialButton("Google", GoogleG, Modifier.weight(1f)) { soon("Google") }
                    SocialButton("Facebook", FacebookF, Modifier.weight(1f)) { soon("Facebook") }
                    SocialButton("Apple", AppleLogo, Modifier.weight(1f)) { soon("Apple") }
                }
                Spacer(Modifier.height(if (tab == 0) 30.dp else 20.dp))
                Text(
                    buildAnnotatedString {
                        append(if (tab == 0) "Don’t have an account? " else "Already have an account? ")
                        withStyle(SpanStyle(color = Blue, fontWeight = FontWeight.Bold)) { append(if (tab == 0) "Sign Up" else "Sign In") }
                    },
                    fontSize = 13.sp, color = Color(0xFF6B7482), textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().clickable { tab = 1 - tab }
                )
            }
        }
    }

    if (forgot) {
        AlertDialog(
            onDismissRequest = { forgot = false },
            confirmButton = { TextButton(onClick = { forgot = false }) { Text("ঠিক আছে") } },
            title = { Text("পাসওয়ার্ড রিসেট") },
            text = { Text("ইমেইলে রিসেট লিংক পাঠানোর সুবিধা সার্ভার সংযুক্ত হলে চালু হবে। এখন অ্যাকাউন্টগুলো শুধু এই ফোনেই সংরক্ষিত।") }
        )
    }
}
