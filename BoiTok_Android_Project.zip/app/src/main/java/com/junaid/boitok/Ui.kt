package com.junaid.boitok

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

val Blue = Color(0xFF1F78F4)
val BlueDark = Color(0xFF0B63E0)
val BlueLight = Color(0xFF2E8BFA)
val Ink = Color(0xFF14171F)
val Grey = Color(0xFF7C8594)
val FieldBg = Color(0xFFF3F7FD)
val FieldBorder = Color(0xFFE1E9F5)
val Green = Color(0xFF13A152)
val Red = Color(0xFFE5484D)
val Amber = Color(0xFFFFB21E)

val OutfitFamily = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_medium, FontWeight.Medium),
    Font(R.font.outfit_semibold, FontWeight.SemiBold),
    Font(R.font.outfit_bold, FontWeight.Bold),
    Font(R.font.outfit_bold, FontWeight.ExtraBold)
)

private fun vec(name: String, d: String, width: Float = 1.8f, fill: Boolean = false): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).addPath(
        pathData = PathParser().parsePathString(d).toNodes(),
        fill = if (fill) SolidColor(Color.Black) else null,
        stroke = SolidColor(Color.Black),
        strokeLineWidth = width,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round
    ).build()

private fun circ(cx: Float, cy: Float, r: Float) =
    "M${cx - r} ${cy}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"

val IMail = vec("mail", "M6 5h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3zM3.5 7.5l8.5 6 8.5-6")
val ILock = vec("lock", "M7.5 10.5h9a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3h-9a3 3 0 0 1-3-3v-4a3 3 0 0 1 3-3zM8 10.5V8a4 4 0 0 1 8 0v2.5")
val IEye = vec("eye", "M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z" + circ(12f, 12f, 3f))
val IEyeOff = vec("eyeoff", "M3 3l18 18M10.6 5.6A9.8 9.8 0 0 1 12 5.5c6.4 0 10 6.5 10 6.5a17 17 0 0 1-3.2 3.8M6.4 6.9C3.7 8.7 2 12 2 12s3.6 6.5 10 6.5c1.6 0 3-.4 4.3-1M9.9 9.9a3 3 0 0 0 4.2 4.2")
val IUser = vec("user", circ(12f, 8f, 4f) + "M4.5 20.5c.6-4 3.5-6 7.5-6s6.9 2 7.5 6")
val ICheck = vec("check", "M5 12.5l4.5 4.5L19 7.5", 3.2f)
val IArrow = vec("arrow", "M5 12h14M13 6l6 6-6 6", 2.3f)
val IHome = vec("home", "M4 11l8-7 8 7v8.5a1.5 1.5 0 0 1-1.5 1.5H15v-6H9v6H5.5A1.5 1.5 0 0 1 4 19.5z", 1.9f)
val IUsers = vec("users", circ(9f, 8f, 3.8f) + "M2.5 20v-1.2a4.5 4.5 0 0 1 4.5-4.5h4a4.5 4.5 0 0 1 4.5 4.5V20M16 4.4a3.8 3.8 0 0 1 0 7.2M21.5 20v-1.2a4.5 4.5 0 0 0-3-4.2", 1.9f)
val IWallet = vec("wallet", "M4 7.5A2.5 2.5 0 0 1 6.5 5H18v3M4 7.5V18a2 2 0 0 0 2 2h13a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1H6.5A2.5 2.5 0 0 1 4 7.5zM16 14h2", 1.9f)
val ILibrary = vec("library", "M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5zM5 19.5A1.5 1.5 0 0 0 6.5 21H19v-3", 1.9f)
val ILogout = vec("logout", "M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3M16 8l4 4-4 4M20 12H9", 1.9f)
