package com.junaid.boitok

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.ProvideTextStyle

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // The design is drawn on a 390dp-wide canvas and scaled to the real screen width
            val d = LocalDensity.current
            val w = LocalConfiguration.current.screenWidthDp
            val scale = w / 390f
            CompositionLocalProvider(LocalDensity provides Density(d.density * scale, 1f)) {
                ProvideTextStyle(TextStyle(fontFamily = OutfitFamily)) { BoiTokApp() }
            }
        }
    }
}

@Composable
fun BoiTokApp() {
    val ctx = LocalContext.current
    val store = remember { AuthStore(ctx) }
    var user by remember { mutableStateOf(store.currentUser()) }

    val u = user
    if (u == null) {
        AuthScreen(store) { logged, keep ->
            store.saveSession(if (keep) logged else null)
            user = logged
        }
    } else {
        HomeShell(u) {
            store.saveSession(null)
            user = null
        }
    }
}

private data class NavItem(val label: String, val icon: ImageVector)

@Composable
private fun HomeShell(user: User, onLogout: () -> Unit) {
    val items = listOf(
        NavItem("Home", IHome), NavItem("Social", IUsers), NavItem("Economy", IWallet),
        NavItem("Library", ILibrary), NavItem("Profile", IUser)
    )
    var sel by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().background(Color(0xFFF6F9FF))) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFFD6E7FF), Color(0xFFEAF2FF))))
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(painterResource(R.drawable.logo_t), null, modifier = Modifier.size(34.dp, 36.dp))
            Column(Modifier.padding(start = 10.dp)) {
                Text("স্বাগতম, ${user.name}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                Text(user.email, fontSize = 11.5.sp, color = Grey)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (sel == 4) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(user.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text(user.email, fontSize = 13.sp, color = Grey, modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.height(24.dp))
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .clickable { onLogout() }
                            .padding(horizontal = 22.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(ILogout, null, tint = Color(0xFFE5484D), modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Sign out", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE5484D))
                    }
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(items[sel].icon, null, tint = Blue, modifier = Modifier.size(44.dp))
                    Text(items[sel].label, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(top = 10.dp))
                    Text("এই পেজ শীঘ্রই আসছে", fontSize = 13.sp, color = Grey, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Color.White).navigationBarsPadding().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            items.forEachIndexed { i, item ->
                val on = sel == i
                Column(
                    Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { sel = i }.padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(item.icon, null, tint = if (on) Blue else Color(0xFF8A93A3), modifier = Modifier.size(24.dp))
                    Text(item.label, fontSize = 11.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, color = if (on) Blue else Color(0xFF8A93A3))
                }
            }
        }
    }
}
