package com.junaid.social

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Base64
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

/** What the signed-in user has done (kept in users/{uid}). */
data class MeState(
    val liked: Set<String> = emptySet(),
    val bookmarks: Set<String> = emptySet(),
    val following: Set<String> = emptySet(),
    val hidden: Set<String> = emptySet(),
    val votes: Map<String, Int> = emptyMap(),
    val verified: Boolean = false
)

/** A post exactly as stored in posts/{id}. */
class PostDoc(
    val id: String,
    val authorUid: String,
    val author: String,
    val photo: String?,
    val createdAt: Long,
    val text: String,
    val imageB64: String?,
    val imageUrl: String?,
    val pollOptions: List<String>?,
    val votes: Map<Int, Int>,
    val pollEnds: Long,
    val verified: Boolean,
    val likes: Int,
    val commentCount: Int,
    val shares: Int
)

private const val DAY = 24L * 60 * 60 * 1000

private fun DocumentSnapshot.toPostDoc(): PostDoc? {
    val uid = getString("authorUid") ?: return null
    val ts = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        ?.toDate()?.time ?: System.currentTimeMillis()
    val opts = (get("pollOptions") as? List<*>)?.mapNotNull { it as? String }?.takeIf { it.size >= 2 }
    val votes = HashMap<Int, Int>()
    (get("votes") as? Map<*, *>)?.forEach { (k, v) ->
        val i = (k as? String)?.toIntOrNull()
        val n = (v as? Number)?.toInt()
        if (i != null && n != null) votes[i] = n
    }
    return PostDoc(
        id = id,
        authorUid = uid,
        author = getString("authorName") ?: "User",
        photo = getString("authorPhoto")?.takeIf { it.isNotBlank() },
        createdAt = ts,
        text = getString("text") ?: "",
        imageB64 = getString("imageB64")?.takeIf { it.isNotBlank() },
        imageUrl = getString("imageUrl")?.takeIf { it.isNotBlank() },
        pollOptions = opts,
        votes = votes,
        pollEnds = getLong("pollEnds") ?: 0L,
        verified = getBoolean("verified") == true,
        likes = (getLong("likes") ?: 0L).toInt().coerceAtLeast(0),
        commentCount = (getLong("commentCount") ?: 0L).toInt().coerceAtLeast(0),
        shares = (getLong("shares") ?: 0L).toInt().coerceAtLeast(0)
    )
}

private fun parseMe(s: DocumentSnapshot?): MeState {
    fun set(k: String): Set<String> =
        (s?.get(k) as? List<*>)?.mapNotNull { it as? String }?.toSet() ?: emptySet()
    val votes = HashMap<String, Int>()
    (s?.get("votes") as? Map<*, *>)?.forEach { (k, v) ->
        val key = k as? String
        val n = (v as? String)?.toIntOrNull()
        if (key != null && n != null) votes[key] = n
    }
    return MeState(set("liked"), set("bookmarks"), set("following"), set("hidden"), votes, s?.getBoolean("verified") == true)
}

object Repo {
    private val db get() = FirebaseFirestore.getInstance()
    private fun userRef(uid: String) = db.collection("users").document(uid)
    private fun postRef(id: String) = db.collection("posts").document(id)

    /** Creates users/{uid} the first time this person signs in. */
    fun ensureUser(u: User) {
        val ref = userRef(u.uid)
        ref.get().addOnSuccessListener { s ->
            if (!s.exists()) {
                ref.set(
                    hashMapOf<String, Any>(
                        "name" to u.name,
                        "email" to u.email,
                        "photo" to (u.photo ?: ""),
                        "liked" to emptyList<String>(),
                        "bookmarks" to emptyList<String>(),
                        "following" to emptyList<String>(),
                        "hidden" to emptyList<String>(),
                        "votes" to emptyMap<String, String>(),
                        "verified" to false
                    )
                )
            }
        }
    }

    fun listenPosts(onData: (List<PostDoc>) -> Unit, onErr: (String) -> Unit): ListenerRegistration =
        db.collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { s, e ->
                if (e != null) {
                    onErr(e.message ?: "error")
                } else if (s != null) {
                    onData(s.documents.mapNotNull { it.toPostDoc() })
                }
            }

    fun listenMe(uid: String, onData: (MeState) -> Unit): ListenerRegistration =
        userRef(uid).addSnapshotListener { s, _ -> onData(parseMe(s)) }

    fun listenComments(postId: String, onData: (List<Comment>) -> Unit): ListenerRegistration =
        postRef(postId).collection("comments").orderBy("createdAt")
            .addSnapshotListener { s, _ ->
                if (s != null) {
                    onData(s.documents.map {
                        Comment(it.id, it.getString("authorUid") ?: "", it.getString("author") ?: "User", it.getString("text") ?: "")
                    })
                }
            }

    fun buildPosts(docs: List<PostDoc>, me: MeState, uid: String): List<Post> {
        val now = System.currentTimeMillis()
        return docs.map { d ->
            val poll = d.pollOptions?.let { opts ->
                val sel = me.votes[d.id] ?: -1
                val left = ((d.pollEnds - now + DAY - 1) / DAY).toInt()
                Poll(
                    options = opts.mapIndexed { i, t -> PollOption(t, d.votes[i] ?: 0) },
                    selected = if (sel in opts.indices) sel else -1,
                    daysLeft = left.coerceAtLeast(0),
                    ended = d.pollEnds in 1..now
                )
            }
            Post(
                id = d.id,
                authorUid = d.authorUid,
                author = d.author,
                authorPhoto = d.photo,
                createdAt = d.createdAt,
                text = d.text,
                imageB64 = d.imageB64,
                imageUrl = d.imageUrl,
                poll = poll,
                verified = d.verified,
                mine = d.authorUid == uid,
                following = d.authorUid in me.following,
                liked = d.id in me.liked,
                likes = d.likes,
                commentCount = d.commentCount,
                shares = d.shares,
                bookmarked = d.id in me.bookmarks
            )
        }
    }

    // ------------------------------------------------------------ writes

    fun createPost(
        u: User, verified: Boolean, text: String, imageB64: String?, pollOptions: List<String>,
        onOk: () -> Unit, onErr: (String) -> Unit
    ) {
        val data = hashMapOf<String, Any>(
            "authorUid" to u.uid,
            "authorName" to u.name,
            "authorPhoto" to (u.photo ?: ""),
            "text" to text,
            "createdAt" to FieldValue.serverTimestamp(),
            "verified" to verified,
            "likes" to 0,
            "commentCount" to 0,
            "shares" to 0
        )
        if (imageB64 != null) data["imageB64"] = imageB64
        if (pollOptions.size >= 2) {
            data["pollOptions"] = pollOptions
            data["votes"] = pollOptions.indices.associate { it.toString() to 0 }
            data["pollEnds"] = System.currentTimeMillis() + 3 * DAY
        }
        db.collection("posts").add(data)
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "") }
    }

    fun toggleLike(uid: String, postId: String, liked: Boolean, onErr: (String) -> Unit) {
        val b = db.batch()
        b.update(userRef(uid), "liked", if (liked) FieldValue.arrayRemove(postId) else FieldValue.arrayUnion(postId))
        b.update(postRef(postId), "likes", FieldValue.increment(if (liked) -1L else 1L))
        b.commit().addOnFailureListener { onErr(it.message ?: "") }
    }

    fun vote(uid: String, postId: String, option: Int, onErr: (String) -> Unit) {
        val b = db.batch()
        b.update(userRef(uid), "votes.$postId", option.toString())
        b.update(postRef(postId), "votes.$option", FieldValue.increment(1L))
        b.commit().addOnFailureListener { onErr(it.message ?: "") }
    }

    fun toggleBookmark(uid: String, postId: String, on: Boolean) {
        userRef(uid).update("bookmarks", if (on) FieldValue.arrayRemove(postId) else FieldValue.arrayUnion(postId))
    }

    fun toggleFollow(uid: String, authorUid: String, following: Boolean) {
        userRef(uid).update("following", if (following) FieldValue.arrayRemove(authorUid) else FieldValue.arrayUnion(authorUid))
    }

    fun hide(uid: String, postId: String) {
        userRef(uid).update("hidden", FieldValue.arrayUnion(postId))
    }

    fun share(postId: String) {
        postRef(postId).update("shares", FieldValue.increment(1L))
    }

    fun delete(postId: String, onErr: (String) -> Unit) {
        postRef(postId).delete().addOnFailureListener { onErr(it.message ?: "") }
    }

    fun addComment(u: User, postId: String, text: String, onErr: (String) -> Unit) {
        val b = db.batch()
        val c = postRef(postId).collection("comments").document()
        b.set(
            c, hashMapOf<String, Any>(
                "authorUid" to u.uid,
                "author" to u.name,
                "text" to text,
                "createdAt" to FieldValue.serverTimestamp()
            )
        )
        b.update(postRef(postId), "commentCount", FieldValue.increment(1L))
        b.commit().addOnFailureListener { onErr(it.message ?: "") }
    }
}

/**
 * Shrinks a picked image and returns it as base64 JPEG (kept under ~600 KB so it fits in a Firestore
 * document). Used until a separate image host (e.g. Cloudinary) is connected.
 */
fun compressImage(ctx: Context, uri: Uri): String? {
    var bmp = loadBitmap(ctx, uri, 1280) ?: return null
    val longest = maxOf(bmp.width, bmp.height)
    if (longest > 1080) {
        val s = 1080f / longest
        bmp = Bitmap.createScaledBitmap(
            bmp, (bmp.width * s).toInt().coerceAtLeast(1), (bmp.height * s).toInt().coerceAtLeast(1), true
        )
    }
    var cur = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(cur)
    canvas.drawColor(android.graphics.Color.WHITE)
    canvas.drawBitmap(bmp, 0f, 0f, null)
    var q = 80
    var out = ByteArray(0)
    while (true) {
        val bos = java.io.ByteArrayOutputStream()
        cur.compress(Bitmap.CompressFormat.JPEG, q, bos)
        out = bos.toByteArray()
        if (out.size <= 600_000) break
        if (q > 45) {
            q -= 10
        } else {
            if (cur.width < 300) break
            cur = Bitmap.createScaledBitmap(cur, (cur.width * 0.8f).toInt(), (cur.height * 0.8f).toInt(), true)
        }
    }
    return Base64.encodeToString(out, Base64.NO_WRAP)
}
