package com.junaid.social

import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation

/** Cuts [t] to at most [max] characters, without ever splitting an emoji (surrogate pair) in half. */
fun cutToLimit(t: String, max: Int): String {
    if (t.length <= max) return t
    var end = max
    if (end > 0 && Character.isHighSurrogate(t[end - 1])) end--
    return t.substring(0, end)
}

/**
 * A text field that is safe for pasting and for being cleared from the outside.
 *
 * It keeps the cursor/selection/IME state itself (TextFieldValue) and only reports the plain text upwards, so
 * - pasting many times in a row always works (nothing is thrown away between two pastes),
 * - a paste that is longer than [maxChars] is cut to fit instead of being dropped,
 * - when the owner changes [value] from the outside (message sent, text cleared, edit loaded) the field follows at once.
 */
@Composable
fun PasteSafeField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: TextStyle = TextStyle.Default,
    cursorBrush: Brush = SolidColor(Color.Black),
    singleLine: Boolean = false,
    maxChars: Int = Int.MAX_VALUE,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None
) {
    var tfv by remember { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    // the owner's text always wins; our own TextFieldValue is only used while it still says the same text
    val shown = if (tfv.text == value) tfv else TextFieldValue(value, TextRange(value.length))
    BasicTextField(
        value = shown,
        onValueChange = { nv ->
            val cut = cutToLimit(nv.text, maxChars)
            val fixed = if (cut == nv.text) nv else TextFieldValue(cut, TextRange(minOf(nv.selection.end, cut.length)))
            tfv = fixed
            onValueChange(fixed.text)
        },
        modifier = modifier,
        textStyle = textStyle,
        cursorBrush = cursorBrush,
        singleLine = singleLine,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        visualTransformation = visualTransformation
    )
}
