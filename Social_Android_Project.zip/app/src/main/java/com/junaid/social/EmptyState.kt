package com.junaid.social

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Four-pointed twinkle star. */
private fun DrawScope.sparkle(c: Offset, r: Float, color: Color) {
    val p = Path().apply {
        moveTo(c.x, c.y - r)
        quadraticBezierTo(c.x, c.y, c.x + r, c.y)
        quadraticBezierTo(c.x, c.y, c.x, c.y + r)
        quadraticBezierTo(c.x, c.y, c.x - r, c.y)
        quadraticBezierTo(c.x, c.y, c.x, c.y - r)
        close()
    }
    drawPath(p, color)
}

/**
 * Shown when the feed has no posts: two post cards floating gently, a magnifying glass and a few twinkles,
 * all drawn in code (no image files) in the app's blue.
 */
@Composable
fun EmptyFeedState(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "emptyFeed")
    val bob by infinite.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val twinkle by infinite.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Reverse),
        label = "twinkle"
    )

    Column(
        modifier
            .fillMaxWidth()
            .padding(start = 32.dp, end = 32.dp, top = 14.dp, bottom = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(Modifier.size(width = 230.dp, height = 178.dp)) {
            val u = size.width / 230f
            fun o(x: Float, y: Float) = Offset(x * u, y * u)
            fun sz(w: Float, h: Float) = Size(w * u, h * u)
            val dy = bob * 4f          // cards float up and down (design units)
            val dy2 = -bob * 3f        // the magnifier moves the other way

            // soft round backdrop
            drawCircle(Color(0xFFE6F0FE), radius = 82f * u, center = o(115f, 92f))
            drawCircle(Color(0xFFD6E7FD), radius = 58f * u, center = o(115f, 92f))

            // shadow on the ground, shrinks as the cards rise
            drawOval(Color(0x1A1F78F4), topLeft = o(72f + bob * 2f, 158f), size = sz(76f - bob * 4f, 9f))

            val pivot = o(110f, 92f + dy)

            // back card
            rotate(-9f, pivot) {
                drawRoundRect(
                    Color(0xFFB7D3F8),
                    topLeft = o(58f, 34f + dy),
                    size = sz(108f, 112f),
                    cornerRadius = CornerRadius(16f * u)
                )
            }

            // front card
            rotate(5f, pivot) {
                drawRoundRect(
                    Color(0x221F78F4),
                    topLeft = o(60f, 40f + dy),
                    size = sz(108f, 112f),
                    cornerRadius = CornerRadius(16f * u)
                )
                drawRoundRect(
                    Color.White,
                    topLeft = o(58f, 34f + dy),
                    size = sz(108f, 112f),
                    cornerRadius = CornerRadius(16f * u)
                )
                drawRoundRect(
                    Color(0xFFCFE1F8),
                    topLeft = o(58f, 34f + dy),
                    size = sz(108f, 112f),
                    cornerRadius = CornerRadius(16f * u),
                    style = Stroke(1.4f * u)
                )
                // header: avatar + name + time
                drawCircle(Color(0xFF1F78F4), radius = 7.5f * u, center = o(76f, 53f + dy))
                drawRoundRect(Color(0xFFD9E4F4), topLeft = o(89f, 46f + dy), size = sz(42f, 5.5f), cornerRadius = CornerRadius(2.75f * u))
                drawRoundRect(Color(0xFFE8EFF9), topLeft = o(89f, 56f + dy), size = sz(28f, 4.5f), cornerRadius = CornerRadius(2.25f * u))
                // text lines
                drawRoundRect(Color(0xFFDCE6F5), topLeft = o(70f, 72f + dy), size = sz(84f, 5f), cornerRadius = CornerRadius(2.5f * u))
                drawRoundRect(Color(0xFFE8EFF9), topLeft = o(70f, 82f + dy), size = sz(60f, 5f), cornerRadius = CornerRadius(2.5f * u))
                // picture
                drawRoundRect(
                    Brush.verticalGradient(
                        listOf(Color(0xFFCFE3FD), Color(0xFF9CC4FA)),
                        startY = (94f + dy) * u,
                        endY = (130f + dy) * u
                    ),
                    topLeft = o(70f, 94f + dy),
                    size = sz(84f, 36f),
                    cornerRadius = CornerRadius(8f * u)
                )
                drawCircle(Color(0xFFFFC517), radius = 5f * u, center = o(140f, 104f + dy))
                val hills = Path().apply {
                    val p0 = o(76f, 127f + dy)
                    val p1 = o(92f, 108f + dy)
                    val p2 = o(103f, 120f + dy)
                    val p3 = o(117f, 104f + dy)
                    val p4 = o(148f, 127f + dy)
                    moveTo(p0.x, p0.y)
                    lineTo(p1.x, p1.y)
                    lineTo(p2.x, p2.y)
                    lineTo(p3.x, p3.y)
                    lineTo(p4.x, p4.y)
                    close()
                }
                drawPath(hills, Color(0xFF6FA8F7))
                // action dots
                drawCircle(Color(0xFFD9E4F4), radius = 3f * u, center = o(75f, 138f + dy))
                drawCircle(Color(0xFFD9E4F4), radius = 3f * u, center = o(89f, 138f + dy))
                drawCircle(Color(0xFFD9E4F4), radius = 3f * u, center = o(103f, 138f + dy))
            }

            // magnifying glass
            val lens = o(156f, 118f + dy2)
            drawCircle(Color(0x66FFFFFF), radius = 21f * u, center = lens)
            drawLine(
                Color(0xFF0F5BD8),
                start = o(171f, 133f + dy2),
                end = o(188f, 150f + dy2),
                strokeWidth = 8f * u,
                cap = StrokeCap.Round
            )
            drawCircle(Color(0xFF1F78F4), radius = 21f * u, center = lens, style = Stroke(6f * u))
            drawLine(
                Color(0xAAFFFFFF),
                start = o(145f, 109f + dy2),
                end = o(150f, 104f + dy2),
                strokeWidth = 3f * u,
                cap = StrokeCap.Round
            )

            // twinkles and dots
            sparkle(o(34f, 46f), 9f * u * twinkle, Color(0xFFFFC517))
            sparkle(o(196f, 44f), 7f * u * (1.6f - twinkle), Color(0xFF5AA0FA))
            sparkle(o(44f, 128f), 5f * u * (1.6f - twinkle), Color(0xFF9CC4FA))
            drawCircle(Color(0xFF9CC4FA), radius = 4f * u, center = o(26f, 100f))
            drawCircle(Color(0xFFFFD66B), radius = 3f * u, center = o(206f, 92f))
            drawCircle(Color(0xFFBBD6F8), radius = 3.5f * u, center = o(182f, 20f))
        }
        Spacer(Modifier.height(14.dp))
        Text(
            "এখনো কোনো পোস্ট নেই",
            color = Ink,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "প্রথম পোস্টটি আপনিই করুন",
            color = Grey,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
    }
}
