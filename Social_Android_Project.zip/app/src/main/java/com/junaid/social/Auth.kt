package com.junaid.social

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.tasks.await

data class User(val uid: String, val name: String, val email: String, val photo: String?)

sealed class AuthResult {
    data class Ok(val user: User) : AuthResult()

    /** field: "email", "pass" or "toast". An empty msg means "user cancelled, say nothing". */
    data class Fail(val field: String, val msg: String) : AuthResult()
}

private fun FirebaseUser.toUser(nameOverride: String? = null): User {
    val n = nameOverride?.takeIf { it.isNotBlank() }
        ?: displayName?.takeIf { it.isNotBlank() }
        ?: email?.substringBefore("@")
        ?: "User"
    return User(uid, n, email ?: "", photoUrl?.toString())
}

/**
 * Online accounts through Firebase Authentication (email + password, Google).
 * The Firebase SDK keeps the session on the phone; "Remember me" off signs out on the next app start.
 */
class AuthStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("boitok_auth", Context.MODE_PRIVATE)
    private val auth get() = FirebaseAuth.getInstance()

    companion object {
        private var checked = false
    }

    fun setKeep(keep: Boolean) {
        sp.edit().putBoolean("keep", keep).apply()
    }

    fun currentUser(): User? {
        val u = auth.currentUser ?: return null
        if (!checked) {
            checked = true
            if (!sp.getBoolean("keep", true)) {
                auth.signOut()
                return null
            }
        }
        return u.toUser()
    }

    fun signOut() = auth.signOut()

    private fun fail(e: Exception?, signUp: Boolean): AuthResult.Fail = when (e) {
        is FirebaseAuthUserCollisionException ->
            AuthResult.Fail("email", "এই ইমেইলে আগেই অ্যাকাউন্ট আছে — Sign In করুন")
        is FirebaseAuthWeakPasswordException ->
            AuthResult.Fail("pass", "পাসওয়ার্ড আরও শক্তিশালী করুন")
        is FirebaseAuthInvalidUserException ->
            AuthResult.Fail("email", "এই ইমেইলে কোনো অ্যাকাউন্ট নেই — Sign Up করুন")
        is FirebaseAuthInvalidCredentialsException ->
            if (signUp) AuthResult.Fail("email", "সঠিক ইমেইল ঠিকানা দিন")
            else AuthResult.Fail("pass", "ইমেইল বা পাসওয়ার্ড ভুল হয়েছে")
        is FirebaseNetworkException ->
            AuthResult.Fail("toast", "ইন্টারনেট সংযোগ নেই")
        is FirebaseTooManyRequestsException ->
            AuthResult.Fail("toast", "অনেকবার চেষ্টা হয়েছে, একটু পরে আবার চেষ্টা করুন")
        else -> AuthResult.Fail("toast", "কিছু একটা সমস্যা হয়েছে, আবার চেষ্টা করুন")
    }

    fun signIn(email: String, pw: String, cb: (AuthResult) -> Unit) {
        auth.signInWithEmailAndPassword(email.trim(), pw).addOnCompleteListener { t ->
            val fu = if (t.isSuccessful) t.result?.user else null
            if (fu != null) cb(AuthResult.Ok(fu.toUser())) else cb(fail(t.exception, false))
        }
    }

    fun register(name: String, email: String, pw: String, cb: (AuthResult) -> Unit) {
        auth.createUserWithEmailAndPassword(email.trim(), pw).addOnCompleteListener { t ->
            val fu = if (t.isSuccessful) t.result?.user else null
            if (fu == null) {
                cb(fail(t.exception, true))
            } else {
                val req = UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()
                fu.updateProfile(req).addOnCompleteListener { cb(AuthResult.Ok(fu.toUser(name.trim()))) }
            }
        }
    }

    fun resetPassword(email: String, cb: (AuthResult) -> Unit) {
        auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { t ->
            if (t.isSuccessful) cb(AuthResult.Fail("toast", "রিসেট লিংক ইমেইলে পাঠানো হয়েছে (স্প্যাম ফোল্ডারও দেখুন)"))
            else cb(fail(t.exception, true).let { if (it.field == "email") AuthResult.Fail("email", it.msg) else it })
        }
    }

    /** [activity] must be the Activity context (Credential Manager shows the account chooser on it). */
    suspend fun googleSignIn(activity: Context): AuthResult {
        return try {
            val resId = activity.resources.getIdentifier("default_web_client_id", "string", activity.packageName)
            if (resId == 0) {
                return AuthResult.Fail("toast", "Google লগইনের সেটআপ অসম্পূর্ণ (google-services.json এ SHA-1 যোগ করে নতুন ফাইল দিন)")
            }
            val option = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(activity.getString(resId))
                .build()
            val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val result = CredentialManager.create(activity).getCredential(activity, request)
            val cred = result.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                val fu = auth.signInWithCredential(GoogleAuthProvider.getCredential(g.idToken, null)).await().user
                if (fu != null) AuthResult.Ok(fu.toUser()) else AuthResult.Fail("toast", "Google লগইন ব্যর্থ হয়েছে")
            } else {
                AuthResult.Fail("toast", "Google লগইন ব্যর্থ হয়েছে")
            }
        } catch (e: GetCredentialCancellationException) {
            AuthResult.Fail("toast", "")
        } catch (e: NoCredentialException) {
            AuthResult.Fail("toast", "এই ফোনে কোনো Google অ্যাকাউন্ট পাওয়া যায়নি")
        } catch (e: GetCredentialException) {
            AuthResult.Fail("toast", "Google লগইন ব্যর্থ হয়েছে (${e.type})")
        } catch (e: Exception) {
            fail(e, false).let { if (it.field == "toast") it else AuthResult.Fail("toast", "Google লগইন ব্যর্থ হয়েছে") }
        }
    }
}

fun isValidEmail(e: String) =
    android.util.Patterns.EMAIL_ADDRESS.matcher(e.trim()).matches()

/** 0..4 */
fun passwordScore(pw: String): Int {
    if (pw.isEmpty()) return 0
    var s = 0
    if (pw.length >= 8) s++
    if (pw.any { it.isLowerCase() } && pw.any { it.isUpperCase() }) s++
    if (pw.any { it.isDigit() }) s++
    if (pw.any { !it.isLetterOrDigit() }) s++
    return maxOf(s, 1)
}
