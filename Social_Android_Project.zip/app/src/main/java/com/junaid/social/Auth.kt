package com.junaid.social

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

data class User(val name: String, val email: String)

/**
 * Local account store (SharedPreferences). Passwords are never saved in plain text:
 * a random salt + SHA-256 hash is stored instead.
 * NOTE: this keeps accounts on the device only. Real cross-device accounts / Google / Facebook
 * sign-in need a backend (e.g. Firebase) which is not connected yet.
 */
class AuthStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("boitok_auth", Context.MODE_PRIVATE)
    private val sep = "\u001F"

    private fun key(email: String) = "u_" + email.trim().lowercase()

    private fun hash(salt: String, pw: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pw).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun exists(email: String) = sp.contains(key(email))

    fun register(name: String, email: String, pw: String): User {
        val saltBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val salt = saltBytes.joinToString("") { "%02x".format(it) }
        sp.edit().putString(key(email), listOf(name.trim(), salt, hash(salt, pw)).joinToString(sep)).apply()
        return User(name.trim(), email.trim().lowercase())
    }

    /** Returns the user, or null when email/password do not match. */
    fun login(email: String, pw: String): User? {
        val raw = sp.getString(key(email), null) ?: return null
        val p = raw.split(sep)
        if (p.size != 3) return null
        return if (hash(p[1], pw) == p[2]) User(p[0], email.trim().lowercase()) else null
    }

    fun saveSession(user: User?) {
        sp.edit().apply {
            if (user == null) remove("session") else putString("session", user.email)
        }.apply()
    }

    fun currentUser(): User? {
        val email = sp.getString("session", null) ?: return null
        val raw = sp.getString(key(email), null) ?: return null
        return User(raw.split(sep)[0], email)
    }
}

fun isValidEmail(e: String) =
    android.util.Patterns.EMAIL_ADDRESS.matcher(e.trim()).matches()

/** 0..4 */
fun passwordScore(pw: String): Int {
    if (pw.isEmpty()) return 0
    var s = 0
    if (pw.length >= 8) s++
    if (pw.any { it.isLowerCase() } && pw.any { it.isUpperCase() }) s++
    if (pw.any { it.isDigit() }) s++
    if (pw.any { !it.isLetterOrDigit() }) s++
    return maxOf(s, 1)
}
