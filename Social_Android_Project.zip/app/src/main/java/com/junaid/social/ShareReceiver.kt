package com.junaid.social

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.firebase.auth.FirebaseAuth

/**
 * Called by Android only after the person has actually picked an app in the share sheet.
 * (Cancelling the sheet never reaches here.) This is where a post's share count goes up.
 */
class ShareReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val postId = intent.getStringExtra(EXTRA_POST_ID) ?: return
        if (FirebaseAuth.getInstance().currentUser == null) return
        Repo.share(postId)
    }

    companion object {
        const val EXTRA_POST_ID = "postId"
    }
}
