package com.junaid.social

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

// colours / icons used only by the login screens (the rest comes from Ui.kt)
val BlueDark = Color(0xFF0B63E0)
val BlueLight = Color(0xFF2E8BFA)
val FieldBg = Color(0xFFF3F7FD)
val FieldBorder = Color(0xFFE1E9F5)
val Green = Color(0xFF13A152)
val Red = Color(0xFFE5484D)
val Amber = Color(0xFFFFB21E)

private fun avec(name: String, d: String, width: Float = 1.8f): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).addPath(
        pathData = PathParser().parsePathString(d).toNodes(),
        fill = null,
        stroke = SolidColor(Color.Black),
        strokeLineWidth = width,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round
    ).build()

private fun acirc(cx: Float, cy: Float, r: Float) =
    "M${cx - r} ${cy}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"

val IMail = avec("mail", "M6 5h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3zM3.5 7.5l8.5 6 8.5-6")
val ILock = avec("lock", "M7.5 10.5h9a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3h-9a3 3 0 0 1-3-3v-4a3 3 0 0 1 3-3zM8 10.5V8a4 4 0 0 1 8 0v2.5")
val IEye = avec("eye", "M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z" + acirc(12f, 12f, 3f))
val IEyeOff = avec("eyeoff", "M3 3l18 18M10.6 5.6A9.8 9.8 0 0 1 12 5.5c6.4 0 10 6.5 10 6.5a17 17 0 0 1-3.2 3.8M6.4 6.9C3.7 8.7 2 12 2 12s3.6 6.5 10 6.5c1.6 0 3-.4 4.3-1M9.9 9.9a3 3 0 0 0 4.2 4.2")
val IArrow = avec("arrow", "M5 12h14M13 6l6 6-6 6", 2.3f)
val ILogout = avec("logout", "M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3M16 8l4 4-4 4M20 12H9", 1.9f)
