package com.junaid.social

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Full-screen gallery for a post's pictures (the whole picture, nothing cut). Swipe sideways for the next picture,
 * swipe down or press back to close.
 */
@Composable
fun ImageGalleryViewer(images: List<String>, startIndex: Int, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    val onCloseNow by rememberUpdatedState(onClose)
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, images.lastIndex)) { images.size }
    var closing by remember { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val appear = remember { Animatable(0f) }

    fun close() {
        if (closing) return
        closing = true
        scope.launch {
            appear.animateTo(0f, tween(180))
            onCloseNow()
        }
    }

    BackHandler { close() }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(220)) }

    // status-bar icons turn white while the dark gallery is open
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = view.context.findActivity()?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, view) }
        val before = ctrl?.isAppearanceLightStatusBars ?: true
        ctrl?.isAppearanceLightStatusBars = false
        onDispose { ctrl?.isAppearanceLightStatusBars = before }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val a = appear.value
                alpha = a * (1f - (dragY / 1200f).coerceIn(0f, 0.6f))
                scaleX = 0.94f + 0.06f * a
                scaleY = 0.94f + 0.06f * a
                translationY = dragY.coerceAtLeast(0f)
            }
            .background(Color.Black)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onVerticalDrag = { change, dy ->
                        change.consume()
                        dragY += dy
                    },
                    onDragEnd = { if (dragY > 260f) close() else dragY = 0f },
                    onDragCancel = { dragY = 0f }
                )
            }
    ) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            GalleryPage(images[page])
        }

        // counter and close
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "${pager.currentPage + 1} / ${images.size}",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x66000000))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            )
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0x66000000))
                    .clickable { close() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Close, null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }

        // page dots
        if (images.size > 1) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(images.size) { i ->
                    val on = i == pager.currentPage
                    Box(
                        Modifier
                            .size(if (on) 7.dp else 6.dp)
                            .clip(CircleShape)
                            .background(if (on) Color.White else Color(0x66FFFFFF))
                    )
                }
            }
        }
    }
}

@Composable
private fun GalleryPage(b64: String) {
    val bmp by produceState<ImageBitmap?>(initialValue = null, b64) {
        value = withContext(Dispatchers.Default) { decodeB64(b64) }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        bmp?.let {
            Image(bitmap = it, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
    }
}
