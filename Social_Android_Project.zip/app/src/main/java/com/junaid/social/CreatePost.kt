package com.junaid.social

import android.net.Uri
import android.view.ViewGroup
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.key
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import android.widget.Toast
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.shadow
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.core.view.WindowCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.DoneAll
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties

// ---------------------------------------------------------------- colours

private val CpPurple = Color(0xFF8257F0)
private val CpPurpleSoft = Color(0xFFEEE8FD)
private val CpIndigo = Color(0xFF5046E5)
private val CpBlue = Color(0xFF207BF4)
private val CpBlueSoft = Color(0xFFE4EFFE)
private val CpRed = Color(0xFFE5484D)
private val CpRedSoft = Color(0xFFFFE7E8)
private val CpGreen = Color(0xFF14935C)
private val CpGreenSoft = Color(0xFFDDF5EA)
private val CpOrange = Color(0xFFE08A00)
private val CpOrangeSoft = Color(0xFFFFF0D6)
private val CpLine = Color(0xFFE9EAF1)
private val CpBg = Color.White
private val CpField = Color(0xFFF8F8FD)
private val CpSub = Color(0xFF6B7385)

private val CpChecklist: ImageVector = ImageVector.Builder("cpchecklist", 24.dp, 24.dp, 24f, 24f)
    .addPath(
        pathData = PathParser().parsePathString("M3.5 6.5l2 2 3.5-4M3.5 16.5l2 2 3.5-4M13 7h8M13 17h8").toNodes(),
        stroke = SolidColor(Color.Black),
        strokeLineWidth = 1.9f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round
    )
    .build()

private const val CP_MIN = 60_000L
private const val CP_HOUR = 60 * CP_MIN
private const val CP_DAY = 24 * CP_HOUR
private const val CP_QUESTION_MAX = 150
private const val CP_OPTION_MAX = 40
private const val CP_OPTIONS_MAX = 5
private const val CP_FOREVER = -1L

private class CpOpt(val id: Long) {
    var text by mutableStateOf("")
    var removing by mutableStateOf(false)
}

private fun cpDuration(ms: Long): String {
    if (ms < 0) return "Forever"
    val d = ms / CP_DAY
    val h = (ms % CP_DAY) / CP_HOUR
    val m = (ms % CP_HOUR) / CP_MIN
    val parts = buildList {
        if (d > 0) add("${d}d")
        if (h > 0) add("${h}h")
        if (m > 0) add("${m}m")
    }
    return if (parts.isEmpty()) "5m" else parts.joinToString(" ")
}

@Composable
private fun Modifier.cpClick(enabled: Boolean = true, onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = NoIndication,
        enabled = enabled,
        onClick = onClick
    )

// ---------------------------------------------------------------- popover menu

private class CpItem(
    val id: String,
    val title: String,
    val sub: String,
    val icon: ImageVector,
    val tileBg: Color,
    val fg: Color,
    val selBg: Color
)

@Composable
private fun CpPopMenu(
    items: List<CpItem>,
    selected: String,
    caretX: Dp,
    offsetY: Dp,
    alignEnd: Boolean,
    width: Dp,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val density = LocalDensity.current
    val shadowPad = 8.dp
    val px = with(density) { shadowPad.roundToPx() }
    val py = with(density) { offsetY.roundToPx() }
    val cx = caretX.coerceIn(22.dp, width - 22.dp)
    Popup(
        alignment = if (alignEnd) Alignment.TopEnd else Alignment.TopStart,
        offset = IntOffset(if (alignEnd) px else -px, py),
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true)
    ) {
        Box(Modifier.width(width + shadowPad * 2).padding(shadowPad)) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.White,
                shadowElevation = 8.dp,
                border = BorderStroke(1.dp, CpLine),
                modifier = Modifier.fillMaxWidth().padding(top = 7.dp)
            ) {
                Column(Modifier.padding(7.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    items.forEach { it ->
                        val sel = it.id == selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(15.dp))
                                .background(if (sel) it.selBg else Color.Transparent)
                                .cpClick { onSelect(it.id) }
                                .padding(horizontal = 8.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(it.tileBg),
                                contentAlignment = Alignment.Center
                            ) { Icon(it.icon, null, tint = it.fg, modifier = Modifier.size(18.dp)) }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(it.title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(it.sub, color = CpSub, fontSize = 11.5.sp, maxLines = 1)
                            }
                            if (sel) {
                                Box(
                                    Modifier.size(22.dp).clip(CircleShape).background(it.fg),
                                    contentAlignment = Alignment.Center
                                ) { Icon(ICheck, null, tint = Color.White, modifier = Modifier.size(13.dp)) }
                            }
                        }
                    }
                }
            }
            // small pointer on top of the card, aimed at the chip that was tapped
            Canvas(
                Modifier
                    .align(if (alignEnd) Alignment.TopEnd else Alignment.TopStart)
                    .offset(x = if (alignEnd) -(cx - 8.dp) else (cx - 8.dp))
                    .size(16.dp, 9.dp)
            ) {
                val w = size.width
                val h = size.height
                val tri = Path().apply {
                    moveTo(0f, h * 0.86f); lineTo(w / 2f, h * 0.10f); lineTo(w, h * 0.86f); close()
                }
                drawPath(tri, Color.White)
                drawRect(Color.White, topLeft = Offset(w * 0.06f, h * 0.74f), size = Size(w * 0.88f, h * 0.22f))
                val edge = Path().apply {
                    moveTo(0f, h * 0.80f); lineTo(w / 2f, h * 0.10f); lineTo(w, h * 0.80f)
                }
                drawPath(edge, CpLine, style = Stroke(width = 1.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

@Composable
private fun CpChip(
    label: String, icon: ImageVector, fg: Color, border: Color, bg: Color,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .height(21.dp)
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .cpClick(onClick = onClick)
            .padding(start = 8.dp, end = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = fg, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(1.dp))
        Icon(Icons.Filled.KeyboardArrowDown, null, tint = fg, modifier = Modifier.size(13.dp))
    }
}

/** (text colour, border colour, background) of a chip. */
private fun cpChipColors(id: String): Triple<Color, Color, Color> = when (id) {
    "followers", "text" -> Triple(CpBlue, Color(0xFF9CC4F7), Color(0xFFF3F8FE))
    "private" -> Triple(CpOrange, Color(0xFFF2C77A), Color(0xFFFFF9EE))
    "image" -> Triple(CpRed, Color(0xFFF4A6A9), Color(0xFFFFF6F6))
    "poll" -> Triple(CpIndigo, Color(0xFFB7A6F7), Color(0xFFF8F6FF))
    else -> Triple(CpGreen, Color(0xFF86D7AF), Color(0xFFF3FBF7))
}

// ---------------------------------------------------------------- settings rows

@Composable
private fun CpDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(CpLine))
}

@Composable
private fun CpSettingRow(
    icon: ImageVector,
    fg: Color,
    bg: Color,
    title: String,
    sub: String,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.cpClick(onClick = onClick) else it }
            .height(54.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(32.dp).clip(RoundedCornerShape(11.dp)).background(bg),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = fg, modifier = Modifier.size(16.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = CpSub, fontSize = 11.5.sp, maxLines = 1)
        }
        trailing()
    }
}

@Composable
private fun CpSwitch(on: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (on) 18.dp else 2.dp, label = "cpsw")
    Box(
        Modifier
            .width(40.dp)
            .height(24.dp)
            .clip(CircleShape)
            .background(if (on) accent else Color(0xFFDDDCE8))
            .border(1.dp, if (on) accent else Color(0xFFCFCDDD), CircleShape)
            .cpClick { onChange(!on) }
    ) {
        Box(
            Modifier
                .offset(x = x, y = 2.dp)
                .size(20.dp)
                .shadow(1.5.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

@Composable
private fun CpSection(label: String, top: Dp = 20.dp, bottom: Dp = 12.dp, right: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = top, bottom = bottom), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color(0xFF6B7385), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
        right()
    }
}

/** Makes the page's own window edge-to-edge with a white status bar (dark icons) instead of a grey dimmed one. */
@Composable
private fun CpWindowStyle() {
    val view = LocalView.current
    SideEffect {
        val w = (view.parent as? DialogWindowProvider)?.window ?: return@SideEffect
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        w.setDimAmount(0f)
        WindowCompat.setDecorFitsSystemWindows(w, false)
        w.statusBarColor = android.graphics.Color.TRANSPARENT
        w.navigationBarColor = android.graphics.Color.TRANSPARENT
        val c = WindowCompat.getInsetsController(w, view)
        c.isAppearanceLightStatusBars = true
        c.isAppearanceLightNavigationBars = true
    }
}

// ---------------------------------------------------------------- duration dialog

@Composable
private fun CpOptionRow(o: CpOpt, number: Int, removable: Boolean, accent: Color, opts: MutableList<CpOpt>) {
    val vs = remember { MutableTransitionState(false).apply { targetState = true } }
    LaunchedEffect(o.removing) { if (o.removing) vs.targetState = false }
    LaunchedEffect(vs.currentState, vs.targetState, o.removing) {
        if (o.removing && !vs.currentState && !vs.targetState) opts.remove(o)
    }
    AnimatedVisibility(
        visibleState = vs,
        enter = expandVertically(tween(280)) + fadeIn(tween(280)),
        exit = shrinkVertically(tween(240)) + fadeOut(tween(180))
    ) {
        Box(Modifier.padding(bottom = 7.dp)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(47.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(CpField)
                    .border(1.dp, Color(0xFFE6E7F1), RoundedCornerShape(16.dp))
                    .padding(start = 9.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)).background(CpPurpleSoft),
                    contentAlignment = Alignment.Center
                ) { Text("$number", color = CpPurple, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (o.text.isEmpty()) Text("Option $number", color = Color(0xFF9AA1AF), fontSize = 15.sp)
                    PasteSafeField(
                        value = o.text,
                        onValueChange = { o.text = it },
                        singleLine = true,
                        maxChars = CP_OPTION_MAX,
                        textStyle = TextStyle(color = Ink, fontSize = 15.sp, fontFamily = OutfitFamily),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    "${o.text.length}/$CP_OPTION_MAX", color = Color(0xFF8A90A0), fontSize = 12.sp,
                    fontStyle = FontStyle.Italic
                )
                if (removable) {
                    Spacer(Modifier.width(9.dp))
                    Icon(
                        Icons.Filled.Close, null, tint = Color(0xFF6B7385),
                        modifier = Modifier.size(16.dp).cpClick { o.removing = true }
                    )
                }
            }
        }
    }
}

@Composable
private fun CpStepper(label: String, value: Int, step: Int, max: Int, accent: Color, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Box(
            Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(CpField)
                .cpClick { onChange((value - step).coerceAtLeast(0)) },
            contentAlignment = Alignment.Center
        ) { Text("−", color = accent, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        Text(
            value.toString(), color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, modifier = Modifier.width(44.dp)
        )
        Box(
            Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha = 0.12f))
                .cpClick { onChange((value + step).coerceAtMost(max)) },
            contentAlignment = Alignment.Center
        ) { Text("+", color = accent, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun CpPreset(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) accent else CpField)
            .border(1.dp, if (selected) accent else Color(0xFFE2E3EC), shape)
            .cpClick(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(label, color = if (selected) Color.White else Ink, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CpDurationDialog(current: Long, accent: Color, onDismiss: () -> Unit, onSave: (Long) -> Unit) {
    val start = if (current < 0) CP_DAY else current
    var forever by remember { mutableStateOf(current < 0) }
    var d by remember { mutableStateOf((start / CP_DAY).toInt()) }
    var h by remember { mutableStateOf(((start % CP_DAY) / CP_HOUR).toInt()) }
    var m by remember { mutableStateOf(((start % CP_HOUR) / CP_MIN).toInt()) }
    val total = d * CP_DAY + h * CP_HOUR + m * CP_MIN
    fun set(ms: Long) {
        forever = false
        d = (ms / CP_DAY).toInt(); h = ((ms % CP_DAY) / CP_HOUR).toInt(); m = ((ms % CP_HOUR) / CP_MIN).toInt()
    }
    val presets1 = listOf("1 hour" to CP_HOUR, "6 hours" to 6 * CP_HOUR, "1 day" to CP_DAY)
    val presets2 = listOf("3 days" to 3 * CP_DAY, "7 days" to 7 * CP_DAY, "30 days" to 30 * CP_DAY)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text("Poll duration", fontSize = 18.sp, fontWeight = FontWeight.SemiBold) },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets1.forEach { (l, v) -> CpPreset(l, !forever && total == v, accent) { set(v) } }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets2.forEach { (l, v) -> CpPreset(l, !forever && total == v, accent) { set(v) } }
                }
                Spacer(Modifier.height(6.dp))
                Row { CpPreset("Forever (no end)", forever, accent) { forever = !forever } }
                if (!forever) {
                    Spacer(Modifier.height(10.dp))
                    CpStepper("Days", d, 1, 3650, accent) { d = it }
                    CpStepper("Hours", h, 1, 23, accent) { h = it }
                    CpStepper("Minutes", m, 5, 55, accent) { m = it }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(if (forever) CP_FOREVER else if (total < 5 * CP_MIN) 5 * CP_MIN else total)
            }) { Text("Save", color = accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = Grey) } }
    )
}

// ---------------------------------------------------------------- the page

/**
 * Full-screen "Create Post" page. One page for the three post types (Text / Image / Poll).
 * [onPost] gets: text (the question for a poll), pictures, poll options, poll length in milliseconds.
 * Audience, "who can vote", multiple answers, anonymous voting, early results and comments are on the screen
 * only for now; they are not saved online yet.
 */
@Composable
fun ComposeDialog(
    initialMode: String,
    userName: String,
    userPhoto: String?,
    verified: Boolean,
    onDismiss: () -> Unit,
    onPost: (String, List<Uri>, List<String>, Long) -> Unit
) {
    var mode by remember { mutableStateOf(if (initialMode == "image" || initialMode == "poll") initialMode else "text") }
    var audience by remember { mutableStateOf("public") }
    var text by remember { mutableStateOf("") }
    val uris = remember { mutableStateListOf<Uri>() }
    val idGen = remember { longArrayOf(2L) }
    val opts = remember { mutableStateListOf(CpOpt(0L), CpOpt(1L)) }
    var duration by remember { mutableStateOf(CP_DAY + 6 * CP_HOUR + 30 * CP_MIN) }
    var whoCan by remember { mutableStateOf("everyone") }
    var multiple by remember { mutableStateOf(false) }
    var anonymous by remember { mutableStateOf(false) }
    var early by remember { mutableStateOf(false) }
    var comments by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf<String?>(null) }
    var showDuration by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { picked ->
        for (u in picked) if (uris.size < MAX_POST_PHOTOS && u !in uris) uris.add(u)
    }
    val firstBmp = rememberUriBitmap(uris.firstOrNull())
    LaunchedEffect(Unit) { if (initialMode == "image") picker.launch("image/*") }

    val accent = when (mode) { "poll" -> CpPurple; "image" -> CpRed; else -> CpBlue }
    val accentSoft = when (mode) { "poll" -> CpPurpleSoft; "image" -> CpRedSoft; else -> CpBlueSoft }

    val filledOptions = opts.count { !it.removing && it.text.isNotBlank() }
    val canPost = when (mode) {
        "poll" -> text.isNotBlank() && filledOptions >= 2
        "image" -> uris.isNotEmpty() || text.isNotBlank()
        else -> text.isNotBlank()
    }

    val audienceItems = listOf(
        CpItem("public", "Public", "Anyone can see your post", IGlobe, Color(0xFFE9ECF2), Ink, CpGreenSoft),
        CpItem("followers", "Followers", "Only your followers", IUsers, CpBlueSoft, CpBlue, CpBlueSoft),
        CpItem("private", "Private", "Just for you, nobody else", Icons.Outlined.Lock, CpOrangeSoft, CpOrange, CpOrangeSoft)
    )
    val typeItems = listOf(
        CpItem("text", "Text", "Share your thoughts", IText, Color(0xFFDDEEFF), Color(0xFF2B7BE0), Color(0xFFE4EFFE)),
        CpItem("image", "Image", "Share photos", IImage, Color(0xFFFFE4E9), Color(0xFFE11D48), Color(0xFFFFE4E9)),
        CpItem("poll", "Poll", "Ask the community", IBars, Color(0xFFECEEFE), CpIndigo, Color(0xFFECEEFE))
    )
    val whoItems = listOf(
        CpItem("everyone", "Everyone", "Anyone can vote", IGlobe, Color(0xFFE9ECF2), Ink, CpPurpleSoft),
        CpItem("followers", "Followers", "Only your followers", IUsers, CpBlueSoft, CpBlue, CpBlueSoft)
    )
    val audIcon = when (audience) { "followers" -> IUsers; "private" -> Icons.Outlined.Lock; else -> IGlobe }
    val audLabel = audienceItems.first { it.id == audience }.title
    val typeIcon = when (mode) { "poll" -> IBars; "image" -> IImage; else -> IText }
    val typeLabel = typeItems.first { it.id == mode }.title

    val ctx = LocalContext.current
    val density = LocalDensity.current
    var audX by remember { mutableStateOf(0f) }   // chip centres (px), measured inside the chips row
    var typeX by remember { mutableStateOf(0f) }

    fun doPost() {
        if (!canPost) {
            Toast.makeText(
                ctx,
                if (mode == "poll") "Add a question and at least 2 options" else "Write something first",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        onPost(
            text.trim(),
            if (mode == "image") uris.toList() else emptyList(),
            if (mode == "poll") opts.filter { !it.removing && it.text.isNotBlank() }.map { it.text.trim() } else emptyList(),
            duration
        )
    }

    val audColors = cpChipColors(audience)
    val typeColors = cpChipColors(mode)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        CpWindowStyle()
        Surface(Modifier.fillMaxSize(), color = CpBg) {
            ProvideTextStyle(TextStyle(fontFamily = OutfitFamily)) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {

                    // ---- top bar: back, exactly-centred title, Post
                    Box(Modifier.fillMaxWidth().height(46.dp).padding(horizontal = 12.dp)) {
                        Box(
                            Modifier.align(Alignment.CenterStart).size(36.dp).cpClick(onClick = onDismiss),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = Ink, modifier = Modifier.size(30.dp)) }
                        Text(
                            "Create Post", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.align(Alignment.Center)
                        )
                        Box(
                            Modifier
                                .align(Alignment.CenterEnd)
                                .width(70.dp)
                                .height(34.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(accent)
                                .cpClick { doPost() },
                            contentAlignment = Alignment.Center
                        ) { Text("Post", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                    }
                    CpDivider()

                    // ---- scrolling body
                    Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
                    ) {
                        Spacer(Modifier.height(18.dp))

                        // user row with the two chips
                        Row(verticalAlignment = Alignment.Top) {
                            UserAvatar(userPhoto, userName, 38.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        userName, color = Ink, fontSize = 15.5.sp, lineHeight = 18.sp,
                                        fontWeight = FontWeight.SemiBold, maxLines = 1
                                    )
                                    if (verified) {
                                        Spacer(Modifier.width(5.dp))
                                        Icon(IVerified, null, tint = Color.Unspecified, modifier = Modifier.size(14.dp))
                                    }
                                }
                                Spacer(Modifier.height(2.dp))
                                Box {
                                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                        CpChip(
                                            audLabel, audIcon, audColors.first, audColors.second, audColors.third,
                                            Modifier.onGloballyPositioned { audX = it.positionInParent().x + it.size.width / 2f }
                                        ) { menu = "aud" }
                                        CpChip(
                                            typeLabel, typeIcon, typeColors.first, typeColors.second, typeColors.third,
                                            Modifier.onGloballyPositioned { typeX = it.positionInParent().x + it.size.width / 2f }
                                        ) { menu = "type" }
                                    }
                                    if (menu == "aud") CpPopMenu(
                                        audienceItems, audience, with(density) { audX.toDp() }, 15.dp, false, 232.dp,
                                        onSelect = { audience = it; menu = null }, onDismiss = { menu = null }
                                    )
                                    if (menu == "type") CpPopMenu(
                                        typeItems, mode, with(density) { typeX.toDp() }, 15.dp, false, 232.dp,
                                        onSelect = { id ->
                                            menu = null
                                            if (id != mode) {
                                                mode = id
                                                if (id == "poll") text = cutToLimit(text, CP_QUESTION_MAX)
                                                if (id == "image" && uris.isEmpty()) picker.launch("image/*")
                                            }
                                        },
                                        onDismiss = { menu = null }
                                    )
                                }
                            }
                        }

                        if (mode == "poll") {
                            val active = opts.filter { !it.removing }

                            // ---- question
                            CpSection("QUESTION", top = 14.dp, bottom = 11.dp)
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 64.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFFFAF9FF))
                                    .border(1.5.dp, accent.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                                    .padding(start = 14.dp, end = 14.dp, top = 11.dp, bottom = 24.dp)
                            ) {
                                if (text.isEmpty()) Text("What do you want to ask?", color = Color(0xFF8A90A0), fontSize = 16.sp)
                                PasteSafeField(
                                    value = text,
                                    onValueChange = { text = it },
                                    maxChars = CP_QUESTION_MAX,
                                    textStyle = TextStyle(color = Ink, fontSize = 16.sp, fontFamily = OutfitFamily),
                                    cursorBrush = SolidColor(accent),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    "${text.length}/$CP_QUESTION_MAX", color = Color(0xFF8A90A0), fontSize = 12.sp,
                                    modifier = Modifier.align(Alignment.BottomEnd).offset(y = 14.dp)
                                )
                            }

                            // ---- options (two to start; Add / X animate in and out)
                            CpSection("OPTIONS", top = 20.dp, bottom = 11.dp) {
                                Box(
                                    Modifier.clip(RoundedCornerShape(50)).background(CpPurpleSoft)
                                        .padding(horizontal = 11.dp, vertical = 3.dp)
                                ) {
                                    Text("${active.size} of $CP_OPTIONS_MAX", color = CpPurple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            opts.forEach { o ->
                                key(o.id) {
                                    val number = if (o.removing) opts.indexOf(o) + 1 else active.indexOf(o) + 1
                                    CpOptionRow(o, number, removable = number > 2 && !o.removing, accent = accent, opts = opts)
                                }
                            }
                            AnimatedVisibility(
                                visible = active.size < CP_OPTIONS_MAX,
                                enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                                exit = shrinkVertically(tween(220)) + fadeOut(tween(160))
                            ) {
                                val left = CP_OPTIONS_MAX - active.size
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .height(57.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Brush.horizontalGradient(listOf(Color(0xFFF3EFFF), Color(0xFFF1ECFE))))
                                        .border(1.dp, Color(0xFFD9CFF9), RoundedCornerShape(16.dp))
                                        .cpClick { opts.add(CpOpt(idGen[0]++)) }
                                        .padding(horizontal = 14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.size(32.dp).clip(RoundedCornerShape(11.dp))
                                            .background(Brush.linearGradient(listOf(Color(0xFF9A74F8), Color(0xFF7C4DEA)))),
                                        contentAlignment = Alignment.Center
                                    ) { Icon(IPlus, null, tint = Color.White, modifier = Modifier.size(17.dp)) }
                                    Spacer(Modifier.width(13.dp))
                                    Column {
                                        Text("Add option", color = CpPurple, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "$left more option${if (left == 1) "" else "s"} allowed",
                                            color = CpSub, fontSize = 12.sp
                                        )
                                    }
                                }
                            }

                            // ---- settings (flat rows with thin dividers)
                            CpSection("SETTINGS", top = 23.dp, bottom = 12.dp)
                            CpDivider()
                            CpSettingRow(
                                Icons.Outlined.Timer, CpIndigo, Color(0xFFEBEDFE), "Poll duration", "How long voting stays open",
                                onClick = { showDuration = true }
                            ) {
                                Box(
                                    Modifier.clip(RoundedCornerShape(50)).background(CpPurpleSoft)
                                        .padding(horizontal = 12.dp, vertical = 4.dp)
                                ) { Text(cpDuration(duration), color = CpPurple, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold) }
                            }
                            CpDivider()
                            CpSettingRow(
                                IUsers, CpBlue, Color(0xFFDFF0FE), "Who can vote", "Choose who can take part",
                                onClick = { menu = "who" }
                            ) {
                                Box {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(whoItems.first { it.id == whoCan }.title, color = CpSub, fontSize = 13.sp)
                                        Icon(Icons.Filled.ChevronRight, null, tint = CpSub, modifier = Modifier.size(18.dp))
                                    }
                                    if (menu == "who") CpPopMenu(
                                        whoItems, whoCan, 22.dp, 14.dp, true, 232.dp,
                                        onSelect = { whoCan = it; menu = null }, onDismiss = { menu = null }
                                    )
                                }
                            }
                            CpDivider()
                            CpSettingRow(
                                CpChecklist, CpPurple, Color(0xFFF0EAFE), "Multiple answers", "Voters can pick more than one"
                            ) { CpSwitch(multiple, CpPurple) { multiple = it } }
                            CpDivider()
                            CpSettingRow(
                                Icons.Outlined.VisibilityOff, CpGreen, CpGreenSoft, "Anonymous voting", "Hide who voted for what"
                            ) { CpSwitch(anonymous, CpPurple) { anonymous = it } }
                            CpDivider()
                            CpSettingRow(
                                IBars, Color(0xFFF08A00), Color(0xFFFFF0D2), "Early results", "Show results before voting"
                            ) { CpSwitch(early, CpPurple) { early = it } }
                            CpDivider()
                            CpSettingRow(
                                IChat, Color(0xFFE11D48), Color(0xFFFFE4E9), "Comments", "Let people join the discussion"
                            ) { CpSwitch(comments, CpPurple) { comments = it } }
                            CpDivider()
                            CpSettingRow(
                                Icons.Filled.MoreHoriz, Color(0xFF4B5563), Color(0xFFEDEFF4), "More options",
                                "Topics, location, schedule & more",
                                onClick = { }
                            ) { Icon(Icons.Filled.ChevronRight, null, tint = CpSub, modifier = Modifier.size(18.dp)) }

                            // ---- note (end of the page)
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(top = 18.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(CpOrangeSoft)
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Outlined.Info, null, tint = CpOrange, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "Once a poll is posted, it can't be edited later.",
                                    color = Color(0xFF8A5A00), fontSize = 11.5.sp, fontWeight = FontWeight.Medium
                                )
                            }
                        } else {
                            // ---- text / image post
                            Spacer(Modifier.height(16.dp))
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 130.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFFFAFAFF))
                                    .border(1.5.dp, accent.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                                    .padding(14.dp)
                            ) {
                                if (text.isEmpty()) Text("What's on your mind?", color = Color(0xFF8A90A0), fontSize = 16.sp)
                                PasteSafeField(
                                    value = text,
                                    onValueChange = { text = it },
                                    textStyle = TextStyle(color = Ink, fontSize = 16.sp, fontFamily = OutfitFamily),
                                    cursorBrush = SolidColor(accent),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            if (mode == "image") {
                                if (uris.size == 1 && firstBmp != null) {
                                    Spacer(Modifier.height(10.dp))
                                    FramedPicture(firstBmp, corner = 12.dp)
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(
                                    Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (uris.size < MAX_POST_PHOTOS) {
                                        Box(
                                            Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(accentSoft)
                                                .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                                .cpClick { picker.launch("image/*") },
                                            contentAlignment = Alignment.Center
                                        ) { Icon(IPlus, null, tint = accent, modifier = Modifier.size(22.dp)) }
                                    }
                                    uris.toList().forEach { u ->
                                        key(u) { PickedThumb(u) { uris.remove(u) } }
                                    }
                                }
                                Text(
                                    "${uris.size}/$MAX_POST_PHOTOS photos", color = CpSub, fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            CpSection("SETTINGS", top = 23.dp, bottom = 12.dp)
                            CpDivider()
                            CpSettingRow(
                                IChat, Color(0xFFE11D48), Color(0xFFFFE4E9), "Comments", "Let people join the discussion"
                            ) { CpSwitch(comments, accent) { comments = it } }
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }
        }
    }

    if (showDuration) {
        CpDurationDialog(duration, accent, onDismiss = { showDuration = false }) {
            duration = it
            showDuration = false
        }
    }
}
