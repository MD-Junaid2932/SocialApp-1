package com.junaid.social

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.DoneAll
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties

// ---------------------------------------------------------------- colours

private val CpPurple = Color(0xFF7B4DF5)
private val CpPurpleSoft = Color(0xFFEFE9FE)
private val CpBlue = Color(0xFF207BF4)
private val CpBlueSoft = Color(0xFFE4EFFE)
private val CpRed = Color(0xFFE5484D)
private val CpRedSoft = Color(0xFFFFE7E8)
private val CpGreen = Color(0xFF1FA463)
private val CpGreenSoft = Color(0xFFE2F5EA)
private val CpOrange = Color(0xFFE08A00)
private val CpOrangeSoft = Color(0xFFFFF0D6)
private val CpLine = Color(0xFFE6E8F0)
private val CpBg = Color(0xFFF9FAFD)
private val CpField = Color(0xFFF5F6FA)

private const val CP_MIN = 60_000L
private const val CP_HOUR = 60 * CP_MIN
private const val CP_DAY = 24 * CP_HOUR
private const val CP_QUESTION_MAX = 150
private const val CP_OPTION_MAX = 40
private const val CP_OPTIONS_MAX = 5

private fun cpDuration(ms: Long): String {
    val d = ms / CP_DAY
    val h = (ms % CP_DAY) / CP_HOUR
    val m = (ms % CP_HOUR) / CP_MIN
    val parts = buildList {
        if (d > 0) add("${d}d")
        if (h > 0) add("${h}h")
        if (m > 0) add("${m}m")
    }
    return if (parts.isEmpty()) "5m" else parts.joinToString(" ")
}

@Composable
private fun Modifier.cpClick(enabled: Boolean = true, onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = NoIndication,
        enabled = enabled,
        onClick = onClick
    )

// ---------------------------------------------------------------- popover menu

private class CpItem(
    val id: String,
    val title: String,
    val sub: String,
    val icon: ImageVector,
    val tileBg: Color,
    val fg: Color,
    val selBg: Color
)

@Composable
private fun CpPopMenu(
    items: List<CpItem>,
    selected: String,
    offsetY: Dp,
    alignEnd: Boolean,
    width: Dp,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val py = with(LocalDensity.current) { offsetY.roundToPx() }
    Popup(
        alignment = if (alignEnd) Alignment.TopEnd else Alignment.TopStart,
        offset = IntOffset(0, py),
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            border = BorderStroke(1.dp, CpLine),
            modifier = Modifier.width(width)
        ) {
            Column(Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                items.forEach { it ->
                    val sel = it.id == selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(13.dp))
                            .background(if (sel) it.selBg else Color.Transparent)
                            .cpClick { onSelect(it.id) }
                            .padding(horizontal = 8.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(it.tileBg),
                            contentAlignment = Alignment.Center
                        ) { Icon(it.icon, null, tint = it.fg, modifier = Modifier.size(18.dp)) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(it.title, color = Ink, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                            Text(it.sub, color = Grey, fontSize = 11.sp, maxLines = 1)
                        }
                        if (sel) {
                            Box(
                                Modifier.size(20.dp).clip(CircleShape).background(it.fg),
                                contentAlignment = Alignment.Center
                            ) { Icon(ICheck, null, tint = Color.White, modifier = Modifier.size(12.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CpChip(label: String, icon: ImageVector, fg: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        Modifier
            .clip(shape)
            .background(Color.White)
            .border(1.dp, fg.copy(alpha = 0.40f), shape)
            .cpClick(onClick = onClick)
            .padding(start = 8.dp, end = 5.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Icon(Icons.Filled.KeyboardArrowDown, null, tint = fg, modifier = Modifier.size(13.dp))
    }
}

// ---------------------------------------------------------------- settings rows

@Composable
private fun CpSettingRow(
    icon: ImageVector,
    fg: Color,
    bg: Color,
    title: String,
    sub: String,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.cpClick(onClick = onClick) else it }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(bg),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = fg, modifier = Modifier.size(16.dp)) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Grey, fontSize = 11.sp, maxLines = 1)
        }
        trailing()
    }
}

@Composable
private fun CpSwitch(on: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Switch(
        checked = on,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = accent,
            checkedBorderColor = Color.Transparent,
            uncheckedThumbColor = Color.White,
            uncheckedTrackColor = Color(0xFFDDE1EA),
            uncheckedBorderColor = Color.Transparent
        )
    )
}

@Composable
private fun CpSection(label: String, modifier: Modifier = Modifier, right: @Composable () -> Unit = {}) {
    Row(modifier.fillMaxWidth().padding(top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Grey, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, modifier = Modifier.weight(1f))
        right()
    }
}

// ---------------------------------------------------------------- duration dialog

@Composable
private fun CpStepper(label: String, value: Int, step: Int, max: Int, accent: Color, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Box(
            Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(CpField)
                .cpClick { onChange((value - step).coerceAtLeast(0)) },
            contentAlignment = Alignment.Center
        ) { Text("−", color = accent, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Text(
            value.toString(), color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, modifier = Modifier.width(44.dp)
        )
        Box(
            Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha = 0.12f))
                .cpClick { onChange((value + step).coerceAtMost(max)) },
            contentAlignment = Alignment.Center
        ) { Text("+", color = accent, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun CpDurationDialog(current: Long, accent: Color, onDismiss: () -> Unit, onSave: (Long) -> Unit) {
    var d by remember { mutableStateOf((current / CP_DAY).toInt()) }
    var h by remember { mutableStateOf(((current % CP_DAY) / CP_HOUR).toInt()) }
    var m by remember { mutableStateOf(((current % CP_HOUR) / CP_MIN).toInt()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text("Poll duration", fontWeight = FontWeight.SemiBold) },
        text = {
            Column {
                CpStepper("Days", d, 1, 7, accent) { d = it }
                CpStepper("Hours", h, 1, 23, accent) { h = it }
                CpStepper("Minutes", m, 5, 55, accent) { m = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val total = d * CP_DAY + h * CP_HOUR + m * CP_MIN
                onSave(if (total < 5 * CP_MIN) 5 * CP_MIN else total)
            }) { Text("Save", color = accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = Grey) } }
    )
}

// ---------------------------------------------------------------- the page

/**
 * Full-screen "Create Post" page. One page for the three post types (Text / Image / Poll).
 * [onPost] gets: text (the question for a poll), pictures, poll options, poll length in milliseconds.
 * Audience, "who can vote", multiple answers, anonymous voting, early results and comments are on the screen
 * only for now; they are not saved online yet.
 */
@Composable
fun ComposeDialog(
    initialMode: String,
    userName: String,
    userPhoto: String?,
    verified: Boolean,
    onDismiss: () -> Unit,
    onPost: (String, List<Uri>, List<String>, Long) -> Unit
) {
    var mode by remember { mutableStateOf(if (initialMode == "image" || initialMode == "poll") initialMode else "text") }
    var audience by remember { mutableStateOf("public") }
    var text by remember { mutableStateOf("") }
    val uris = remember { mutableStateListOf<Uri>() }
    val opts = remember { mutableStateListOf("", "", "", "") }
    var duration by remember { mutableStateOf(CP_DAY + 6 * CP_HOUR + 30 * CP_MIN) }
    var whoCan by remember { mutableStateOf("everyone") }
    var multiple by remember { mutableStateOf(false) }
    var anonymous by remember { mutableStateOf(false) }
    var early by remember { mutableStateOf(false) }
    var comments by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf<String?>(null) }
    var showDuration by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { picked ->
        for (u in picked) if (uris.size < MAX_POST_PHOTOS && u !in uris) uris.add(u)
    }
    val firstBmp = rememberUriBitmap(uris.firstOrNull())
    LaunchedEffect(Unit) { if (initialMode == "image") picker.launch("image/*") }

    val accent = when (mode) { "poll" -> CpPurple; "image" -> CpRed; else -> CpBlue }
    val accentSoft = when (mode) { "poll" -> CpPurpleSoft; "image" -> CpRedSoft; else -> CpBlueSoft }

    val filledOptions = opts.count { it.isNotBlank() }
    val canPost = when (mode) {
        "poll" -> text.isNotBlank() && filledOptions >= 2
        "image" -> uris.isNotEmpty() || text.isNotBlank()
        else -> text.isNotBlank()
    }

    val audienceItems = listOf(
        CpItem("public", "Public", "Anyone can see your post", IGlobe, Color(0xFFE9ECF2), Ink, CpGreenSoft),
        CpItem("followers", "Followers", "Only your followers", IUsers, CpBlueSoft, CpBlue, CpBlueSoft),
        CpItem("private", "Private", "Just for you, nobody else", Icons.Outlined.Lock, CpOrangeSoft, CpOrange, CpOrangeSoft)
    )
    val typeItems = listOf(
        CpItem("text", "Text", "Share your thoughts", IText, CpBlueSoft, CpBlue, CpBlueSoft),
        CpItem("image", "Image", "Share photos", IImage, CpRedSoft, CpRed, CpRedSoft),
        CpItem("poll", "Poll", "Ask the community", IBars, CpPurpleSoft, CpPurple, CpPurpleSoft)
    )
    val whoItems = listOf(
        CpItem("everyone", "Everyone", "Anyone can vote", IGlobe, Color(0xFFE9ECF2), Ink, CpPurpleSoft),
        CpItem("followers", "Followers", "Only your followers", IUsers, CpBlueSoft, CpBlue, CpBlueSoft)
    )
    // audience chip colours follow the chosen audience (green / blue / orange)
    val audFg = when (audience) { "followers" -> CpBlue; "private" -> CpOrange; else -> CpGreen }
    val audIcon = when (audience) { "followers" -> IUsers; "private" -> Icons.Outlined.Lock; else -> IGlobe }
    val audLabel = audienceItems.first { it.id == audience }.title
    val typeIcon = when (mode) { "poll" -> IBars; "image" -> IImage; else -> IText }
    val typeLabel = typeItems.first { it.id == mode }.title

    fun doPost() {
        if (!canPost) return
        onPost(
            text.trim(),
            if (mode == "image") uris.toList() else emptyList(),
            if (mode == "poll") opts.filter { it.isNotBlank() }.map { it.trim() } else emptyList(),
            duration
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = CpBg) {
            ProvideTextStyle(TextStyle(fontFamily = OutfitFamily)) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {

                    // ---- top bar: back, exactly-centred title, Post
                    Box(
                        Modifier.fillMaxWidth().height(56.dp).background(Color.White).padding(horizontal = 12.dp)
                    ) {
                        Box(
                            Modifier.align(Alignment.CenterStart).size(36.dp).cpClick(onClick = onDismiss),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Ink, modifier = Modifier.size(22.dp)) }
                        Text(
                            "Create Post", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.align(Alignment.Center)
                        )
                        Box(
                            Modifier
                                .align(Alignment.CenterEnd)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (canPost) accent else accent.copy(alpha = 0.40f))
                                .cpClick(enabled = canPost) { doPost() }
                                .padding(horizontal = 22.dp, vertical = 9.dp)
                        ) { Text("Post", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(CpLine))

                    // ---- scrolling body
                    Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)
                    ) {
                        Spacer(Modifier.height(12.dp))

                        // user row with the two chips
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            UserAvatar(userPhoto, userName, 42.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(userName, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    if (verified) {
                                        Spacer(Modifier.width(4.dp))
                                        Icon(IVerified, null, tint = Color.Unspecified, modifier = Modifier.size(14.dp))
                                    }
                                }
                                Spacer(Modifier.height(5.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box {
                                        CpChip(audLabel, audIcon, audFg) { menu = "aud" }
                                        if (menu == "aud") CpPopMenu(
                                            audienceItems, audience, 30.dp, false, 232.dp,
                                            onSelect = { audience = it; menu = null }, onDismiss = { menu = null }
                                        )
                                    }
                                    Box {
                                        CpChip(typeLabel, typeIcon, accent) { menu = "type" }
                                        if (menu == "type") CpPopMenu(
                                            typeItems, mode, 30.dp, false, 232.dp,
                                            onSelect = { id ->
                                                menu = null
                                                if (id != mode) {
                                                    mode = id
                                                    if (id == "poll") text = cutToLimit(text, CP_QUESTION_MAX)
                                                    if (id == "image" && uris.isEmpty()) picker.launch("image/*")
                                                }
                                            },
                                            onDismiss = { menu = null }
                                        )
                                    }
                                }
                            }
                        }

                        if (mode == "poll") {
                            // ---- question
                            CpSection("QUESTION")
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 92.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color.White)
                                    .border(1.2.dp, accent, RoundedCornerShape(14.dp))
                                    .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 24.dp)
                            ) {
                                if (text.isEmpty()) Text("What do you want to ask?", color = Grey, fontSize = 14.sp)
                                PasteSafeField(
                                    value = text,
                                    onValueChange = { text = it },
                                    maxChars = CP_QUESTION_MAX,
                                    textStyle = TextStyle(color = Ink, fontSize = 15.sp, fontFamily = OutfitFamily),
                                    cursorBrush = SolidColor(accent),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    "${text.length}/$CP_QUESTION_MAX", color = Grey, fontSize = 10.5.sp,
                                    fontStyle = FontStyle.Italic,
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(top = 6.dp)
                                )
                            }

                            // ---- options
                            CpSection("OPTIONS") {
                                Box(
                                    Modifier.clip(RoundedCornerShape(8.dp)).background(CpPurpleSoft)
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text("${opts.size} of $CP_OPTIONS_MAX", color = CpPurple, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            opts.forEachIndexed { i, v ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .height(46.dp)
                                        .clip(RoundedCornerShape(13.dp))
                                        .background(CpField)
                                        .border(1.dp, Color(0xFFECEEF4), RoundedCornerShape(13.dp))
                                        .padding(horizontal = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.size(24.dp).clip(RoundedCornerShape(7.dp)).background(CpPurpleSoft),
                                        contentAlignment = Alignment.Center
                                    ) { Text("${i + 1}", color = CpPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                    Spacer(Modifier.width(10.dp))
                                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                        if (v.isEmpty()) Text("Option ${i + 1}", color = Color(0xFF9AA1AF), fontSize = 14.sp)
                                        PasteSafeField(
                                            value = v,
                                            onValueChange = { opts[i] = it },
                                            singleLine = true,
                                            maxChars = CP_OPTION_MAX,
                                            textStyle = TextStyle(color = Ink, fontSize = 14.sp, fontFamily = OutfitFamily),
                                            cursorBrush = SolidColor(accent),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    Text(
                                        "${v.length}/$CP_OPTION_MAX", color = Grey, fontSize = 10.5.sp,
                                        fontStyle = FontStyle.Italic
                                    )
                                    if (i >= 2) {
                                        Spacer(Modifier.width(8.dp))
                                        Icon(
                                            Icons.Filled.Close, null, tint = Grey,
                                            modifier = Modifier.size(15.dp).cpClick { opts.removeAt(i) }
                                        )
                                    }
                                }
                            }
                            if (opts.size < CP_OPTIONS_MAX) {
                                val left = CP_OPTIONS_MAX - opts.size
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(top = 6.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Brush.horizontalGradient(listOf(CpPurpleSoft, Color(0xFFF7F4FF))))
                                        .border(1.dp, CpPurple.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                                        .cpClick { opts.add("") }
                                        .padding(horizontal = 10.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(CpPurple),
                                        contentAlignment = Alignment.Center
                                    ) { Icon(IPlus, null, tint = Color.White, modifier = Modifier.size(17.dp)) }
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text("Add option", color = CpPurple, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "$left more option${if (left == 1) "" else "s"} allowed",
                                            color = Grey, fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            // ---- settings
                            CpSection("SETTINGS")
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.White)
                                    .border(1.dp, CpLine, RoundedCornerShape(16.dp))
                                    .padding(vertical = 2.dp)
                            ) {
                                CpSettingRow(
                                    IClock, CpPurple, CpPurpleSoft, "Poll duration", "How long voting stays open",
                                    onClick = { showDuration = true }
                                ) {
                                    Box(
                                        Modifier.clip(RoundedCornerShape(9.dp)).background(CpPurpleSoft)
                                            .padding(horizontal = 9.dp, vertical = 4.dp)
                                    ) { Text(cpDuration(duration), color = CpPurple, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold) }
                                }
                                CpSettingRow(
                                    IUsers, CpBlue, CpBlueSoft, "Who can vote", "Choose who can take part",
                                    onClick = { menu = "who" }
                                ) {
                                    Box {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                whoItems.first { it.id == whoCan }.title,
                                                color = Grey, fontSize = 12.sp
                                            )
                                            Icon(Icons.Filled.ChevronRight, null, tint = Grey, modifier = Modifier.size(18.dp))
                                        }
                                        if (menu == "who") CpPopMenu(
                                            whoItems, whoCan, 28.dp, true, 232.dp,
                                            onSelect = { whoCan = it; menu = null }, onDismiss = { menu = null }
                                        )
                                    }
                                }
                                CpSettingRow(
                                    Icons.Outlined.DoneAll, CpPurple, CpPurpleSoft, "Multiple answers",
                                    "Voters can pick more than one"
                                ) { CpSwitch(multiple, CpPurple) { multiple = it } }
                                CpSettingRow(
                                    Icons.Outlined.VisibilityOff, CpGreen, CpGreenSoft, "Anonymous voting",
                                    "Hide who voted for what"
                                ) { CpSwitch(anonymous, CpPurple) { anonymous = it } }
                                CpSettingRow(
                                    IBars, CpOrange, CpOrangeSoft, "Early results", "Show results before voting"
                                ) { CpSwitch(early, CpPurple) { early = it } }
                                CpSettingRow(
                                    IChat, CpRed, CpRedSoft, "Comments", "Let people join the discussion"
                                ) { CpSwitch(comments, CpPurple) { comments = it } }
                                CpSettingRow(
                                    Icons.Filled.MoreHoriz, Grey, Color(0xFFEDEFF4), "More options",
                                    "Topics, location, schedule & more",
                                    onClick = { }
                                ) { Icon(Icons.Filled.ChevronRight, null, tint = Grey, modifier = Modifier.size(18.dp)) }
                            }
                        } else {
                            // ---- text / image post
                            Spacer(Modifier.height(14.dp))
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 130.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color.White)
                                    .border(1.2.dp, accent, RoundedCornerShape(14.dp))
                                    .padding(14.dp)
                            ) {
                                if (text.isEmpty()) Text("What's on your mind?", color = Grey, fontSize = 15.sp)
                                PasteSafeField(
                                    value = text,
                                    onValueChange = { text = it },
                                    textStyle = TextStyle(color = Ink, fontSize = 16.sp, fontFamily = OutfitFamily),
                                    cursorBrush = SolidColor(accent),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            if (mode == "image") {
                                if (uris.size == 1 && firstBmp != null) {
                                    Spacer(Modifier.height(10.dp))
                                    FramedPicture(firstBmp, corner = 12.dp)
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(
                                    Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (uris.size < MAX_POST_PHOTOS) {
                                        Box(
                                            Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)).background(accentSoft)
                                                .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                                                .cpClick { picker.launch("image/*") },
                                            contentAlignment = Alignment.Center
                                        ) { Icon(IPlus, null, tint = accent, modifier = Modifier.size(22.dp)) }
                                    }
                                    uris.toList().forEach { u ->
                                        androidx.compose.runtime.key(u) { PickedThumb(u) { uris.remove(u) } }
                                    }
                                }
                                Text(
                                    "${uris.size}/$MAX_POST_PHOTOS photos", color = Grey, fontSize = 11.5.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            CpSection("SETTINGS")
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.White)
                                    .border(1.dp, CpLine, RoundedCornerShape(16.dp))
                                    .padding(vertical = 2.dp)
                            ) {
                                CpSettingRow(
                                    IChat, CpRed, CpRedSoft, "Comments", "Let people join the discussion"
                                ) { CpSwitch(comments, accent) { comments = it } }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                    }

                    // ---- note, only for polls
                    if (mode == "poll") {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(CpOrangeSoft)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Info, null, tint = CpOrange, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Once a poll is posted, it can't be edited later.",
                                color = Color(0xFF8A5A00), fontSize = 11.5.sp, fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDuration) {
        CpDurationDialog(duration, accent, onDismiss = { showDuration = false }) {
            duration = it
            showDuration = false
        }
    }
}
