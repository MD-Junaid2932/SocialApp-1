package com.junaid.social

import android.net.Uri

data class PollOption(val text: String, val votes: Int, val fixedPct: Int? = null)

data class Poll(
    val options: List<PollOption>,
    val selected: Int = -1,
    val daysLeft: Int = 2
) {
    val total: Int get() = options.sumOf { it.votes }

    fun pct(i: Int): Int {
        options[i].fixedPct?.let { return it }
        return if (total == 0) 0 else Math.round(options[i].votes * 100f / total)
    }
}

data class Comment(val author: String, val text: String)

data class Post(
    val id: Long,
    val author: String,
    val avatarRes: Int,
    val time: String,
    val text: String,
    val imageRes: Int? = null,
    val imageUri: Uri? = null,
    val poll: Poll? = null,
    val verified: Boolean = false,
    val mine: Boolean = false,
    val following: Boolean = true,
    val liked: Boolean = false,
    val likes: Int = 0,
    val comments: List<Comment> = emptyList(),
    val commentCount: Int = 0,
    val shares: Int = 0,
    val bookmarked: Boolean = false,
    val hidden: Boolean = false
)

data class Story(val name: String, val avatarRes: Int)

enum class FeedFilter { All, Following, Text, Image, Poll }

fun sampleStories(): List<Story> = listOf(
    Story("Md. Arif", R.drawable.s_arif),
    Story("Nusrat", R.drawable.s_nusrat),
    Story("Jannat", R.drawable.s_jannat),
    Story("Mim", R.drawable.s_mim),
    Story("Rafi", R.drawable.s_rafi)
)

fun samplePosts(): List<Post> = listOf(
    Post(
        id = 1,
        author = "Rakib Hasan",
        avatarRes = R.drawable.a_rakib,
        time = "2 hours ago",
        text = "জীবনের প্রতিটি মুহূর্তই একটা নতুন পর্ব\nসেই পর্বে দাঁড়ালে তই হয় মুসম, আর সেটা না পারলে তা হয়\nশুধু তুমি হয়ে যাস! ✨",
        imageRes = R.drawable.post1,
        verified = true,
        mine = true,
        liked = true,
        likes = 342,
        commentCount = 48,
        shares = 22,
        comments = listOf(
            Comment("Sadia Islam", "দারুণ লাগছে! 😍"),
            Comment("Md. Arif", "ছবিটা অসাধারণ ভাই 🔥"),
            Comment("Nusrat", "সুন্দর কথা ❤️")
        )
    ),
    Post(
        id = 2,
        author = "Sadia Islam",
        avatarRes = R.drawable.a_sadia,
        time = "5 hours ago",
        text = "আজ একটা নতুন গল্প লিখতে শুরু করলাম।\nকি হবে সেটা জানি না, তবে একটা বেশ ভালো লাগছে! 😊",
        imageRes = R.drawable.post2,
        likes = 198,
        commentCount = 35,
        shares = 12,
        comments = listOf(
            Comment("Jannat", "শুভকামনা রইল ✍️"),
            Comment("Rafi", "গল্প শেষ হলে পড়তে চাই!")
        )
    ),
    Post(
        id = 3,
        author = "Tania Akter",
        avatarRes = R.drawable.a_tania,
        time = "12 hours ago",
        text = "তোমার সঙ্গে, জীবনের সবচেয়ে গুরুত্বপূর্ণ জিনিস কোনটি?",
        poll = Poll(
            options = listOf(
                PollOption("জ্ঞান / পরিশ্রম", 342, 42),
                PollOption("ভালোবাসা", 298, 24),
                PollOption("বন্ধু", 189, 18),
                PollOption("টাকা / আর্থিক স্বাধীনতা", 142, 16)
            ),
            selected = -1,
            daysLeft = 2
        ),
        liked = true,
        likes = 134,
        commentCount = 46,
        shares = 18
    ),
    Post(
        id = 4,
        author = "Rofiul Islam",
        avatarRes = R.drawable.a_rofiul,
        time = "14 hours ago",
        text = "নতুন দিন, নতুন স্বপ্ন। সবাইকে শুভ সকাল! 🌤️",
        likes = 87,
        commentCount = 12,
        shares = 4,
        following = false
    )
)
