package com.junaid.social

data class PollOption(val text: String, val votes: Int, val fixedPct: Int? = null)

data class Poll(
    val options: List<PollOption>,
    val selected: Int = -1,
    val daysLeft: Int = 2,
    val ended: Boolean = false
) {
    val total: Int get() = options.sumOf { it.votes }

    fun pct(i: Int): Int {
        options[i].fixedPct?.let { return it }
        return if (total == 0) 0 else Math.round(options[i].votes * 100f / total)
    }
}

data class Comment(val id: String, val authorUid: String, val author: String, val text: String)

data class Post(
    val id: String,
    val authorUid: String,
    val author: String,
    val authorPhoto: String?,
    val createdAt: Long,
    val text: String,
    val imageB64: String? = null,
    val imageUrl: String? = null,
    val poll: Poll? = null,
    val verified: Boolean = false,
    val mine: Boolean = false,
    val following: Boolean = false,
    val liked: Boolean = false,
    val likes: Int = 0,
    val commentCount: Int = 0,
    val shares: Int = 0,
    val bookmarked: Boolean = false
)

enum class FeedFilter { All, Following, Text, Image, Poll }

/** One page of a story. Either text on a gradient, or a picture (drawable for demo, uri for the user's own). */
data class StoryItem(
    val text: String? = null,
    val imageRes: Int? = null,
    val imageUri: String? = null,
    val bgFrom: Long = 0xFF2E8BFA,
    val bgTo: Long = 0xFF0B63E0,
    val minutesAgo: Int = 0
)

/** All the pages one person has posted. [mine] marks the signed-in user's own story. */
data class Story(
    val id: String,
    val name: String,
    val avatarRes: Int? = null,
    val avatarUrl: String? = null,
    val items: List<StoryItem>,
    val mine: Boolean = false
)

/** Background gradients (top colour, bottom colour) offered when writing a text story. */
val StoryGradients: List<Pair<Long, Long>> = listOf(
    0xFF2E8BFA to 0xFF0B63E0,
    0xFFFF9A44 to 0xFFFC4A7D,
    0xFF8E4EC6 to 0xFF4A3AFF,
    0xFF13A152 to 0xFF0891B2,
    0xFFF76B15 to 0xFFE5484D,
    0xFF2B2F3A to 0xFF0B0D12
)

// DEMO stories. Replace with online data later.
fun sampleStories(): List<Story> = listOf(
    Story(
        id = "arif", name = "Md. Arif", avatarRes = R.drawable.s_arif,
        items = listOf(
            StoryItem(text = "আজকের সকালটা কত সুন্দর! ☀️", bgFrom = 0xFFFF9A44, bgTo = 0xFFFC4A7D, minutesAgo = 25),
            StoryItem(imageRes = R.drawable.post1, bgFrom = 0xFF1B2B4B, bgTo = 0xFF0B1220, minutesAgo = 22)
        )
    ),
    Story(
        id = "nusrat", name = "Nusrat", avatarRes = R.drawable.s_nusrat,
        items = listOf(
            StoryItem(text = "একটা ভালো বই, এক কাপ চা আর বৃষ্টির দিন 📚☕", bgFrom = 0xFF2E8BFA, bgTo = 0xFF0B63E0, minutesAgo = 180),
            StoryItem(imageRes = R.drawable.post2, bgFrom = 0xFF2B2F3A, bgTo = 0xFF0B0D12, minutesAgo = 170)
        )
    ),
    Story(
        id = "jannat", name = "Jannat", avatarRes = R.drawable.s_jannat,
        items = listOf(
            StoryItem(text = "নতুন গল্পের প্রথম অধ্যায় লিখে ফেললাম ✍️", bgFrom = 0xFF8E4EC6, bgTo = 0xFF4A3AFF, minutesAgo = 45)
        )
    ),
    Story(
        id = "mim", name = "Mim", avatarRes = R.drawable.s_mim,
        items = listOf(
            StoryItem(text = "Dream. Learn. Grow. 🌱", bgFrom = 0xFF13A152, bgTo = 0xFF0891B2, minutesAgo = 600),
            StoryItem(text = "পড়তে থাকো, স্বপ্ন দেখতে থাকো", bgFrom = 0xFFF76B15, bgTo = 0xFFE5484D, minutesAgo = 590)
        )
    ),
    Story(
        id = "rafi", name = "Rafi", avatarRes = R.drawable.s_rafi,
        items = listOf(
            StoryItem(imageRes = R.drawable.post1, text = "পাহাড়ের চূড়ায় ⛰️", bgFrom = 0xFF1B2B4B, bgTo = 0xFF0B1220, minutesAgo = 75)
        )
    )
)
