package com.junaid.social

data class PollOption(val text: String, val votes: Int, val fixedPct: Int? = null)

data class Poll(
    val options: List<PollOption>,
    val selected: Int = -1,
    val daysLeft: Int = 2,
    val ended: Boolean = false
) {
    val total: Int get() = options.sumOf { it.votes }

    fun pct(i: Int): Int {
        options[i].fixedPct?.let { return it }
        return if (total == 0) 0 else Math.round(options[i].votes * 100f / total)
    }
}

data class Comment(val id: String, val authorUid: String, val author: String, val text: String)

data class Post(
    val id: String,
    val authorUid: String,
    val author: String,
    val authorPhoto: String?,
    val createdAt: Long,
    val text: String,
    val imageB64: String? = null,
    val imageUrl: String? = null,
    val poll: Poll? = null,
    val verified: Boolean = false,
    val mine: Boolean = false,
    val following: Boolean = false,
    val liked: Boolean = false,
    val likes: Int = 0,
    val commentCount: Int = 0,
    val shares: Int = 0,
    val bookmarked: Boolean = false
)

data class Story(val name: String, val avatarRes: Int)

enum class FeedFilter { All, Following, Text, Image, Poll }

fun sampleStories(): List<Story> = listOf(
    Story("Md. Arif", R.drawable.s_arif),
    Story("Nusrat", R.drawable.s_nusrat),
    Story("Jannat", R.drawable.s_jannat),
    Story("Mim", R.drawable.s_mim),
    Story("Rafi", R.drawable.s_rafi)
)
