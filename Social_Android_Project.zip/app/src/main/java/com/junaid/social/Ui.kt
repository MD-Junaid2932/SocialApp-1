package com.junaid.social

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- colours / fonts

val Blue = Color(0xFF1F78F4)
val Ink = Color(0xFF14171F)
val Grey = Color(0xFF7C8594)
val HeartRed = Color(0xFFFD404E)
val TagBg = Color(0xFFE6F1FE)
val TagText = Color(0xFF0F6BF5)
val BookmarkYellow = Color(0xFFFFC517)
val TitleInk = Color(0xFF000002)
val CountInk = Color(0xFF00000B)
val PostInk = Color(0xFF000118)
val TimeGrey = Color(0xFF37405A)
val SubGrey = Color(0xFF5F6878)
val PlaceholderGrey = Color(0xFF808898)
val PollMeta = Color(0xFF5B698B)
val PollVotes = Color(0xFF4D6287)
val PollRowBorder = Color(0xFFA4B3D3)
val PollBoxBorder = Color(0xFF7A8AAB)
val PollTrack = Color(0xFFDFE8F6)

val OutfitFamily = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_medium, FontWeight.Medium),
    Font(R.font.outfit_semibold, FontWeight.SemiBold),
    Font(R.font.outfit_bold, FontWeight.Bold),
    Font(R.font.outfit_bold, FontWeight.ExtraBold)
)

// ---------------------------------------------------------------- icons (thin line set)

private fun vec(
    name: String,
    d: String,
    width: Float = 1.8f,
    fill: Boolean = false
): ImageVector = ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).addPath(
    pathData = PathParser().parsePathString(d).toNodes(),
    fill = if (fill) SolidColor(Color.Black) else null,
    stroke = SolidColor(Color.Black),
    strokeLineWidth = width,
    strokeLineCap = StrokeCap.Round,
    strokeLineJoin = StrokeJoin.Round
).build()

private fun circ(cx: Float, cy: Float, r: Float) =
    "M${cx - r} ${cy}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"

private fun rrect(x: Float, y: Float, w: Float, h: Float, r: Float) =
    "M${x + r} ${y}h${w - 2 * r}a$r $r 0 0 1 $r $r v${h - 2 * r}a$r $r 0 0 1 -$r $r h${-(w - 2 * r)}a$r $r 0 0 1 -$r -$r v${-(h - 2 * r)}a$r $r 0 0 1 $r -${r}z"

val ISearch = vec("search", circ(11f, 11f, 7.5f) + "M21 21l-4.6-4.6")
val IBell = vec("bell", "M18 8.5a6 6 0 0 0-12 0c0 6.5-2.8 8.5-2.8 8.5h17.6S18 15 18 8.5M13.8 20.8a2 2 0 0 1-3.6 0")
val IGrid = vec("grid", rrect(3.5f, 3.5f, 7f, 7f, 1.8f) + rrect(13.5f, 3.5f, 7f, 7f, 1.8f) + rrect(3.5f, 13.5f, 7f, 7f, 1.8f) + rrect(13.5f, 13.5f, 7f, 7f, 1.8f), 1.9f)
val IUsers = vec("users", circ(9f, 8f, 3.8f) + "M2.5 20v-1.2a4.5 4.5 0 0 1 4.5-4.5h4a4.5 4.5 0 0 1 4.5 4.5V20M16 4.4a3.8 3.8 0 0 1 0 7.2M21.5 20v-1.2a4.5 4.5 0 0 0-3-4.2", 1.9f)
val IText = vec("text", "M4 6h16M4 12h16M4 18h10", 1.9f)
val IImage = vec("image", rrect(3f, 3f, 18f, 18f, 3f) + circ(9f, 9f, 1.8f) + "M21 16l-5.2-5.2L5 21.5", 1.9f)
val IBars = vec("bars", "M6 20v-7M12 20V5M18 20v-10", 1.9f)
val ITune = vec("tune", "M3 7h9M16 7h5M3 17h5M12 17h9" + circ(14f, 7f, 2.2f) + circ(10f, 17f, 2.2f), 1.9f)
val IPen = vec("pen", "M16.5 3.5a2.8 2.8 0 0 1 4 4L8 20 3 21.2 4.2 16zM14.5 5.5l4 4")
val IGlobe = vec("globe", circ(12f, 12f, 9f) + "M3 12h18M12 3c2.6 2.6 3.8 5.6 3.8 9s-1.2 6.4-3.8 9c-2.6-2.6-3.8-5.6-3.8-9S9.4 5.6 12 3z", 1.6f)
val IClock = vec("clock", circ(12f, 12f, 9f) + "M12 7v5.2l3.3 2", 1.7f)
val IPlus = vec("plus", "M12 4v16M4 12h16", 2.2f)
val IPlusFab = vec("plusfab", "M12 4v16M4 12h16", 2.4f)
val ICheck = vec("check", "M4.5 12.5l5 5 10-11", 3.4f)
val IHeart = vec("heart", "M12 20.8S3 15.2 3 8.9A4.9 4.9 0 0 1 12 6.2a4.9 4.9 0 0 1 9 2.7c0 6.3-9 11.9-9 11.9z")
val IHeartFill = vec("heartfill", "M12 20.8S3 15.2 3 8.9A4.9 4.9 0 0 1 12 6.2a4.9 4.9 0 0 1 9 2.7c0 6.3-9 11.9-9 11.9z", fill = true)
val IChat = vec("chat", "M6 3.5h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3h-6.2l-4.8 3.8v-3.8H6a3 3 0 0 1-3-3v-8a3 3 0 0 1 3-3z")
val IShare = vec("share", "M14 4.2l7.5 7.3L14 18.8v-4.3c-5.8-.1-9 1.8-11 5.5.6-6.8 4.4-10.6 11-11z")
val IBookmark = vec("bookmark", "M6 3.5h12a1 1 0 0 1 1 1V21l-7-5-7 5V4.5a1 1 0 0 1 1-1z", 1.7f)
val IBookmarkFill = vec("bookmarkfill", "M6 3.5h12a1 1 0 0 1 1 1V21l-7-5-7 5V4.5a1 1 0 0 1 1-1z", 1.7f, fill = true)
val IWallet = vec("wallet", "M4 7.5A2.5 2.5 0 0 1 6.5 5H18v3" + rrect(3f, 7.5f, 18f, 12.5f, 2.8f) + "M16 14h2.5", 1.7f)
val IHome = vec("home", "M3.5 11.2L12 3.5l8.5 7.7V20a1 1 0 0 1-1 1H15v-6H9v6H4.5a1 1 0 0 1-1-1z", 1.7f)
val IBook = vec("book", "M12 6.5C10 4.8 7 4.2 3.5 4.5v13.5c3.5-.3 6.5.3 8.5 2 2-1.7 5-2.3 8.5-2V4.5C17 4.2 14 4.8 12 6.5zM12 6.5V20", 1.7f)
val IUser = vec("user", circ(12f, 8f, 4f) + "M4.5 21v-1a6 6 0 0 1 6-6h3a6 6 0 0 1 6 6v1", 1.7f)
val IUsersNav = vec("usersnav", circ(9f, 8f, 3.8f) + "M2.5 20v-1.2a4.5 4.5 0 0 1 4.5-4.5h4a4.5 4.5 0 0 1 4.5 4.5V20M16 4.4a3.8 3.8 0 0 1 0 7.2M21.5 20v-1.2a4.5 4.5 0 0 0-3-4.2", 1.7f)

// ---- solid (filled) icons used by the bottom navigation
private fun fvec(name: String, d: String, evenOdd: Boolean = false): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).addPath(
        pathData = PathParser().parsePathString(d).toNodes(),
        fill = SolidColor(Color.Black),
        pathFillType = if (evenOdd) androidx.compose.ui.graphics.PathFillType.EvenOdd
        else androidx.compose.ui.graphics.PathFillType.NonZero
    ).build()

val INavSocial = fvec(
    "navsocial",
    circ(16.3f, 7.1f, 4.1f) +
        "M7.7 20.8c0-4.3 3.6-7.5 8.15-7.5s8.15 3.2 8.15 7.5z" +
        circ(6.2f, 9.5f, 2.6f) +
        "M0.3 20.8c0-3.6 2.2-6.1 5.6-6.1.5 0 .9.1 1.3.2-1.2 1.3-1.9 3.3-1.9 5.9z"
)
val INavWallet = fvec(
    "navwallet",
    "M2.6 7.4L17.6 2.8l1.3.6.2 2-2.6-.2L6.4 7.9z" +
        "M4.7 7.6h14.1a3 3 0 0 1 3 3v7.6a3 3 0 0 1-3 3H4.7a3 3 0 0 1-3-3v-7.6a3 3 0 0 1 3-3z" +
        "M21.8 11.3h.3a1.2 1.2 0 0 1 1.2 1.2v3.3a1.2 1.2 0 0 1-1.2 1.2h-.3z" +
        circ(17.4f, 14.4f, 1.3f),
    evenOdd = true
)
val INavHome = fvec(
    "navhome",
    "M12 3.2c.45 0 .9.15 1.25.45l6.6 5.5c.7.6 1.1 1.4 1.1 2.3v7.5c0 1.1-.9 2-2 2h-3.9v-5.2c0-.9-.7-1.6-1.6-1.6h-2.9c-.9 0-1.6.7-1.6 1.6v5.2H5.1c-1.1 0-2-.9-2-2v-7.5c0-.9.4-1.7 1.1-2.3l6.6-5.5c.35-.3.8-.45 1.25-.45z"
)
val INavBook = fvec(
    "navbook",
    "M2.4 5.6C5.6 4.8 9 5.1 11.2 6.9V19.4C9 17.9 5.6 17.7 2.4 18.4z" +
        "M21.6 5.6C18.4 4.8 15 5.1 12.8 6.9V19.4C15 17.9 18.4 17.7 21.6 18.4z"
)
val INavUser = fvec(
    "navuser",
    circ(12f, 6.6f, 4.2f) +
        "M3 20.4c0-3.8 4-6.7 9-6.7s9 2.9 9 6.7c0 .6-.5 1.1-1.1 1.1H4.1C3.5 21.5 3 21 3 20.4z"
)

/** Scalloped blue verified badge with a white rounded tick. Draw with tint = Color.Unspecified. */
val IVerified: ImageVector = ImageVector.Builder("verified", 24.dp, 24.dp, 100f, 100f)
    .addPath(
        pathData = PathParser().parsePathString("M50.00 2.40 L51.24 2.54 L52.47 2.96 L53.65 3.62 L54.79 4.45 L55.87 5.38 L56.91 6.35 L57.92 7.26 L58.92 8.04 L59.93 8.65 L60.97 9.04 L62.08 9.22 L63.26 9.20 L64.51 9.02 L65.84 8.74 L67.22 8.43 L68.63 8.16 L70.03 8.00 L71.38 8.03 L72.65 8.28 L73.80 8.78 L74.80 9.52 L75.65 10.50 L76.35 11.65 L76.92 12.94 L77.39 14.30 L77.81 15.65 L78.23 16.94 L78.70 18.12 L79.27 19.15 L79.98 20.02 L80.85 20.73 L81.88 21.30 L83.06 21.77 L84.35 22.19 L85.70 22.61 L87.06 23.08 L88.35 23.65 L89.50 24.35 L90.48 25.20 L91.22 26.20 L91.72 27.35 L91.97 28.62 L92.00 29.97 L91.84 31.37 L91.57 32.78 L91.26 34.16 L90.98 35.49 L90.80 36.74 L90.78 37.92 L90.96 39.03 L91.35 40.07 L91.96 41.08 L92.74 42.08 L93.65 43.09 L94.62 44.13 L95.55 45.21 L96.38 46.35 L97.04 47.53 L97.46 48.76 L97.60 50.00 L97.46 51.24 L97.04 52.47 L96.38 53.65 L95.55 54.79 L94.62 55.87 L93.65 56.91 L92.74 57.92 L91.96 58.92 L91.35 59.93 L90.96 60.97 L90.78 62.08 L90.80 63.26 L90.98 64.51 L91.26 65.84 L91.57 67.22 L91.84 68.63 L92.00 70.03 L91.97 71.38 L91.72 72.65 L91.22 73.80 L90.48 74.80 L89.50 75.65 L88.35 76.35 L87.06 76.92 L85.70 77.39 L84.35 77.81 L83.06 78.23 L81.88 78.70 L80.85 79.27 L79.98 79.98 L79.27 80.85 L78.70 81.88 L78.23 83.06 L77.81 84.35 L77.39 85.70 L76.92 87.06 L76.35 88.35 L75.65 89.50 L74.80 90.48 L73.80 91.22 L72.65 91.72 L71.38 91.97 L70.03 92.00 L68.63 91.84 L67.22 91.57 L65.84 91.26 L64.51 90.98 L63.26 90.80 L62.08 90.78 L60.97 90.96 L59.93 91.35 L58.92 91.96 L57.92 92.74 L56.91 93.65 L55.87 94.62 L54.79 95.55 L53.65 96.38 L52.47 97.04 L51.24 97.46 L50.00 97.60 L48.76 97.46 L47.53 97.04 L46.35 96.38 L45.21 95.55 L44.13 94.62 L43.09 93.65 L42.08 92.74 L41.08 91.96 L40.07 91.35 L39.03 90.96 L37.92 90.78 L36.74 90.80 L35.49 90.98 L34.16 91.26 L32.78 91.57 L31.37 91.84 L29.97 92.00 L28.62 91.97 L27.35 91.72 L26.20 91.22 L25.20 90.48 L24.35 89.50 L23.65 88.35 L23.08 87.06 L22.61 85.70 L22.19 84.35 L21.77 83.06 L21.30 81.88 L20.73 80.85 L20.02 79.98 L19.15 79.27 L18.12 78.70 L16.94 78.23 L15.65 77.81 L14.30 77.39 L12.94 76.92 L11.65 76.35 L10.50 75.65 L9.52 74.80 L8.78 73.80 L8.28 72.65 L8.03 71.38 L8.00 70.03 L8.16 68.63 L8.43 67.22 L8.74 65.84 L9.02 64.51 L9.20 63.26 L9.22 62.08 L9.04 60.97 L8.65 59.93 L8.04 58.92 L7.26 57.92 L6.35 56.91 L5.38 55.87 L4.45 54.79 L3.62 53.65 L2.96 52.47 L2.54 51.24 L2.40 50.00 L2.54 48.76 L2.96 47.53 L3.62 46.35 L4.45 45.21 L5.38 44.13 L6.35 43.09 L7.26 42.08 L8.04 41.08 L8.65 40.07 L9.04 39.03 L9.22 37.92 L9.20 36.74 L9.02 35.49 L8.74 34.16 L8.43 32.78 L8.16 31.37 L8.00 29.97 L8.03 28.62 L8.28 27.35 L8.78 26.20 L9.52 25.20 L10.50 24.35 L11.65 23.65 L12.94 23.08 L14.30 22.61 L15.65 22.19 L16.94 21.77 L18.12 21.30 L19.15 20.73 L20.02 20.02 L20.73 19.15 L21.30 18.12 L21.77 16.94 L22.19 15.65 L22.61 14.30 L23.08 12.94 L23.65 11.65 L24.35 10.50 L25.20 9.52 L26.20 8.78 L27.35 8.28 L28.62 8.03 L29.97 8.00 L31.37 8.16 L32.78 8.43 L34.16 8.74 L35.49 9.02 L36.74 9.20 L37.92 9.22 L39.03 9.04 L40.07 8.65 L41.08 8.04 L42.08 7.26 L43.09 6.35 L44.13 5.38 L45.21 4.45 L46.35 3.62 L47.53 2.96 L48.76 2.54 Z").toNodes(),
        fill = SolidColor(Color(0xFF4A80F5))
    )
    .addPath(
        pathData = PathParser().parsePathString("M28.5 49.5L44.5 64.5L70 37.5").toNodes(),
        stroke = SolidColor(Color.White),
        strokeLineWidth = 11f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round
    )
    .build()

// ---------------------------------------------------------------- helpers

internal fun loadBitmap(ctx: android.content.Context, uri: Uri, maxDim: Int = 2048): Bitmap? {
    val resolver = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxDim) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
    val orientation = try {
        resolver.openInputStream(uri)?.use {
            android.media.ExifInterface(it).getAttributeInt(
                android.media.ExifInterface.TAG_ORIENTATION,
                android.media.ExifInterface.ORIENTATION_NORMAL
            )
        } ?: android.media.ExifInterface.ORIENTATION_NORMAL
    } catch (e: Exception) {
        android.media.ExifInterface.ORIENTATION_NORMAL
    }
    val m = android.graphics.Matrix()
    when (orientation) {
        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
        android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        else -> return bmp
    }
    return try {
        Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    } catch (e: Exception) {
        bmp
    }
}

@Composable
fun rememberUriBitmap(uri: Uri?): ImageBitmap? {
    val ctx = LocalContext.current
    val state = produceState<ImageBitmap?>(initialValue = null, uri) {
        value = if (uri == null) null else withContext(Dispatchers.IO) {
            try {
                loadBitmap(ctx, uri)?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    return state.value
}

@Composable
fun Avatar(res: Int, size: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(res),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.size(size).clip(CircleShape)
    )
}

private val AvatarColors = listOf(
    Color(0xFF1F78F4), Color(0xFF13A152), Color(0xFFE5484D), Color(0xFF8E4EC6), Color(0xFFF76B15), Color(0xFF0891B2)
)

/** Profile photo when there is one, otherwise a coloured circle with the first letter of the name. */
@Composable
fun UserAvatar(photo: String?, name: String, size: Dp, modifier: Modifier = Modifier) {
    if (!photo.isNullOrBlank()) {
        AsyncImage(
            model = photo,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier.size(size).clip(CircleShape).background(Color(0xFFE3EAF3))
        )
    } else {
        val c = AvatarColors[(name.hashCode() and 0x7fffffff) % AvatarColors.size]
        Box(modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
            Text(
                name.trim().take(1).uppercase(),
                color = Color.White,
                fontSize = (size.value * 0.42f).sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

fun relTime(ms: Long): String {
    val d = (System.currentTimeMillis() - ms) / 1000
    return when {
        d < 60 -> "Just now"
        d < 3600 -> "${d / 60} min ago"
        d < 7200 -> "1 hour ago"
        d < 86400 -> "${d / 3600} hours ago"
        d < 172800 -> "1 day ago"
        else -> "${d / 86400} days ago"
    }
}

private fun decodeB64(b: String): ImageBitmap? = try {
    val bytes = android.util.Base64.decode(b, android.util.Base64.DEFAULT)
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
} catch (e: Exception) {
    null
}

// ---------------------------------------------------------------- Top bar (height 38)

@Composable
fun TopBar(
    searching: Boolean,
    query: String,
    unread: Boolean,
    userName: String,
    userPhoto: String?,
    onQuery: (String) -> Unit,
    onSearchToggle: () -> Unit,
    onBell: () -> Unit,
    onProfile: () -> Unit
) {
    Row(
        modifier = Modifier
            .statusBarsPadding()
            .fillMaxWidth()
            .height(38.dp)
            .padding(start = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (searching) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE8EDF5), RoundedCornerShape(18.dp))
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) Text("খুঁজুন...", color = Grey, fontSize = 14.sp)
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = Ink, fontSize = 14.sp),
                    cursorBrush = SolidColor(Blue),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(36.dp).clickable(onClick = onSearchToggle), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
        } else {
            Spacer(Modifier.width(2.dp))
            Image(
                painter = painterResource(R.drawable.logo_flower),
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.width(10.5.dp))
            Column {
                Text(
                    "Social",
                    color = TitleInk,
                    fontSize = 16.5.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 18.sp
                )
                Text(
                    "Connect  ·  Share  ·  Grow",
                    color = SubGrey,
                    fontSize = 9.7.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.1.sp,
                    lineHeight = 12.sp,
                    modifier = Modifier.offset(y = (-0.8).dp)
                )
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(33.dp).clickable(onClick = onSearchToggle), contentAlignment = Alignment.Center) {
                Icon(ISearch, null, tint = Ink, modifier = Modifier.size(17.dp))
            }
            Box(Modifier.size(33.dp).clickable(onClick = onBell), contentAlignment = Alignment.Center) {
                Box(Modifier.size(17.dp)) {
                    Icon(IBell, null, tint = Ink, modifier = Modifier.size(17.dp))
                    if (unread) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 1.dp, end = 3.5.dp)
                                .size(5.5.dp)
                                .clip(CircleShape)
                                .background(HeartRed)
                        )
                    }
                }
            }
            Spacer(Modifier.width(7.5.dp))
            UserAvatar(userPhoto, userName, 30.dp, Modifier.clickable(onClick = onProfile))
        }
    }
}

// ---------------------------------------------------------------- Stories (6 equal slots of 65)

@Composable
fun StoriesRow(stories: List<Story>, onCreate: () -> Unit, onStory: (Story) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.weight(1f).clickable(onClick = onCreate),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(47.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFDCEBFD))
                    .border(1.2.dp, Color(0xFFA9C9F4), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(IPlus, null, tint = Blue, modifier = Modifier.size(21.dp))
            }
            Spacer(Modifier.height(5.dp))
            Text("Create", color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium, lineHeight = 14.sp)
        }
        stories.forEach { s ->
            Column(
                modifier = Modifier.weight(1f).clickable { onStory(s) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Avatar(s.avatarRes, 47.dp)
                Spacer(Modifier.height(5.dp))
                Text(
                    s.name,
                    color = Ink,
                    fontSize = 10.2.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Chips (6 in one row, no scrolling)

@Composable
fun FeedChip(label: String?, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(11.dp)
    val bg = if (selected) Brush.horizontalGradient(listOf(Color(0xFF2B86F7), Color(0xFF0F6BEF)))
    else SolidColor(Color.White)
    Row(
        modifier = Modifier
            .height(29.5.dp)
            .shadow(
                if (selected) 3.dp else 1.5.dp, shape, clip = false,
                ambientColor = Color(0x331F78F4), spotColor = Color(0x331F78F4)
            )
            .clip(shape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = if (label == null) 7.dp else 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (selected) Color.White else Ink, modifier = Modifier.size(15.dp))
        if (label != null) {
            Spacer(Modifier.width(4.5.dp))
            Text(
                label,
                color = if (selected) Color.White else Ink,
                fontSize = 11.1.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
            )
        }
    }
}

@Composable
fun ChipsRow(
    selected: FeedFilter,
    sortPopular: Boolean,
    onSelect: (FeedFilter) -> Unit,
    onSort: (Boolean) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        FeedChip("All", IGrid, selected == FeedFilter.All) { onSelect(FeedFilter.All) }
        FeedChip("Following", IUsers, selected == FeedFilter.Following) { onSelect(FeedFilter.Following) }
        FeedChip("Text", IText, selected == FeedFilter.Text) { onSelect(FeedFilter.Text) }
        FeedChip("Image", IImage, selected == FeedFilter.Image) { onSelect(FeedFilter.Image) }
        FeedChip("Poll", IBars, selected == FeedFilter.Poll) { onSelect(FeedFilter.Poll) }
        Box {
            FeedChip(null, ITune, false) { menu = true }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(if (!sortPopular) "✓  নতুন আগে" else "নতুন আগে") },
                    onClick = { onSort(false); menu = false }
                )
                DropdownMenuItem(
                    text = { Text(if (sortPopular) "✓  জনপ্রিয় আগে" else "জনপ্রিয় আগে") },
                    onClick = { onSort(true); menu = false }
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Composer (372 x 47)

@Composable
fun Composer(userName: String, userPhoto: String?, onText: () -> Unit, onImage: () -> Unit, onPoll: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Surface(
        shape = shape,
        color = Color.White,
        shadowElevation = 1.dp,
        modifier = Modifier.padding(horizontal = 9.dp).fillMaxWidth().height(47.dp)
    ) {
        Row(
            modifier = Modifier.padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(userPhoto, userName, 35.dp)
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .width(193.dp)
                    .height(32.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF3F6FA))
                    .clickable(onClick = onText)
                    .padding(start = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text("Your canvas, your words...", color = PlaceholderGrey, fontSize = 14.3.sp, maxLines = 1)
            }
            Spacer(Modifier.width(20.dp))
            Box(Modifier.size(21.dp).clickable(onClick = onImage)) { Icon(IImage, null, tint = Ink, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.width(16.dp))
            Box(Modifier.size(21.dp).clickable(onClick = onPoll)) { Icon(IBars, null, tint = Ink, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.width(14.dp))
            Box(Modifier.size(20.dp).clickable(onClick = onText)) { Icon(IPen, null, tint = Ink, modifier = Modifier.size(20.dp)) }
        }
    }
}

// ---------------------------------------------------------------- Post card

class PostActions(
    val like: (String) -> Unit,
    val comment: (String) -> Unit,
    val share: (String) -> Unit,
    val bookmark: (String) -> Unit,
    val vote: (String, Int) -> Unit,
    val copy: (String) -> Unit,
    val hide: (String) -> Unit,
    val delete: (String) -> Unit,
    val follow: (String) -> Unit
)

@Composable
fun Tag(text: String, icon: ImageVector? = null) {
    Row(
        modifier = Modifier
            .height(16.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(TagBg)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = TagText, modifier = Modifier.size(9.5.dp))
            Spacer(Modifier.width(3.5.dp))
        }
        Text(text, color = TagText, fontSize = 9.9.sp, fontWeight = FontWeight.Medium, lineHeight = 12.sp)
    }
}

@Composable
fun ActionItem(icon: ImageVector, tint: Color, count: Int, onClick: () -> Unit) {
    Row(
        modifier = Modifier.clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.3.dp))
        Text(
            count.toString(), color = CountInk, fontSize = 11.2.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.offset(y = (-1).dp)
        )
    }
}

@Composable
fun ActionRow(post: Post, actions: PostActions) {
    Row(
        modifier = Modifier.fillMaxWidth().height(22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ActionItem(if (post.liked) IHeartFill else IHeart, if (post.liked) HeartRed else Ink, post.likes) { actions.like(post.id) }
        Spacer(Modifier.width(26.5.dp))
        ActionItem(IChat, Ink, post.commentCount) { actions.comment(post.id) }
        Spacer(Modifier.width(27.dp))
        ActionItem(IShare, Ink, post.shares) { actions.share(post.id) }
        Spacer(Modifier.weight(1f))
        Box(Modifier.padding(end = 2.dp).size(19.dp).clickable { actions.bookmark(post.id) }) {
            Icon(
                if (post.bookmarked) IBookmarkFill else IBookmark, null,
                tint = if (post.bookmarked) BookmarkYellow else Ink,
                modifier = Modifier.size(19.dp)
            )
        }
    }
}

@Composable
fun PostCard(post: Post, actions: PostActions, modifier: Modifier = Modifier) {
    var menu by remember { mutableStateOf(false) }
    var pending by remember(post.id) { mutableStateOf(-1) }
    val shape = RoundedCornerShape(16.dp)
    Surface(
        shape = shape,
        color = Color.White,
        shadowElevation = 1.dp,
        border = if (post.mine) BorderStroke(1.dp, Blue) else BorderStroke(0.6.dp, Color(0xFFE8EEF6)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 11.dp)) {
            // ---- header
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(post.authorPhoto, post.author, 36.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f).height(36.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(post.author, color = PostInk, fontSize = 14.5.sp, fontWeight = FontWeight.Medium, lineHeight = 17.sp)
                        if (post.verified) {
                            Spacer(Modifier.width(7.dp))
                            Icon(IVerified, null, tint = Color.Unspecified, modifier = Modifier.size(12.dp))
                        }
                        if (post.mine) {
                            Spacer(Modifier.width(6.dp))
                            Tag("My Post")
                        } else if (post.poll != null) {
                            Spacer(Modifier.width(6.dp))
                            Tag("Poll", IBars)
                        }
                    }
                    Spacer(Modifier.height(0.3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(relTime(post.createdAt), color = TimeGrey, fontSize = 11.7.sp, lineHeight = 12.sp)
                        Spacer(Modifier.width(4.dp))
                        Text("•", color = TimeGrey, fontSize = 9.sp, lineHeight = 12.sp)
                        Spacer(Modifier.width(4.dp))
                        Text("Public", color = TimeGrey, fontSize = 11.7.sp, lineHeight = 12.sp)
                        Spacer(Modifier.width(5.dp))
                        Icon(Icons.Outlined.Public, null, tint = Color(0xFF8A93A3), modifier = Modifier.size(13.dp))
                    }
                }
                Box {
                    Box(Modifier.size(24.dp).clickable { menu = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.MoreHoriz, null, tint = Ink, modifier = Modifier.size(20.dp))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("টেক্সট কপি করুন") }, onClick = { menu = false; actions.copy(post.id) })
                        DropdownMenuItem(text = { Text("পোস্ট লুকান") }, onClick = { menu = false; actions.hide(post.id) })
                        if (!post.mine) {
                            DropdownMenuItem(
                                text = { Text(if (post.following) "আনফলো করুন" else "ফলো করুন") },
                                onClick = { menu = false; actions.follow(post.id) }
                            )
                        }
                        if (post.mine) {
                            DropdownMenuItem(text = { Text("মুছে ফেলুন", color = HeartRed) }, onClick = { menu = false; actions.delete(post.id) })
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            if (post.text.isNotBlank()) {
                Text(
                    post.text,
                    color = PostInk,
                    fontSize = 15.sp,
                    lineHeight = 20.5.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // ---- image (shown in the user's own aspect ratio, never cropped)
            val b64Bmp by produceState<ImageBitmap?>(initialValue = null, post.imageB64) {
                value = post.imageB64?.let { b -> withContext(Dispatchers.Default) { decodeB64(b) } }
            }
            if (post.imageB64 != null || post.imageUrl != null) {
                Spacer(Modifier.height(7.dp))
                val loaded = b64Bmp
                if (post.imageUrl != null) {
                    AsyncImage(
                        model = post.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp))
                    )
                } else if (loaded != null) {
                    Image(
                        bitmap = loaded,
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp))
                    )
                } else {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(773f / 303f)
                            .clip(RoundedCornerShape(9.dp))
                            .background(Color(0xFFEFF3F8))
                    )
                }
            }

            // ---- poll
            if (post.poll != null) {
                val poll = post.poll
                val voted = poll.selected >= 0 || poll.ended
                val lead = poll.options.indices.maxByOrNull { poll.pct(it) } ?: -1
                Spacer(Modifier.height(7.dp))
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    poll.options.forEachIndexed { i, opt ->
                        val st = when {
                            voted && poll.selected == i -> PollState.Voted
                            !voted && pending == i -> PollState.Pending
                            else -> PollState.Normal
                        }
                        PollRow(
                            option = opt,
                            pct = poll.pct(i),
                            state = st,
                            lead = i == lead,
                            onClick = { if (!voted) pending = i },
                            onCancel = { pending = -1 },
                            onConfirm = { pending = -1; actions.vote(post.id, i) }
                        )
                    }
                }
                Spacer(Modifier.height(11.dp))
                Row(
                    modifier = Modifier.padding(start = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${poll.total} votes", color = PollMeta, fontSize = 12.sp)
                    Text("  •  ", color = PollMeta, fontSize = 12.sp)
                    Icon(IClock, null, tint = PollMeta, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (poll.ended) "Poll ended" else "${poll.daysLeft} days left", color = PollMeta, fontSize = 12.sp)
                }
                Spacer(Modifier.height(7.5.dp))
            } else {
                Spacer(Modifier.height(if (post.imageB64 != null || post.imageUrl != null) 8.5.dp else 11.dp))
            }

            ActionRow(post, actions)
        }
    }
}

private fun pollFill(pct: Int): Float {
    val xs = floatArrayOf(0f, 16f, 18f, 24f, 42f, 100f)
    val ys = floatArrayOf(0.02f, 0.16f, 0.19f, 0.26f, 0.39f, 1f)
    val p = pct.toFloat().coerceIn(0f, 100f)
    for (i in 1 until xs.size) {
        if (p <= xs[i]) {
            val t = (p - xs[i - 1]) / (xs[i] - xs[i - 1])
            return ys[i - 1] + t * (ys[i] - ys[i - 1])
        }
    }
    return 1f
}

enum class PollState { Normal, Pending, Voted }

@Composable
private fun ConfirmButton(label: String, icon: ImageVector, bg: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .height(30.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, lineHeight = 16.sp)
    }
}

@Composable
fun PollRow(
    option: PollOption,
    pct: Int,
    state: PollState,
    lead: Boolean,
    onClick: () -> Unit,
    onCancel: () -> Unit,
    onConfirm: () -> Unit
) {
    val shape = RoundedCornerShape(11.dp)
    val selected = state != PollState.Normal
    val strong = selected || lead
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(shape)
            .background(if (selected) Color(0xFFF5F9FF) else Color.White)
            .border(
                if (selected) 1.5.dp else 1.dp,
                if (selected) Blue else PollRowBorder,
                shape
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(45.dp)
                .clickable(enabled = state == PollState.Normal, onClick = onClick)
        ) {
            // checkbox
            val cbShape = RoundedCornerShape(5.dp)
            Box(
                modifier = Modifier
                    .padding(start = 12.dp, top = 14.dp)
                    .size(18.dp)
                    .clip(cbShape)
                    .background(if (state == PollState.Voted) Blue else Color.White)
                    .border(
                        if (state == PollState.Normal) 1.5.dp else 1.8.dp,
                        if (state == PollState.Normal) PollBoxBorder else Blue,
                        cbShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (state == PollState.Voted) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(12.dp))
            }
            // label + percentage on one baseline
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 42.dp, end = 13.dp, top = 10.dp)
            ) {
                Text(
                    option.text,
                    color = Color.Black,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).alignByBaseline()
                )
                Text(
                    "$pct%",
                    color = if (selected) Blue else Color.Black,
                    fontSize = 13.1.sp,
                    lineHeight = 18.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier.alignByBaseline()
                )
            }
            // bar
            Box(
                modifier = Modifier
                    .padding(start = 42.dp, top = 32.dp)
                    .width(214.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(PollTrack)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(pollFill(pct))
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            if (strong) Brush.horizontalGradient(listOf(Color(0xFF3C8DFF), Color(0xFF1F7AFC)))
                            else SolidColor(Color(0xFF75AEFD))
                        )
                )
            }
            // votes
            Text(
                "${option.votes} votes",
                color = PollVotes,
                fontSize = 10.8.sp,
                lineHeight = 12.sp,
                maxLines = 1,
                modifier = Modifier.align(Alignment.TopEnd).padding(end = 13.dp, top = 29.dp)
            )
        }
        if (state == PollState.Pending) {
            val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .drawBehind {
                        drawLine(
                            Color(0xFFB9D3F7),
                            Offset(0f, 0f),
                            Offset(size.width, 0f),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = dash
                        )
                    }
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Vote for this option?",
                    color = Ink,
                    fontSize = 12.5.sp,
                    lineHeight = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                ConfirmButton("Cancel", Icons.Filled.Close, Color(0xFFE5484D), onCancel)
                Spacer(Modifier.width(7.dp))
                ConfirmButton("Vote", Icons.Filled.Check, Color(0xFF1FAA5B), onConfirm)
            }
        }
    }
}


// ---------------------------------------------------------------- FAB + nav

@Composable
fun Fab(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .shadow(6.dp, CircleShape, clip = false, ambientColor = Blue, spotColor = Blue)
            .size(42.dp)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2E8BFA), Color(0xFF0B63E0))))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(IPlusFab, null, tint = Color.White, modifier = Modifier.size(21.dp))
    }
}

val NavLabels = listOf("Social", "Economy", "Home", "Library", "Profile")
val NavIcons: List<ImageVector> = listOf(INavSocial, INavWallet, INavHome, INavBook, INavUser)

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFFF7FBFF), Color(0xFFEDF4FD))))
    ) {
        Box(Modifier.fillMaxWidth().height(0.6.dp).background(Color(0xFFE3EAF4)))
        Row(
            modifier = Modifier.fillMaxWidth().height(49.dp)
        ) {
            NavLabels.forEachIndexed { i, label ->
                val active = i == selected
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onSelect(i) }
                        .padding(top = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(NavIcons[i], null, tint = if (active) Blue else Ink, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.height(1.dp))
                    Text(
                        label,
                        color = if (active) Blue else Ink,
                        fontSize = 8.1.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 10.sp
                    )
                    Spacer(Modifier.height(2.dp))
                    Box(
                        Modifier
                            .size(width = 14.dp, height = 2.5.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (active) Blue else Color(0xFFD3D9E2))
                    )
                }
                if (i < NavLabels.lastIndex) {
                    Box(
                        Modifier
                            .align(Alignment.Top)
                            .padding(top = 10.dp)
                            .width(0.6.dp)
                            .height(26.dp)
                            .background(Color(0xFFD9E2EE))
                    )
                }
            }
        }
        // the bar's background continues under the system navigation area
        Box(Modifier.navigationBarsPadding())
    }
}
