package com.junaid.social

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Indication
import androidx.compose.foundation.IndicationInstance
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- colours / fonts

val Blue = Color(0xFF1F78F4)
val Ink = Color(0xFF14171F)
val Grey = Color(0xFF7C8594)
val HeartRed = Color(0xFFFD404E)
val TagBg = Color(0xFFE3EFFE)
val TagText = Color(0xFF006AFD)
val BookmarkYellow = Color(0xFFFFC517)
val TitleInk = Color(0xFF000002)
val CountInk = Color(0xFF00000B)
val PostInk = Color(0xFF000118)
val TimeGrey = Color(0xFF37405A)
val SubGrey = Color(0xFF5F6878)
val PlaceholderGrey = Color(0xFF808898)
val PollMeta = Color(0xFF5B698B)
val PollVotes = Color(0xFF4D6287)
val PollRowBorder = Color(0xFFA4B3D3)
val PollBoxBorder = Color(0xFF7A8AAB)
val PollTrack = Color(0xFFDFE8F6)
val PollOptionBg = Color(0xFFF5F9FF)

val OutfitFamily = FontFamily(
    Font(R.font.outfit_regular, FontWeight.Normal),
    Font(R.font.outfit_medium, FontWeight.Medium),
    Font(R.font.outfit_semibold, FontWeight.SemiBold),
    Font(R.font.outfit_bold, FontWeight.Bold),
    Font(R.font.outfit_bold, FontWeight.ExtraBold)
)

// ---------------------------------------------------------------- icons (thin line set)

private fun vec(
    name: String,
    d: String,
    width: Float = 1.8f,
    fill: Boolean = false
): ImageVector = ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).addPath(
    pathData = PathParser().parsePathString(d).toNodes(),
    fill = if (fill) SolidColor(Color.Black) else null,
    stroke = SolidColor(Color.Black),
    strokeLineWidth = width,
    strokeLineCap = StrokeCap.Round,
    strokeLineJoin = StrokeJoin.Round
).build()

private fun circ(cx: Float, cy: Float, r: Float) =
    "M${cx - r} ${cy}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"

private fun rrect(x: Float, y: Float, w: Float, h: Float, r: Float) =
    "M${x + r} ${y}h${w - 2 * r}a$r $r 0 0 1 $r $r v${h - 2 * r}a$r $r 0 0 1 -$r $r h${-(w - 2 * r)}a$r $r 0 0 1 -$r -$r v${-(h - 2 * r)}a$r $r 0 0 1 $r -${r}z"

val ISearch = vec("search", circ(11f, 11f, 7.5f) + "M21 21l-4.6-4.6")
val IBell = vec("bell", "M18 8.5a6 6 0 0 0-12 0c0 6.5-2.8 8.5-2.8 8.5h17.6S18 15 18 8.5M13.8 20.8a2 2 0 0 1-3.6 0")
val IGrid = vec("grid", rrect(3.5f, 3.5f, 7f, 7f, 1.8f) + rrect(13.5f, 3.5f, 7f, 7f, 1.8f) + rrect(3.5f, 13.5f, 7f, 7f, 1.8f) + rrect(13.5f, 13.5f, 7f, 7f, 1.8f), 1.9f)
val IUsers = vec("users", circ(9f, 8f, 3.8f) + "M2.5 20v-1.2a4.5 4.5 0 0 1 4.5-4.5h4a4.5 4.5 0 0 1 4.5 4.5V20M16 4.4a3.8 3.8 0 0 1 0 7.2M21.5 20v-1.2a4.5 4.5 0 0 0-3-4.2", 1.9f)
val IText = vec("text", "M4 6h16M4 12h16M4 18h10", 1.9f)
val IImage = vec("image", rrect(3f, 3f, 18f, 18f, 3f) + circ(9f, 9f, 1.8f) + "M21 16l-5.2-5.2L5 21.5", 1.9f)
val IBars = vec("bars", "M6 20v-7M12 20V5M18 20v-10", 1.9f)
val ITune = vec("tune", "M3 7h9M16 7h5M3 17h5M12 17h9" + circ(14f, 7f, 2.2f) + circ(10f, 17f, 2.2f), 1.9f)
val IPen = vec("pen", "M16.5 3.5a2.8 2.8 0 0 1 4 4L8 20 3 21.2 4.2 16zM14.5 5.5l4 4")
val IGlobe = vec("globe", circ(12f, 12f, 9f) + "M3 12h18M12 3c2.6 2.6 3.8 5.6 3.8 9s-1.2 6.4-3.8 9c-2.6-2.6-3.8-5.6-3.8-9S9.4 5.6 12 3z", 1.6f)
val IClock = vec("clock", circ(12f, 12f, 9f) + "M12 7v5.2l3.3 2", 1.7f)
val IPlus = vec("plus", "M12 4v16M4 12h16", 2.2f)
val IPlusFab = vec("plusfab", "M12 4v16M4 12h16", 2.4f)
val ICheck = vec("check", "M4.5 12.5l5 5 10-11", 3.4f)
val IHeart = vec("heart", "M12 20.8S3 15.2 3 8.9A4.9 4.9 0 0 1 12 6.2a4.9 4.9 0 0 1 9 2.7c0 6.3-9 11.9-9 11.9z")
val IHeartFill = vec("heartfill", "M12 20.8S3 15.2 3 8.9A4.9 4.9 0 0 1 12 6.2a4.9 4.9 0 0 1 9 2.7c0 6.3-9 11.9-9 11.9z", fill = true)
val IChat = vec("chat", "M6 3.5h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3h-6.2l-4.8 3.8v-3.8H6a3 3 0 0 1-3-3v-8a3 3 0 0 1 3-3z")
val IShare = vec("share", "M14 4.2l7.5 7.3L14 18.8v-4.3c-5.8-.1-9 1.8-11 5.5.6-6.8 4.4-10.6 11-11z")
private const val BOOKMARK_PATH = "M7.7 3h8.6A2.2 2.2 0 0 1 18.5 5.2V21.2L12 16.6 5.5 21.2V5.2A2.2 2.2 0 0 1 7.7 3z"

val IBookmark = vec("bookmark", BOOKMARK_PATH, 1.7f)
val IBookmarkFill = vec("bookmarkfill", BOOKMARK_PATH, 1.7f, fill = true)

/** Saved bookmark: warm gold gradient with a fine amber edge. Use with tint = Color.Unspecified. */
val IBookmarkSaved: ImageVector = ImageVector.Builder("bookmarksaved", 24.dp, 24.dp, 24f, 24f)
    .addPath(
        pathData = PathParser().parsePathString(BOOKMARK_PATH).toNodes(),
        fill = Brush.verticalGradient(listOf(Color(0xFFFFE066), Color(0xFFFFB800)), startY = 3f, endY = 21.2f),
        stroke = SolidColor(Color(0xFF9A6700)),
        strokeLineWidth = 1.0f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round
    )
    .build()
val IWallet = vec("wallet", "M4 7.5A2.5 2.5 0 0 1 6.5 5H18v3" + rrect(3f, 7.5f, 18f, 12.5f, 2.8f) + "M16 14h2.5", 1.7f)
val IHome = vec("home", "M3.5 11.2L12 3.5l8.5 7.7V20a1 1 0 0 1-1 1H15v-6H9v6H4.5a1 1 0 0 1-1-1z", 1.7f)
val IBook = vec("book", "M12 6.5C10 4.8 7 4.2 3.5 4.5v13.5c3.5-.3 6.5.3 8.5 2 2-1.7 5-2.3 8.5-2V4.5C17 4.2 14 4.8 12 6.5zM12 6.5V20", 1.7f)
val IUser = vec("user", circ(12f, 8f, 4f) + "M4.5 21v-1a6 6 0 0 1 6-6h3a6 6 0 0 1 6 6v1", 1.7f)
val IUsersNav = vec("usersnav", circ(9f, 8f, 3.8f) + "M2.5 20v-1.2a4.5 4.5 0 0 1 4.5-4.5h4a4.5 4.5 0 0 1 4.5 4.5V20M16 4.4a3.8 3.8 0 0 1 0 7.2M21.5 20v-1.2a4.5 4.5 0 0 0-3-4.2", 1.7f)

// ---- solid (filled) icons used by the bottom navigation
private fun fvec(name: String, d: String, evenOdd: Boolean = false): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).addPath(
        pathData = PathParser().parsePathString(d).toNodes(),
        fill = SolidColor(Color.Black),
        pathFillType = if (evenOdd) androidx.compose.ui.graphics.PathFillType.EvenOdd
        else androidx.compose.ui.graphics.PathFillType.NonZero
    ).build()

val INavSocial = fvec(
    "navsocial",
    circ(16.3f, 7.1f, 4.1f) +
        "M7.7 20.8c0-4.3 3.6-7.5 8.15-7.5s8.15 3.2 8.15 7.5z" +
        circ(6.2f, 9.5f, 2.6f) +
        "M0.3 20.8c0-3.6 2.2-6.1 5.6-6.1.5 0 .9.1 1.3.2-1.2 1.3-1.9 3.3-1.9 5.9z"
)
val INavWallet = fvec(
    "navwallet",
    "M2.6 7.4L17.6 2.8l1.3.6.2 2-2.6-.2L6.4 7.9z" +
        "M4.7 7.6h14.1a3 3 0 0 1 3 3v7.6a3 3 0 0 1-3 3H4.7a3 3 0 0 1-3-3v-7.6a3 3 0 0 1 3-3z" +
        "M21.8 11.3h.3a1.2 1.2 0 0 1 1.2 1.2v3.3a1.2 1.2 0 0 1-1.2 1.2h-.3z" +
        circ(17.4f, 14.4f, 1.3f),
    evenOdd = true
)
val INavHome = fvec(
    "navhome",
    "M12 3.2c.45 0 .9.15 1.25.45l6.6 5.5c.7.6 1.1 1.4 1.1 2.3v7.5c0 1.1-.9 2-2 2h-3.9v-5.2c0-.9-.7-1.6-1.6-1.6h-2.9c-.9 0-1.6.7-1.6 1.6v5.2H5.1c-1.1 0-2-.9-2-2v-7.5c0-.9.4-1.7 1.1-2.3l6.6-5.5c.35-.3.8-.45 1.25-.45z"
)
val INavBook = fvec(
    "navbook",
    "M2.4 5.6C5.6 4.8 9 5.1 11.2 6.9V19.4C9 17.9 5.6 17.7 2.4 18.4z" +
        "M21.6 5.6C18.4 4.8 15 5.1 12.8 6.9V19.4C15 17.9 18.4 17.7 21.6 18.4z"
)
val INavUser = fvec(
    "navuser",
    circ(12f, 6.6f, 4.2f) +
        "M3 20.4c0-3.8 4-6.7 9-6.7s9 2.9 9 6.7c0 .6-.5 1.1-1.1 1.1H4.1C3.5 21.5 3 21 3 20.4z"
)

/** Scalloped blue verified badge with a white rounded tick. Draw with tint = Color.Unspecified. */
val IVerified: ImageVector = ImageVector.Builder("verified", 24.dp, 24.dp, 100f, 100f)
    .addPath(
        pathData = PathParser().parsePathString("M50.00 2.40 L51.24 2.54 L52.47 2.96 L53.65 3.62 L54.79 4.45 L55.87 5.38 L56.91 6.35 L57.92 7.26 L58.92 8.04 L59.93 8.65 L60.97 9.04 L62.08 9.22 L63.26 9.20 L64.51 9.02 L65.84 8.74 L67.22 8.43 L68.63 8.16 L70.03 8.00 L71.38 8.03 L72.65 8.28 L73.80 8.78 L74.80 9.52 L75.65 10.50 L76.35 11.65 L76.92 12.94 L77.39 14.30 L77.81 15.65 L78.23 16.94 L78.70 18.12 L79.27 19.15 L79.98 20.02 L80.85 20.73 L81.88 21.30 L83.06 21.77 L84.35 22.19 L85.70 22.61 L87.06 23.08 L88.35 23.65 L89.50 24.35 L90.48 25.20 L91.22 26.20 L91.72 27.35 L91.97 28.62 L92.00 29.97 L91.84 31.37 L91.57 32.78 L91.26 34.16 L90.98 35.49 L90.80 36.74 L90.78 37.92 L90.96 39.03 L91.35 40.07 L91.96 41.08 L92.74 42.08 L93.65 43.09 L94.62 44.13 L95.55 45.21 L96.38 46.35 L97.04 47.53 L97.46 48.76 L97.60 50.00 L97.46 51.24 L97.04 52.47 L96.38 53.65 L95.55 54.79 L94.62 55.87 L93.65 56.91 L92.74 57.92 L91.96 58.92 L91.35 59.93 L90.96 60.97 L90.78 62.08 L90.80 63.26 L90.98 64.51 L91.26 65.84 L91.57 67.22 L91.84 68.63 L92.00 70.03 L91.97 71.38 L91.72 72.65 L91.22 73.80 L90.48 74.80 L89.50 75.65 L88.35 76.35 L87.06 76.92 L85.70 77.39 L84.35 77.81 L83.06 78.23 L81.88 78.70 L80.85 79.27 L79.98 79.98 L79.27 80.85 L78.70 81.88 L78.23 83.06 L77.81 84.35 L77.39 85.70 L76.92 87.06 L76.35 88.35 L75.65 89.50 L74.80 90.48 L73.80 91.22 L72.65 91.72 L71.38 91.97 L70.03 92.00 L68.63 91.84 L67.22 91.57 L65.84 91.26 L64.51 90.98 L63.26 90.80 L62.08 90.78 L60.97 90.96 L59.93 91.35 L58.92 91.96 L57.92 92.74 L56.91 93.65 L55.87 94.62 L54.79 95.55 L53.65 96.38 L52.47 97.04 L51.24 97.46 L50.00 97.60 L48.76 97.46 L47.53 97.04 L46.35 96.38 L45.21 95.55 L44.13 94.62 L43.09 93.65 L42.08 92.74 L41.08 91.96 L40.07 91.35 L39.03 90.96 L37.92 90.78 L36.74 90.80 L35.49 90.98 L34.16 91.26 L32.78 91.57 L31.37 91.84 L29.97 92.00 L28.62 91.97 L27.35 91.72 L26.20 91.22 L25.20 90.48 L24.35 89.50 L23.65 88.35 L23.08 87.06 L22.61 85.70 L22.19 84.35 L21.77 83.06 L21.30 81.88 L20.73 80.85 L20.02 79.98 L19.15 79.27 L18.12 78.70 L16.94 78.23 L15.65 77.81 L14.30 77.39 L12.94 76.92 L11.65 76.35 L10.50 75.65 L9.52 74.80 L8.78 73.80 L8.28 72.65 L8.03 71.38 L8.00 70.03 L8.16 68.63 L8.43 67.22 L8.74 65.84 L9.02 64.51 L9.20 63.26 L9.22 62.08 L9.04 60.97 L8.65 59.93 L8.04 58.92 L7.26 57.92 L6.35 56.91 L5.38 55.87 L4.45 54.79 L3.62 53.65 L2.96 52.47 L2.54 51.24 L2.40 50.00 L2.54 48.76 L2.96 47.53 L3.62 46.35 L4.45 45.21 L5.38 44.13 L6.35 43.09 L7.26 42.08 L8.04 41.08 L8.65 40.07 L9.04 39.03 L9.22 37.92 L9.20 36.74 L9.02 35.49 L8.74 34.16 L8.43 32.78 L8.16 31.37 L8.00 29.97 L8.03 28.62 L8.28 27.35 L8.78 26.20 L9.52 25.20 L10.50 24.35 L11.65 23.65 L12.94 23.08 L14.30 22.61 L15.65 22.19 L16.94 21.77 L18.12 21.30 L19.15 20.73 L20.02 20.02 L20.73 19.15 L21.30 18.12 L21.77 16.94 L22.19 15.65 L22.61 14.30 L23.08 12.94 L23.65 11.65 L24.35 10.50 L25.20 9.52 L26.20 8.78 L27.35 8.28 L28.62 8.03 L29.97 8.00 L31.37 8.16 L32.78 8.43 L34.16 8.74 L35.49 9.02 L36.74 9.20 L37.92 9.22 L39.03 9.04 L40.07 8.65 L41.08 8.04 L42.08 7.26 L43.09 6.35 L44.13 5.38 L45.21 4.45 L46.35 3.62 L47.53 2.96 L48.76 2.54 Z").toNodes(),
        fill = SolidColor(Color(0xFF4A80F5))
    )
    .addPath(
        pathData = PathParser().parsePathString("M28.5 49.5L44.5 64.5L70 37.5").toNodes(),
        stroke = SolidColor(Color.White),
        strokeLineWidth = 11f,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round
    )
    .build()

// ---------------------------------------------------------------- helpers

/** Compose draws a dark translucent square on press when no theme gives it a ripple. This draws nothing instead. */
object NoIndication : Indication {
    private object Instance : IndicationInstance {
        override fun ContentDrawScope.drawIndication() {
            drawContent()
        }
    }

    @Composable
    override fun rememberUpdatedInstance(interactionSource: InteractionSource): IndicationInstance = Instance
}

internal fun loadBitmap(ctx: android.content.Context, uri: Uri, maxDim: Int = 2048): Bitmap? {
    val resolver = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxDim) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
    val orientation = try {
        resolver.openInputStream(uri)?.use {
            android.media.ExifInterface(it).getAttributeInt(
                android.media.ExifInterface.TAG_ORIENTATION,
                android.media.ExifInterface.ORIENTATION_NORMAL
            )
        } ?: android.media.ExifInterface.ORIENTATION_NORMAL
    } catch (e: Exception) {
        android.media.ExifInterface.ORIENTATION_NORMAL
    }
    val m = android.graphics.Matrix()
    when (orientation) {
        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
        android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        else -> return bmp
    }
    return try {
        Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    } catch (e: Exception) {
        bmp
    }
}

@Composable
fun rememberUriBitmap(uri: Uri?): ImageBitmap? {
    val ctx = LocalContext.current
    val state = produceState<ImageBitmap?>(initialValue = null, uri) {
        value = if (uri == null) null else withContext(Dispatchers.IO) {
            try {
                loadBitmap(ctx, uri)?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    return state.value
}

@Composable
fun Avatar(res: Int, size: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(res),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.size(size).clip(CircleShape)
    )
}

private val AvatarColors = listOf(
    Color(0xFF1F78F4), Color(0xFF13A152), Color(0xFFE5484D), Color(0xFF8E4EC6), Color(0xFFF76B15), Color(0xFF0891B2)
)

/** Profile photo when there is one, otherwise a coloured circle with the first letter of the name. */
@Composable
fun UserAvatar(photo: String?, name: String, size: Dp, modifier: Modifier = Modifier) {
    if (!photo.isNullOrBlank()) {
        AsyncImage(
            model = photo,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier.size(size).clip(CircleShape).background(Color(0xFFE3EAF3))
        )
    } else {
        val c = AvatarColors[(name.hashCode() and 0x7fffffff) % AvatarColors.size]
        Box(modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
            Text(
                name.trim().take(1).uppercase(),
                color = Color.White,
                fontSize = (size.value * 0.42f).sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/** Posts longer than this many lines show a "See more" link. */
const val POST_TEXT_MAX_LINES = 4

/** Narrowest a post picture may look (width / height = 4 : 5). Anything taller is centre-cropped to this shape. */
const val MIN_POST_IMAGE_ASPECT = 0.8f

/** 999 -> "999", 1000 -> "1k", 1100 -> "1.1k", 1000000 -> "1M", 1100000 -> "1.1M", 1000000000 -> "1B". Never rounds up. */
fun formatCount(n: Long): String {
    if (n < 1000L) return n.coerceAtLeast(0L).toString()
    val (div, suffix) = when {
        n >= 1_000_000_000L -> 1_000_000_000L to "B"
        n >= 1_000_000L -> 1_000_000L to "M"
        else -> 1_000L to "k"
    }
    val tenths = n * 10L / div
    val whole = tenths / 10L
    val dec = tenths % 10L
    return (if (dec == 0L) "$whole" else "$whole.$dec") + suffix
}

/**
 * Icon that dips in and springs back whenever [active] flips (like / bookmark, both when added and removed).
 * No dip when it first appears on screen. Pass Color.Unspecified as [tint] to keep the icon's own colours.
 */
@Composable
fun PopIcon(icon: ImageVector, tint: Color, size: Dp, active: Boolean, modifier: Modifier = Modifier) {
    val scale = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(active) {
        if (first) {
            first = false
            return@LaunchedEffect
        }
        scale.animateTo(0.74f, tween(90, easing = FastOutSlowInEasing))
        scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
    }
    val animated by animateColorAsState(if (tint == Color.Unspecified) Color.Black else tint, tween(180), label = "popTint")
    Icon(
        icon, null,
        tint = if (tint == Color.Unspecified) Color.Unspecified else animated,
        modifier = modifier.size(size).graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
        }
    )
}

/** A post picture keeps its own shape down to 4 : 5. Anything taller is cut (centre kept) to 4 : 5. */
@Composable
fun FramedPicture(bmp: ImageBitmap, modifier: Modifier = Modifier, corner: Dp = 9.dp) {
    val ratio = (bmp.width.toFloat() / bmp.height.toFloat()).coerceAtLeast(MIN_POST_IMAGE_ASPECT)
    Image(
        bitmap = bmp,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(ratio)
            .clip(RoundedCornerShape(corner))
    )
}

fun relTime(ms: Long): String {
    val d = (System.currentTimeMillis() - ms) / 1000
    return when {
        d < 60 -> "Just now"
        d < 3600 -> "${d / 60} min ago"
        d < 7200 -> "1 hour ago"
        d < 86400 -> "${d / 3600} hours ago"
        d < 172800 -> "1 day ago"
        else -> "${d / 86400} days ago"
    }
}

private fun decodeB64(b: String): ImageBitmap? = try {
    val bytes = android.util.Base64.decode(b, android.util.Base64.DEFAULT)
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
} catch (e: Exception) {
    null
}

// ---------------------------------------------------------------- Top bar (height 38)

@Composable
fun TopBar(
    searching: Boolean,
    query: String,
    unread: Boolean,
    userName: String,
    userPhoto: String?,
    onQuery: (String) -> Unit,
    onSearchToggle: () -> Unit,
    onBell: () -> Unit,
    onProfile: () -> Unit
) {
    Row(
        modifier = Modifier
            .statusBarsPadding()
            .fillMaxWidth()
            .height(38.dp)
            .padding(start = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (searching) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE8EDF5), RoundedCornerShape(18.dp))
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) Text("খুঁজুন...", color = Grey, fontSize = 14.sp)
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = Ink, fontSize = 14.sp),
                    cursorBrush = SolidColor(Blue),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(36.dp).clickable(onClick = onSearchToggle), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
        } else {
            Spacer(Modifier.width(2.dp))
            Image(
                painter = painterResource(R.drawable.logo_flower),
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.width(10.5.dp))
            Column {
                Text(
                    "Social",
                    color = TitleInk,
                    fontSize = 16.5.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 18.sp
                )
                Text(
                    "Connect  ·  Share  ·  Grow",
                    color = SubGrey,
                    fontSize = 9.7.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.1.sp,
                    lineHeight = 12.sp,
                    modifier = Modifier.offset(y = (-0.8).dp)
                )
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(33.dp).clickable(onClick = onSearchToggle), contentAlignment = Alignment.Center) {
                Icon(ISearch, null, tint = Ink, modifier = Modifier.size(17.dp))
            }
            Box(Modifier.size(33.dp).clickable(onClick = onBell), contentAlignment = Alignment.Center) {
                Box(Modifier.size(17.dp)) {
                    Icon(IBell, null, tint = Ink, modifier = Modifier.size(17.dp))
                    if (unread) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 1.dp, end = 3.5.dp)
                                .size(5.5.dp)
                                .clip(CircleShape)
                                .background(HeartRed)
                        )
                    }
                }
            }
            Spacer(Modifier.width(7.5.dp))
            UserAvatar(userPhoto, userName, 30.dp, Modifier.clickable(onClick = onProfile))
        }
    }
}

// ---------------------------------------------------------------- Chips (6 in one row, no scrolling)

@Composable
fun FeedChip(label: String?, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(11.dp)
    val bg = if (selected) Brush.horizontalGradient(listOf(Color(0xFF2B86F7), Color(0xFF0F6BEF)))
    else SolidColor(Color.White)
    Row(
        modifier = Modifier
            .height(29.5.dp)
            .shadow(
                if (selected) 3.dp else 1.5.dp, shape, clip = false,
                ambientColor = Color(0x331F78F4), spotColor = Color(0x331F78F4)
            )
            .clip(shape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = if (label == null) 7.dp else 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (selected) Color.White else Ink, modifier = Modifier.size(15.dp))
        if (label != null) {
            Spacer(Modifier.width(3.8.dp))
            Text(
                label,
                color = if (selected) Color.White else Ink,
                fontSize = 11.1.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
            )
        }
    }
}

@Composable
fun ChipsRow(
    selected: FeedFilter,
    sortPopular: Boolean,
    onSelect: (FeedFilter) -> Unit,
    onSort: (Boolean) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        FeedChip("All", IGrid, selected == FeedFilter.All) { onSelect(FeedFilter.All) }
        FeedChip("Following", IUsers, selected == FeedFilter.Following) { onSelect(FeedFilter.Following) }
        FeedChip("Text", IText, selected == FeedFilter.Text) { onSelect(FeedFilter.Text) }
        FeedChip("Image", IImage, selected == FeedFilter.Image) { onSelect(FeedFilter.Image) }
        FeedChip("Poll", IBars, selected == FeedFilter.Poll) { onSelect(FeedFilter.Poll) }
        Box {
            FeedChip(null, ITune, false) { menu = true }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(if (!sortPopular) "✓  নতুন আগে" else "নতুন আগে") },
                    onClick = { onSort(false); menu = false }
                )
                DropdownMenuItem(
                    text = { Text(if (sortPopular) "✓  জনপ্রিয় আগে" else "জনপ্রিয় আগে") },
                    onClick = { onSort(true); menu = false }
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Composer (372 x 47)

@Composable
fun Composer(userName: String, userPhoto: String?, onText: () -> Unit, onImage: () -> Unit, onPoll: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Surface(
        shape = shape,
        color = Color.White,
        shadowElevation = 1.dp,
        modifier = Modifier.padding(horizontal = 9.dp).fillMaxWidth().height(47.dp)
    ) {
        Row(
            modifier = Modifier.padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(userPhoto, userName, 35.dp)
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .width(193.dp)
                    .height(32.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF3F6FA))
                    .clickable(onClick = onText)
                    .padding(start = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text("Your canvas, your words...", color = PlaceholderGrey, fontSize = 14.45.sp, maxLines = 1, modifier = Modifier.offset(y = 0.8.dp))
            }
            Spacer(Modifier.width(20.dp))
            Box(Modifier.size(21.dp).clickable(onClick = onImage)) { Icon(IImage, null, tint = Ink, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.width(16.dp))
            Box(Modifier.size(21.dp).clickable(onClick = onPoll)) { Icon(IBars, null, tint = Ink, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.width(14.dp))
            Box(Modifier.size(20.dp).clickable(onClick = onText)) { Icon(IPen, null, tint = Ink, modifier = Modifier.size(20.dp)) }
        }
    }
}

// ---------------------------------------------------------------- Post card

/** TEST ONLY: lets the 3-dot menu fake name / time / verified badge on screen. Remove later. */
const val DEBUG_TOOLS = true

class PostActions(
    val like: (String) -> Unit,
    val comment: (String) -> Unit,
    val share: (String) -> Unit,
    val bookmark: (String) -> Unit,
    val vote: (String, Int) -> Unit,
    val copy: (String) -> Unit,
    val hide: (String) -> Unit,
    val delete: (String) -> Unit,
    val follow: (String) -> Unit,
    val debugName: (String) -> Unit = {},
    val debugTime: (String) -> Unit = {},
    val debugVerified: (String) -> Unit = {}
)

@Composable
fun Tag(text: String, icon: ImageVector? = null) {
    Row(
        modifier = Modifier
            .height(16.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(TagBg)
            .padding(horizontal = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = TagText, modifier = Modifier.size(9.5.dp))
            Spacer(Modifier.width(3.5.dp))
        }
        Text(text, color = TagText, fontSize = 10.4.sp, fontWeight = FontWeight.Medium, lineHeight = 12.sp)
    }
}

/** Every action sits in a slot of this width, so icons never move when a count gets longer. */
private val ActionSlotWidth = 60.dp

@Composable
fun ActionItem(icon: ImageVector, tint: Color, count: Int, active: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.width(ActionSlotWidth), contentAlignment = Alignment.CenterStart) {
        Row(
            modifier = Modifier.clickable(onClick = onClick),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PopIcon(icon, tint, 18.dp, active)
            Spacer(Modifier.width(6.3.dp))
            Text(
                formatCount(count.toLong()), color = CountInk, fontSize = 11.2.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, softWrap = false,
                modifier = Modifier.offset(y = (-1).dp)
            )
        }
    }
}

@Composable
fun ActionRow(post: Post, actions: PostActions) {
    val likedNow by rememberUpdatedState(post.liked)
    val actionsNow by rememberUpdatedState(actions)
    Row(
        modifier = Modifier.fillMaxWidth().height(30.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ActionItem(if (post.liked) IHeartFill else IHeart, if (post.liked) HeartRed else Ink, post.likes, post.liked) { actions.like(post.id) }
        ActionItem(IChat, Ink, post.commentCount) { actions.comment(post.id) }
        ActionItem(IShare, Ink, post.shares) { actions.share(post.id) }
        // the empty stretch between share and bookmark: double-tap = like (it never un-likes)
        Box(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .pointerInput(post.id) {
                    detectTapGestures(onDoubleTap = { if (!likedNow) actionsNow.like(post.id) })
                }
        )
        Box(Modifier.padding(end = 2.dp).size(19.dp).clickable { actions.bookmark(post.id) }) {
            PopIcon(
                if (post.bookmarked) IBookmarkSaved else IBookmark,
                if (post.bookmarked) Color.Unspecified else Ink,
                19.dp,
                post.bookmarked
            )
        }
    }
}

@Composable
fun PostCard(post: Post, actions: PostActions, modifier: Modifier = Modifier) {
    var menu by remember { mutableStateOf(false) }
    var pending by remember(post.id) { mutableStateOf(-1) }
    val shape = RoundedCornerShape(16.dp)
    Surface(
        shape = shape,
        color = Color.White,
        shadowElevation = 1.dp,
        border = if (post.mine) BorderStroke(1.dp, Blue) else BorderStroke(0.6.dp, Color(0xFFE8EEF6)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 7.dp)) {
            // ---- header
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(post.authorPhoto, post.author, 36.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f).height(36.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(post.author, color = PostInk, fontSize = 14.5.sp, fontWeight = FontWeight.Medium, lineHeight = 17.sp)
                        if (post.verified) {
                            Spacer(Modifier.width(6.dp))
                            Icon(IVerified, null, tint = Color.Unspecified, modifier = Modifier.size(13.2.dp))
                        }
                        if (post.mine) {
                            Spacer(Modifier.width(5.2.dp))
                            Box(Modifier.offset(y = (-0.5).dp)) { Tag("My Post") }
                        } else if (post.poll != null) {
                            Spacer(Modifier.width(6.dp))
                            Tag("Poll", IBars)
                        }
                    }
                    Spacer(Modifier.height(0.3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(relTime(post.createdAt), color = TimeGrey, fontSize = 11.7.sp, lineHeight = 12.sp)
                        Spacer(Modifier.width(4.dp))
                        Text("•", color = TimeGrey, fontSize = 9.sp, lineHeight = 12.sp)
                        Spacer(Modifier.width(4.dp))
                        Text("Public", color = TimeGrey, fontSize = 11.7.sp, lineHeight = 12.sp)
                        Spacer(Modifier.width(5.dp))
                        Icon(Icons.Outlined.Public, null, tint = Color(0xFF8A93A3), modifier = Modifier.size(13.dp))
                    }
                }
                Box {
                    Box(Modifier.size(24.dp).clickable { menu = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.MoreHoriz, null, tint = Ink, modifier = Modifier.size(20.dp))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("টেক্সট কপি করুন") }, onClick = { menu = false; actions.copy(post.id) })
                        DropdownMenuItem(text = { Text("পোস্ট লুকান") }, onClick = { menu = false; actions.hide(post.id) })
                        if (!post.mine) {
                            DropdownMenuItem(
                                text = { Text(if (post.following) "আনফলো করুন" else "ফলো করুন") },
                                onClick = { menu = false; actions.follow(post.id) }
                            )
                        }
                        if (post.mine) {
                            DropdownMenuItem(text = { Text("মুছে ফেলুন", color = HeartRed) }, onClick = { menu = false; actions.delete(post.id) })
                        }
                        if (DEBUG_TOOLS) {
                            DropdownMenuItem(text = { Text("[টেস্ট] নাম বদলান", color = Blue) }, onClick = { menu = false; actions.debugName(post.id) })
                            DropdownMenuItem(text = { Text("[টেস্ট] সময় বদলান", color = Blue) }, onClick = { menu = false; actions.debugTime(post.id) })
                            DropdownMenuItem(
                                text = { Text(if (post.verified) "[টেস্ট] ভেরিফাইড ব্যাজ বন্ধ" else "[টেস্ট] ভেরিফাইড ব্যাজ চালু", color = Blue) },
                                onClick = { menu = false; actions.debugVerified(post.id) }
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            if (post.text.isNotBlank()) {
                var expanded by remember(post.id) { mutableStateOf(false) }
                var clipped by remember(post.id, post.text) { mutableStateOf(false) }
                Column(Modifier.animateContentSize(tween(220, easing = FastOutSlowInEasing))) {
                    Text(
                        post.text,
                        color = PostInk,
                        fontSize = 15.sp,
                        lineHeight = 20.5.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = if (expanded) Int.MAX_VALUE else POST_TEXT_MAX_LINES,
                        overflow = TextOverflow.Ellipsis,
                        onTextLayout = { if (!expanded) clipped = it.hasVisualOverflow }
                    )
                    if (clipped) {
                        Text(
                            if (expanded) "See less" else "See more",
                            color = Color(0xFF6B7788),
                            fontSize = 14.sp,
                            lineHeight = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 3.dp).clickable { expanded = !expanded }
                        )
                    }
                }
            }

            // ---- image (own shape, cut to 4:5 when taller; see FramedPicture)
            val b64Bmp by produceState<ImageBitmap?>(initialValue = null, post.imageB64) {
                value = post.imageB64?.let { b -> withContext(Dispatchers.Default) { decodeB64(b) } }
            }
            if (post.imageB64 != null || post.imageUrl != null) {
                Spacer(Modifier.height(7.dp))
                val loaded = b64Bmp
                if (post.imageUrl != null) {
                    var urlRatio by remember(post.imageUrl) { mutableStateOf(773f / 303f) }
                    AsyncImage(
                        model = post.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        onSuccess = { st ->
                            val sz = st.painter.intrinsicSize
                            if (sz.width.isFinite() && sz.height.isFinite() && sz.width > 0f && sz.height > 0f) {
                                urlRatio = sz.width / sz.height
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(urlRatio.coerceAtLeast(MIN_POST_IMAGE_ASPECT))
                            .clip(RoundedCornerShape(9.dp))
                    )
                } else if (loaded != null) {
                    FramedPicture(loaded)
                } else {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(773f / 303f)
                            .clip(RoundedCornerShape(9.dp))
                            .background(Color(0xFFEFF3F8))
                    )
                }
            }

            // ---- poll
            if (post.poll != null) {
                val poll = post.poll
                val voted = poll.selected >= 0 || poll.ended
                val lead = poll.options.indices.maxByOrNull { poll.pct(it) } ?: -1
                Spacer(Modifier.height(7.dp))
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    poll.options.forEachIndexed { i, opt ->
                        val st = when {
                            voted && poll.selected == i -> PollState.Voted
                            !voted && pending == i -> PollState.Pending
                            else -> PollState.Normal
                        }
                        PollRow(
                            option = opt,
                            pct = poll.pct(i),
                            state = st,
                            lead = i == lead,
                            onClick = { if (!voted) pending = i },
                            onCancel = { pending = -1 },
                            onConfirm = { pending = -1; actions.vote(post.id, i) }
                        )
                    }
                }
                Spacer(Modifier.height(11.dp))
                Row(
                    modifier = Modifier.padding(start = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${poll.total} votes", color = PollMeta, fontSize = 12.sp)
                    Text("  •  ", color = PollMeta, fontSize = 12.sp)
                    Icon(IClock, null, tint = PollMeta, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (poll.ended) "Poll ended" else "${poll.daysLeft} days left", color = PollMeta, fontSize = 12.sp)
                }
                Spacer(Modifier.height(3.5.dp))
            } else {
                Spacer(Modifier.height(if (post.imageB64 != null || post.imageUrl != null) 4.5.dp else 7.dp))
            }

            ActionRow(post, actions)
        }
    }
}

private fun pollFill(pct: Int): Float {
    val xs = floatArrayOf(0f, 16f, 18f, 24f, 42f, 100f)
    val ys = floatArrayOf(0.02f, 0.16f, 0.19f, 0.26f, 0.39f, 1f)
    val p = pct.toFloat().coerceIn(0f, 100f)
    for (i in 1 until xs.size) {
        if (p <= xs[i]) {
            val t = (p - xs[i - 1]) / (xs[i] - xs[i - 1])
            return ys[i - 1] + t * (ys[i] - ys[i - 1])
        }
    }
    return 1f
}

enum class PollState { Normal, Pending, Voted }

@Composable
private fun ConfirmButton(label: String, icon: ImageVector, bg: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .height(30.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, lineHeight = 16.sp)
    }
}

@Composable
fun PollRow(
    option: PollOption,
    pct: Int,
    state: PollState,
    lead: Boolean,
    onClick: () -> Unit,
    onCancel: () -> Unit,
    onConfirm: () -> Unit
) {
    val shape = RoundedCornerShape(11.dp)
    val selected = state != PollState.Normal
    val strong = selected || lead

    // outline fades to blue; the background colour never changes
    val borderColor by animateColorAsState(if (selected) Blue else PollRowBorder, tween(240), label = "pollBorderColor")
    val borderWidth by animateDpAsState(if (selected) 1.5.dp else 1.dp, tween(240), label = "pollBorderWidth")
    // the "Vote for this option?" strip grows under the tapped option while the previous one folds away,
    // both on the same curve, so the strip appears to glide from one option to the other
    val confirmHeight by animateDpAsState(
        if (state == PollState.Pending) 46.dp else 0.dp,
        tween(durationMillis = 340, easing = FastOutSlowInEasing),
        label = "pollConfirmHeight"
    )
    // no votes = completely empty bar
    val fill by animateFloatAsState(
        if (option.votes <= 0) 0f else pollFill(pct),
        tween(450, easing = FastOutSlowInEasing),
        label = "pollFill"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(PollOptionBg)
            .border(borderWidth, borderColor, shape)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(45.dp)
                .clickable(enabled = state == PollState.Normal, onClick = onClick)
        ) {
            // checkbox
            val cbShape = RoundedCornerShape(5.dp)
            Box(
                modifier = Modifier
                    .padding(start = 12.dp, top = 14.dp)
                    .size(18.dp)
                    .clip(cbShape)
                    .background(if (state == PollState.Voted) Blue else Color.White)
                    .border(
                        if (state == PollState.Normal) 1.5.dp else 1.8.dp,
                        if (state == PollState.Normal) PollBoxBorder else Blue,
                        cbShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (state == PollState.Voted) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(12.dp))
            }
            // label + percentage on one baseline
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 42.dp, end = 13.dp, top = 10.dp)
            ) {
                Text(
                    option.text,
                    color = Color.Black,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).alignByBaseline()
                )
                Text(
                    "$pct%",
                    color = if (selected) Blue else Color.Black,
                    fontSize = 13.1.sp,
                    lineHeight = 18.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier.alignByBaseline()
                )
            }
            // bar
            Box(
                modifier = Modifier
                    .padding(start = 42.dp, top = 32.dp)
                    .width(214.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(PollTrack)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fill)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            if (strong) Brush.horizontalGradient(listOf(Color(0xFF3C8DFF), Color(0xFF1F7AFC)))
                            else SolidColor(Color(0xFF75AEFD))
                        )
                )
            }
            // votes
            Text(
                "${option.votes} votes",
                color = PollVotes,
                fontSize = 10.8.sp,
                lineHeight = 12.sp,
                maxLines = 1,
                modifier = Modifier.align(Alignment.TopEnd).padding(end = 13.dp, top = 29.dp)
            )
        }
        if (confirmHeight > 0.dp) {
            val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
            Box(Modifier.fillMaxWidth().height(confirmHeight).clipToBounds()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight(Alignment.Top, unbounded = true)
                        .height(46.dp)
                        .graphicsLayer { alpha = (confirmHeight.value / 46f).coerceIn(0f, 1f) }
                        .drawBehind {
                            drawLine(
                                Color(0xFFB9D3F7),
                                Offset(0f, 0f),
                                Offset(size.width, 0f),
                                strokeWidth = 1.dp.toPx(),
                                pathEffect = dash
                            )
                        }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Vote for this option?",
                        color = Ink,
                        fontSize = 12.5.sp,
                        lineHeight = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    ConfirmButton("Cancel", Icons.Filled.Close, Color(0xFFE5484D), onCancel)
                    Spacer(Modifier.width(7.dp))
                    ConfirmButton("Vote", Icons.Filled.Check, Color(0xFF1FAA5B), onConfirm)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- FAB + nav

@Composable
fun Fab(onClick: () -> Unit, modifier: Modifier = Modifier, rotation: Float = 0f) {
    Box(
        modifier = modifier
            .shadow(6.dp, CircleShape, clip = false, ambientColor = Blue, spotColor = Blue)
            .size(42.dp)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2E8BFA), Color(0xFF0B63E0))))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            IPlusFab, null, tint = Color.White,
            modifier = Modifier
                .size(21.dp)
                .graphicsLayer { rotationZ = rotation }
        )
    }
}

private class FabChoice(val mode: String, val label: String, val icon: ImageVector)

// top to bottom
private val FabChoices = listOf(
    FabChoice("text", "Text", IText),
    FabChoice("image", "Image", IImage),
    FabChoice("poll", "Poll", IBars)
)

/**
 * The + button. Tapping it turns the + into a x and lifts Text / Image / Poll out of it, one after another
 * (the nearest first), each rising, fading and growing into place. Closing plays the same thing backwards.
 */
@Composable
fun FabMenu(open: Boolean, onToggle: () -> Unit, onPick: (String) -> Unit, modifier: Modifier = Modifier) {
    val spin by animateFloatAsState(if (open) 45f else 0f, tween(320, easing = FastOutSlowInEasing), label = "fabSpin")
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FabChoices.forEachIndexed { i, c ->
            val order = FabChoices.lastIndex - i // 0 = the one right above the button
            val p by animateFloatAsState(
                targetValue = if (open) 1f else 0f,
                animationSpec = tween(
                    durationMillis = 320,
                    delayMillis = if (open) order * 60 else i * 35,
                    easing = FastOutSlowInEasing
                ),
                label = "fabOption$i"
            )
            if (p > 0.001f) {
                FabOption(c.label, c.icon, p, open) { onPick(c.mode) }
            }
        }
        Fab(onClick = onToggle, rotation = spin)
    }
}

@Composable
private fun FabOption(label: String, icon: ImageVector, progress: Float, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier = Modifier
            .graphicsLayer {
                translationY = (1f - progress) * 28.dp.toPx()
                alpha = progress
                scaleX = 0.8f + 0.2f * progress
                scaleY = 0.8f + 0.2f * progress
                transformOrigin = TransformOrigin(1f, 1f)
            }
            .shadow(8.dp, shape, clip = false, ambientColor = Color(0x331F78F4), spotColor = Color(0x331F78F4))
            .clip(shape)
            .background(Color.White)
            .border(0.8.dp, Color(0xFFE1EAF7), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(start = 8.dp, end = 16.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(28.dp).clip(CircleShape).background(Color(0xFFE6F0FE)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(9.dp))
        Text(label, color = Ink, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

val NavLabels = listOf("Social", "Economy", "Home", "Library", "Profile")
val NavIcons: List<ImageVector> = listOf(INavSocial, INavWallet, INavHome, INavBook, INavUser)

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    // soft, light floating sheet: rounded top, white fading to pale blue, faint blue glow above it
    val barShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 14.dp,
                shape = barShape,
                ambientColor = Color(0x1F1F78F4),
                spotColor = Color(0x331F78F4)
            )
            .background(
                Brush.verticalGradient(listOf(Color.White, Color(0xFFF3F8FF), Color(0xFFE8F1FE))),
                barShape
            )
            .border(0.6.dp, Color(0xFFE4ECF8), barShape)
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(49.dp)) {
            val itemW = maxWidth / NavLabels.size
            // The blue line keeps its shape and simply glides under the chosen tab (critically damped: no bounce).
            val lineX by animateDpAsState(
                targetValue = itemW * selected + (itemW - 14.dp) / 2,
                animationSpec = spring(dampingRatio = 1f, stiffness = 320f),
                label = "navLine"
            )
            Row(Modifier.fillMaxSize()) {
                NavLabels.forEachIndexed { i, label ->
                    val active = i == selected
                    val interaction = remember { MutableInteractionSource() }
                    val pressed by interaction.collectIsPressedAsState()
                    val iconScale by animateFloatAsState(
                        targetValue = when {
                            pressed -> 0.9f
                            active -> 1.12f
                            else -> 1f
                        },
                        animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow),
                        label = "navIconScale"
                    )
                    val lift by animateDpAsState(
                        targetValue = if (active) (-1.5).dp else 0.dp,
                        animationSpec = spring(dampingRatio = 0.9f, stiffness = 300f),
                        label = "navIconLift"
                    )
                    val tint by animateColorAsState(
                        if (active) Blue else Ink,
                        tween(320, easing = FastOutSlowInEasing),
                        label = "navTint"
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable(interactionSource = interaction, indication = null) { onSelect(i) }
                            .padding(top = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            NavIcons[i], null, tint = tint,
                            modifier = Modifier
                                .size(19.7.dp)
                                .graphicsLayer {
                                    scaleX = iconScale
                                    scaleY = iconScale
                                    translationY = lift.toPx()
                                }
                        )
                        Spacer(Modifier.height(1.dp))
                        Text(
                            label,
                            color = tint,
                            fontSize = 8.1.sp,
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 10.sp
                        )
                        Spacer(Modifier.height(2.dp))
                        Box(
                            Modifier
                                .size(width = 14.dp, height = 2.5.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color(0xFFD9E2EE))
                        )
                    }
                }
            }
            Box(
                Modifier
                    .offset(x = lineX, y = 36.7.dp)
                    .size(width = 14.dp, height = 2.5.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Blue)
            )
        }
        // the bar's background continues under the system navigation area
        Box(Modifier.navigationBarsPadding())
    }
}
