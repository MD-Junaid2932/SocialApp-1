package com.junaid.social

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Reply
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Notes
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Blue = Color(0xFF1F78F4)
val BlueDark = Color(0xFF0B63E0)
val Ink = Color(0xFF14171F)
val Grey = Color(0xFF7C8594)
val LineGrey = Color(0xFFE8EDF5)
val TagBg = Color(0xFFD8EBFF)
val HeartRed = Color(0xFFFF3B52)
val PageTop = Color(0xFFE9F2FF)

fun Modifier.tap(onClick: () -> Unit): Modifier = composedTap(onClick)

@Composable
private fun rememberNoIndication() = remember { MutableInteractionSource() }

private fun Modifier.composedTap(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)

@Composable
fun rememberUriBitmap(uri: Uri?): ImageBitmap? {
    val ctx = LocalContext.current
    val state = produceState<ImageBitmap?>(initialValue = null, uri) {
        value = if (uri == null) null else withContext(Dispatchers.IO) {
            try {
                val opts = BitmapFactory.Options().apply { inSampleSize = 3 }
                ctx.contentResolver.openInputStream(uri)?.use { s ->
                    val bmp: Bitmap? = BitmapFactory.decodeStream(s, null, opts)
                    bmp?.asImageBitmap()
                }
            } catch (e: Exception) {
                null
            }
        }
    }
    return state.value
}

@Composable
fun Avatar(res: Int, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(res),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.size(size).clip(CircleShape)
    )
}

// ---------------------------------------------------------------- Top bar

@Composable
fun TopBar(
    searching: Boolean,
    query: String,
    unread: Boolean,
    onQuery: (String) -> Unit,
    onSearchToggle: () -> Unit,
    onBell: () -> Unit,
    onProfile: () -> Unit
) {
    Row(
        modifier = Modifier
            .statusBarsPadding()
            .fillMaxWidth()
            .height(56.dp)
            .padding(start = 9.dp, end = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (searching) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(19.dp))
                    .background(Color.White)
                    .border(1.dp, LineGrey, RoundedCornerShape(19.dp))
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) {
                    Text("খুঁজুন...", color = Grey, fontSize = 14.sp)
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = TextStyle(color = Ink, fontSize = 14.sp),
                    cursorBrush = SolidColor(Blue),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.width(6.dp))
            Box(
                modifier = Modifier.size(36.dp).clickable(onClick = onSearchToggle),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Close, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
        } else {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier.size(width = 30.dp, height = 32.dp)
            )
            Spacer(Modifier.width(8.dp))
            Column(verticalArrangement = Arrangement.Center) {
                Text(
                    "Social",
                    color = Ink,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 24.sp
                )
                Text(
                    "Connect  ·  Share  ·  Grow",
                    color = Grey,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 13.sp
                )
            }
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier.size(36.dp).clickable(onClick = onSearchToggle),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Search, null, tint = Ink, modifier = Modifier.size(24.dp))
            }
            Box(
                modifier = Modifier.size(36.dp).clickable(onClick = onBell),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.NotificationsNone, null, tint = Ink, modifier = Modifier.size(24.dp))
                if (unread) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 7.dp, end = 8.dp)
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(HeartRed)
                    )
                }
            }
            Spacer(Modifier.width(6.dp))
            Avatar(
                R.drawable.me, 34.dp,
                Modifier.clickable(onClick = onProfile)
            )
        }
    }
}

// ---------------------------------------------------------------- Stories

@Composable
fun StoriesRow(stories: List<Story>, onCreate: () -> Unit, onStory: (Story) -> Unit) {
    LazyRow(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 1.dp, end = 8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        item {
            Column(
                modifier = Modifier.width(69.dp).clickable(onClick = onCreate),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(45.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE6F0FD))
                        .border(1.dp, Color(0xFFD2E3FA), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Add, null, tint = Blue, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.height(6.dp))
                Text("Create", color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        items(stories) { s ->
            Column(
                modifier = Modifier.width(69.dp).clickable { onStory(s) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Avatar(s.avatarRes, 45.dp)
                Spacer(Modifier.height(6.dp))
                Text(
                    s.name,
                    color = Ink,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Chips

@Composable
fun FeedChip(label: String?, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val bg = if (selected) Brush.horizontalGradient(listOf(Color(0xFF2B86F7), Color(0xFF0F6BEF)))
    else SolidColor(Color.White)
    Row(
        modifier = Modifier
            .height(31.dp)
            .shadow(if (selected) 0.dp else 1.dp, shape, clip = false)
            .clip(shape)
            .background(bg)
            .then(if (selected) Modifier else Modifier.border(0.6.dp, Color(0xFFEBF0F7), shape))
            .clickable(onClick = onClick)
            .padding(horizontal = if (label == null) 10.dp else 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon, null,
            tint = if (selected) Color.White else Ink,
            modifier = Modifier.size(17.dp)
        )
        if (label != null) {
            Spacer(Modifier.width(7.dp))
            Text(
                label,
                color = if (selected) Color.White else Ink,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun ChipsRow(
    selected: FeedFilter,
    sortPopular: Boolean,
    onSelect: (FeedFilter) -> Unit,
    onSort: (Boolean) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    LazyRow(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item { FeedChip("All", Icons.Outlined.GridView, selected == FeedFilter.All) { onSelect(FeedFilter.All) } }
        item { FeedChip("Following", Icons.Outlined.People, selected == FeedFilter.Following) { onSelect(FeedFilter.Following) } }
        item { FeedChip("Text", Icons.Outlined.Notes, selected == FeedFilter.Text) { onSelect(FeedFilter.Text) } }
        item { FeedChip("Image", Icons.Outlined.Image, selected == FeedFilter.Image) { onSelect(FeedFilter.Image) } }
        item { FeedChip("Poll", Icons.Outlined.BarChart, selected == FeedFilter.Poll) { onSelect(FeedFilter.Poll) } }
        item {
            Box {
                FeedChip(null, Icons.Outlined.Tune, false) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(if (!sortPopular) "✓  নতুন আগে" else "নতুন আগে") },
                        onClick = { onSort(false); menu = false }
                    )
                    DropdownMenuItem(
                        text = { Text(if (sortPopular) "✓  জনপ্রিয় আগে" else "জনপ্রিয় আগে") },
                        onClick = { onSort(true); menu = false }
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Composer

@Composable
fun Composer(onText: () -> Unit, onImage: () -> Unit, onPoll: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Surface(
        shape = shape,
        color = Color.White,
        shadowElevation = 1.dp,
        border = BorderStroke(0.6.dp, Color(0xFFEBF0F7)),
        modifier = Modifier.padding(horizontal = 9.dp).fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(R.drawable.a_me, 34.dp)
            Spacer(Modifier.width(12.dp))
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF3F6FA))
                    .clickable(onClick = onText)
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text("What's on your mind?", color = Grey, fontSize = 14.sp)
            }
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(34.dp).clickable(onClick = onImage), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Image, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
            Box(Modifier.size(34.dp).clickable(onClick = onPoll), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.BarChart, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
            Box(Modifier.size(34.dp).clickable(onClick = onText), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Edit, null, tint = Ink, modifier = Modifier.size(21.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- Post card

class PostActions(
    val like: (Long) -> Unit,
    val comment: (Long) -> Unit,
    val share: (Long) -> Unit,
    val bookmark: (Long) -> Unit,
    val vote: (Long, Int) -> Unit,
    val copy: (Long) -> Unit,
    val hide: (Long) -> Unit,
    val delete: (Long) -> Unit
)

@Composable
fun Tag(text: String, icon: ImageVector? = null) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(11.dp))
            .background(TagBg)
            .padding(horizontal = 9.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(12.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(text, color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Medium, lineHeight = 14.sp)
    }
}

@Composable
fun ActionItem(icon: ImageVector, tint: Color, count: Int, flip: Boolean = false, onClick: () -> Unit) {
    Row(
        modifier = Modifier.clickable(onClick = onClick).padding(vertical = 4.dp, horizontal = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon, null, tint = tint,
            modifier = Modifier
                .size(20.dp)
                .graphicsLayer { scaleX = if (flip) -1f else 1f }
        )
        Spacer(Modifier.width(8.dp))
        Text(count.toString(), color = Color(0xFF222630), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun PostCard(post: Post, actions: PostActions, modifier: Modifier = Modifier) {
    var menu by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    Surface(
        shape = shape,
        color = Color.White,
        shadowElevation = 1.dp,
        border = if (post.mine) BorderStroke(1.dp, Blue) else BorderStroke(0.6.dp, Color(0xFFEBF0F7)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 8.dp)) {
            // header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(post.avatarRes, 34.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(post.author, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 18.sp)
                        if (post.verified) {
                            Spacer(Modifier.width(5.dp))
                            Icon(Icons.Filled.Verified, null, tint = Blue, modifier = Modifier.size(15.dp))
                        }
                        if (post.mine) {
                            Spacer(Modifier.width(8.dp))
                            Tag("My Post")
                        } else if (post.poll != null) {
                            Spacer(Modifier.width(8.dp))
                            Tag("Poll", Icons.Outlined.BarChart)
                        }
                    }
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(post.time, color = Grey, fontSize = 12.sp, lineHeight = 14.sp)
                        Text("  •  ", color = Grey, fontSize = 12.sp, lineHeight = 14.sp)
                        Text("Public", color = Grey, fontSize = 12.sp, lineHeight = 14.sp)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Outlined.Public, null, tint = Grey, modifier = Modifier.size(13.dp))
                    }
                }
                Box {
                    Box(Modifier.size(32.dp).clickable { menu = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.MoreHoriz, null, tint = Ink, modifier = Modifier.size(22.dp))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("টেক্সট কপি করুন") }, onClick = { menu = false; actions.copy(post.id) })
                        DropdownMenuItem(text = { Text("পোস্ট লুকান") }, onClick = { menu = false; actions.hide(post.id) })
                        if (post.mine) {
                            DropdownMenuItem(text = { Text("মুছে ফেলুন", color = HeartRed) }, onClick = { menu = false; actions.delete(post.id) })
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            if (post.text.isNotBlank()) {
                Text(
                    post.text,
                    color = Ink,
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // image
            val uriBmp = rememberUriBitmap(post.imageUri)
            if (post.imageRes != null || post.imageUri != null) {
                Spacer(Modifier.height(9.dp))
                val imgMod = Modifier
                    .fillMaxWidth()
                    .aspectRatio(773f / 303f)
                    .clip(RoundedCornerShape(10.dp))
                if (post.imageRes != null) {
                    Image(
                        painter = painterResource(post.imageRes),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = imgMod
                    )
                } else if (uriBmp != null) {
                    Image(
                        bitmap = uriBmp,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = imgMod
                    )
                } else {
                    Box(imgMod.background(Color(0xFFEFF3F8)))
                }
            }

            // poll
            if (post.poll != null) {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    post.poll.options.forEachIndexed { i, opt ->
                        PollRow(
                            option = opt,
                            pct = post.poll.pct(i),
                            checked = post.poll.selected == i,
                            onClick = { actions.vote(post.id, i) }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.padding(start = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${post.poll.total} votes", color = Grey, fontSize = 12.sp)
                    Text("   •   ", color = Grey, fontSize = 12.sp)
                    Icon(Icons.Outlined.Schedule, null, tint = Grey, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("${post.poll.daysLeft} days left", color = Grey, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
            } else {
                Spacer(Modifier.height(6.dp))
            }

            // actions
            Row(verticalAlignment = Alignment.CenterVertically) {
                ActionItem(
                    icon = if (post.liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    tint = if (post.liked) HeartRed else Ink,
                    count = post.likes
                ) { actions.like(post.id) }
                Spacer(Modifier.width(27.dp))
                ActionItem(Icons.Outlined.ChatBubbleOutline, Ink, post.commentCount) { actions.comment(post.id) }
                Spacer(Modifier.width(27.dp))
                ActionItem(Icons.AutoMirrored.Outlined.Reply, Ink, post.shares, flip = true) { actions.share(post.id) }
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(32.dp).clickable { actions.bookmark(post.id) }, contentAlignment = Alignment.Center) {
                    Icon(
                        if (post.bookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        null,
                        tint = Ink,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PollRow(option: PollOption, pct: Int, checked: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(41.dp)
            .clip(shape)
            .background(Color(0xFFF4F7FB))
            .border(0.6.dp, Color(0xFFE6ECF4), shape)
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(14.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(if (checked) Blue else Color.Transparent)
                .then(if (checked) Modifier else Modifier.border(1.4.dp, Color(0xFF9AA5B5), RoundedCornerShape(3.dp))),
            contentAlignment = Alignment.Center
        ) {
            if (checked) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(11.dp))
        }
        Spacer(Modifier.width(20.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    option.text,
                    color = Color(0xFF5878AE),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text("${option.votes} votes", color = Grey, fontSize = 11.sp)
            }
            Spacer(Modifier.height(5.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFFE2E9F2))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((pct / 100f * 0.94f).coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF3D8FF7), Color(0xFF1F6FEA))))
                )
            }
        }
        Text(
            "$pct%",
            color = Ink,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.End,
            modifier = Modifier.width(46.dp)
        )
    }
}

// ---------------------------------------------------------------- FAB + nav

@Composable
fun Fab(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .shadow(6.dp, CircleShape, clip = false, ambientColor = Blue, spotColor = Blue)
            .size(42.dp)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2E8BFA), Color(0xFF0B63E0))))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(24.dp))
    }
}

val NavLabels = listOf("Social", "Economy", "Home", "Library", "Profile")
val NavIcons: List<ImageVector> = listOf(
    Icons.Outlined.People,
    Icons.Outlined.AccountBalanceWallet,
    Icons.Outlined.Home,
    Icons.Outlined.MenuBook,
    Icons.Outlined.Person
)

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    Surface(
        color = Color.Transparent,
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        shadowElevation = 8.dp,
        border = BorderStroke(0.6.dp, Color(0xFFE6ECF5)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .background(Brush.verticalGradient(listOf(Color(0xFFF6FAFF), Color(0xFFE9F2FD))))
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(50.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavLabels.forEachIndexed { i, label ->
                    val active = i == selected
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { onSelect(i) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(NavIcons[i], null, tint = if (active) Blue else Ink, modifier = Modifier.size(22.dp))
                        Text(
                            label,
                            color = if (active) Blue else Ink,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 12.sp
                        )
                        Spacer(Modifier.height(2.dp))
                        Box(
                            Modifier
                                .size(width = 13.dp, height = 2.5.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (active) Blue else Color(0xFFD3D9E2))
                        )
                    }
                    if (i < NavLabels.lastIndex) {
                        Box(Modifier.width(0.6.dp).height(26.dp).background(Color(0xFFD9E2EE)))
                    }
                }
            }
        }
    }
}
