package com.junaid.social

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.launch

/** How long each story page stays on screen. */
private const val STORY_PAGE_MS = 5000

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Draws a thin ring just outside the avatar (blue = not watched yet, grey = watched). Takes no layout space. */
private fun Modifier.storyRing(unseen: Boolean): Modifier = this.drawBehind {
    val stroke = 1.8.dp.toPx()
    val gap = 2.dp.toPx()
    val r = size.minDimension / 2f + gap + stroke / 2f
    val c = Offset(size.width / 2f, size.height / 2f)
    if (unseen) {
        drawCircle(
            brush = Brush.linearGradient(
                listOf(Color(0xFF2E8BFA), Color(0xFF0B63E0)),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height)
            ),
            radius = r, center = c, style = Stroke(stroke)
        )
    } else {
        drawCircle(color = Color(0xFFD3D9E2), radius = r, center = c, style = Stroke(stroke))
    }
}

// ---------------------------------------------------------------- row on the Social tab

/** Same look as before (65dp slots, 6 fit on screen) but scrolls sideways when there are more stories. */
@Composable
fun StoriesRow(
    stories: List<Story>,
    mine: Story?,
    seen: List<String>,
    userName: String,
    userPhoto: String?,
    onCreate: () -> Unit,
    onOpen: (Story) -> Unit
) {
    LazyRow(modifier = Modifier.fillMaxWidth()) {
        item(key = "me") {
            Column(
                modifier = Modifier
                    .width(65.dp)
                    .clickable { if (mine == null) onCreate() else onOpen(mine) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (mine == null) {
                    Box(
                        modifier = Modifier
                            .size(47.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCEBFD))
                            .border(1.2.dp, Color(0xFFA9C9F4), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(IPlus, null, tint = Blue, modifier = Modifier.size(21.dp))
                    }
                } else {
                    Box(Modifier.size(47.dp).storyRing(unseen = mine.id !in seen)) {
                        UserAvatar(userPhoto, userName, 47.dp)
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .padding(1.5.dp)
                                .clip(CircleShape)
                                .background(Blue)
                                .clickable(onClick = onCreate),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(IPlus, null, tint = Color.White, modifier = Modifier.size(11.dp))
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    if (mine == null) "Create" else "Your story",
                    color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium,
                    lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        items(stories, key = { it.id }) { s ->
            Column(
                modifier = Modifier.width(65.dp).clickable { onOpen(s) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(47.dp).storyRing(unseen = s.id !in seen)) {
                    val res = s.avatarRes
                    if (res != null) Avatar(res, 47.dp) else UserAvatar(s.avatarUrl, s.name, 47.dp)
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    s.name,
                    color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium,
                    lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ---------------------------------------------------------------- full-screen viewer

/**
 * Tap right = next page, tap left = previous, press and hold = pause, swipe down = close.
 * Runs through every story in [stories] starting from [startIndex].
 */
@Composable
fun StoryViewer(
    stories: List<Story>,
    startIndex: Int,
    onSeen: (Story) -> Unit,
    onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val onCloseNow by rememberUpdatedState(onClose)
    val onSeenNow by rememberUpdatedState(onSeen)

    var userIdx by remember { mutableIntStateOf(startIndex.coerceIn(0, stories.lastIndex)) }
    var itemIdx by remember { mutableIntStateOf(0) }
    var restart by remember { mutableIntStateOf(0) }
    var paused by remember { mutableStateOf(false) }
    var closing by remember { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val appear = remember { Animatable(0f) }

    fun close() {
        if (closing) return
        closing = true
        scope.launch {
            appear.animateTo(0f, tween(180))
            onCloseNow()
        }
    }

    fun next() {
        val cur = stories[userIdx]
        if (itemIdx < cur.items.lastIndex) {
            itemIdx++
        } else if (userIdx < stories.lastIndex) {
            userIdx++
            itemIdx = 0
        } else {
            close()
        }
    }

    fun prev() {
        if (itemIdx > 0) {
            itemIdx--
        } else if (userIdx > 0) {
            userIdx--
            itemIdx = 0
        } else {
            restart++
        }
    }

    val story = stories[userIdx]
    val item = story.items[itemIdx.coerceIn(0, story.items.lastIndex)]

    BackHandler { close() }

    // status-bar icons turn white while the dark viewer is open
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = view.context.findActivity()?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, view) }
        val before = ctrl?.isAppearanceLightStatusBars ?: true
        ctrl?.isAppearanceLightStatusBars = false
        onDispose { ctrl?.isAppearanceLightStatusBars = before }
    }

    LaunchedEffect(Unit) { appear.animateTo(1f, tween(220)) }
    LaunchedEffect(userIdx) { onSeenNow(stories[userIdx]) }

    // a fresh progress value for every page; pausing keeps the value, resuming continues from it
    val progress = remember(userIdx, itemIdx, restart) { Animatable(0f) }
    LaunchedEffect(userIdx, itemIdx, restart, paused, closing) {
        if (!paused && !closing) {
            val left = ((1f - progress.value) * STORY_PAGE_MS).toInt().coerceAtLeast(1)
            progress.animateTo(1f, tween(left, easing = LinearEasing))
            next()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val a = appear.value
                alpha = a * (1f - (dragY / 1200f).coerceIn(0f, 0.6f))
                scaleX = 0.92f + 0.08f * a
                scaleY = 0.92f + 0.08f * a
                translationY = dragY.coerceAtLeast(0f)
            }
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        paused = true
                        tryAwaitRelease()
                        paused = false
                    },
                    onTap = { o -> if (o.x < size.width / 3f) prev() else next() }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { paused = true },
                    onVerticalDrag = { change, dy ->
                        change.consume()
                        dragY += dy
                    },
                    onDragEnd = {
                        paused = false
                        if (dragY > 260f) close() else dragY = 0f
                    },
                    onDragCancel = {
                        paused = false
                        dragY = 0f
                    }
                )
            }
    ) {
        // ---- page content
        val bmp = rememberUriBitmap(item.imageUri?.let { Uri.parse(it) })
        val hasImage = item.imageRes != null || bmp != null
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(item.bgFrom), Color(item.bgTo))))
        ) {
            item.imageRes?.let {
                Image(
                    painter = painterResource(it),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().align(Alignment.Center)
                )
            }
            bmp?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            item.text?.let { t ->
                if (hasImage) {
                    Text(
                        t,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(horizontal = 24.dp, vertical = 28.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x66000000))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                } else {
                    Text(
                        t,
                        color = Color.White,
                        fontSize = 26.sp,
                        lineHeight = 36.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(horizontal = 30.dp)
                    )
                }
            }
        }

        // ---- progress bars + header
        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                story.items.forEachIndexed { i, _ ->
                    val f = when {
                        i < itemIdx -> 1f
                        i == itemIdx -> progress.value
                        else -> 0f
                    }
                    Box(
                        Modifier
                            .weight(1f)
                            .height(2.5.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.White.copy(alpha = 0.35f))
                    ) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f.coerceIn(0f, 1f)).background(Color.White))
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                val res = story.avatarRes
                if (res != null) Avatar(res, 34.dp) else UserAvatar(story.avatarUrl, story.name, 34.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(story.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, lineHeight = 17.sp)
                    Text(
                        relTime(System.currentTimeMillis() - item.minutesAgo * 60_000L),
                        color = Color(0xCCFFFFFF), fontSize = 11.5.sp, lineHeight = 14.sp
                    )
                }
                Box(
                    Modifier.size(36.dp).clickable { close() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Close, null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
        }
    }
}

// ---------------------------------------------------------------- create a story

/** Write a text story on a gradient, or pick a photo (with an optional caption). Kept on this phone only for now. */
@Composable
fun StoryCreator(onClose: () -> Unit, onShare: (StoryItem) -> Unit) {
    var text by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var gradIdx by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) uri = it }
    val bmp = rememberUriBitmap(uri)
    val grad = StoryGradients[gradIdx]
    val canShare = text.isNotBlank() || uri != null

    BackHandler { onClose() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F8FE))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
            Text("নতুন স্টোরি", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (canShare) Blue else Color(0xFFC9D3E3))
                    .clickable(enabled = canShare) {
                        onShare(
                            StoryItem(
                                text = text.trim().ifBlank { null },
                                imageUri = uri?.toString(),
                                bgFrom = grad.first,
                                bgTo = grad.second,
                                minutesAgo = 0
                            )
                        )
                    }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) {
                Text("Share", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
        }

        // preview
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.verticalGradient(listOf(Color(grad.first), Color(grad.second))))
        ) {
            bmp?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            val hasImage = bmp != null
            Box(
                Modifier
                    .align(if (hasImage) Alignment.BottomCenter else Alignment.Center)
                    .padding(horizontal = 22.dp, vertical = if (hasImage) 18.dp else 0.dp)
            ) {
                if (text.isEmpty()) {
                    Text(
                        if (hasImage) "ক্যাপশন লিখুন..." else "কিছু লিখুন...",
                        color = Color(0xB3FFFFFF),
                        fontSize = if (hasImage) 16.sp else 26.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                BasicTextField(
                    value = text,
                    onValueChange = { if (it.length <= 160) text = it },
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = if (hasImage) 16.sp else 26.sp,
                        lineHeight = if (hasImage) 22.sp else 36.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    ),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // tools
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE1E9F5), RoundedCornerShape(12.dp))
                    .clickable { if (uri == null) picker.launch("image/*") else uri = null }
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            ) {
                Text(if (uri == null) "📷 ছবি" else "✖ ছবি বাদ", color = Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.width(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StoryGradients.forEachIndexed { i, g ->
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Brush.verticalGradient(listOf(Color(g.first), Color(g.second))))
                            .border(if (i == gradIdx) 2.dp else 0.dp, if (i == gradIdx) Blue else Color.Transparent, CircleShape)
                            .clickable { gradIdx = i }
                    )
                }
            }
        }
    }
}
