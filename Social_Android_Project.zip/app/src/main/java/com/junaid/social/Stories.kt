package com.junaid.social

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.Shadow
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Public
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Share
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.launch

/** How long each story page stays on screen. */
private const val STORY_PAGE_MS = 5000

internal fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Where the first gap of a split ring sits (degrees, 0 = 3 o'clock, clockwise). -135 = top-left. */
private const val RING_START_DEG = -135f

/**
 * Draws a ring just outside the avatar (#0055FF to #00DDFF gradient = not watched yet, grey = watched). Takes no layout space.
 * One story = a full circle; [count] stories = the ring is cut into that many equal slices, each drawn as an arc with
 * softly rounded ends and a small gap to its neighbours. The first gap sits at the top-left, so two stories are split
 * into two halves along the \\ diagonal.
 */
private fun Modifier.storyRing(unseen: Boolean, count: Int = 1): Modifier = this.drawBehind {
    val stroke = 2.4.dp.toPx()
    val gap = 2.dp.toPx()
    val r = size.minDimension / 2f + gap + stroke / 2f
    val c = Offset(size.width / 2f, size.height / 2f)
    val brush: Brush = if (unseen) {
        Brush.linearGradient(
            listOf(Color(0xFF0055FF), Color(0xFF00DDFF)),
            start = Offset(0f, 0f),
            end = Offset(size.width, size.height)
        )
    } else {
        SolidColor(Color(0xFFD3D9E2))
    }
    if (count <= 1) {
        drawCircle(brush = brush, radius = r, center = c, style = Stroke(stroke))
    } else {
        val slice = 360f / count
        // round ends stick out by half a stroke, so the arcs are shortened by that much on both sides
        val capDeg = Math.toDegrees(((stroke / 2f) / r).toDouble()).toFloat()
        // visible gap between two arcs is about 1.4dp long
        val gapDeg = Math.toDegrees((1.4.dp.toPx() / r).toDouble()).toFloat()
        val sweep = (slice - gapDeg - 2f * capDeg).coerceAtLeast(1f)
        for (i in 0 until count) {
            drawArc(
                brush = brush,
                startAngle = RING_START_DEG + i * slice + gapDeg / 2f + capDeg,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(c.x - r, c.y - r),
                size = Size(r * 2f, r * 2f),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
    }
}

// ---------------------------------------------------------------- row on the Social tab

/** 65dp slots. "Create" is always first, then "Your Story" (once you have one), then everyone else. Scrolls sideways. */
@Composable
fun StoriesRow(
    stories: List<Story>,
    mine: Story?,
    seen: List<String>,
    userName: String,
    userPhoto: String?,
    onCreate: () -> Unit,
    onOpen: (Story) -> Unit
) {
    LazyRow(modifier = Modifier.fillMaxWidth()) {
        item(key = "create") {
            Column(
                modifier = Modifier.width(65.dp).clickable(onClick = onCreate),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(47.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDCEBFD))
                        .border(1.2.dp, Color(0xFFA9C9F4), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(IPlus, null, tint = Blue, modifier = Modifier.size(21.dp))
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    "Create",
                    color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium,
                    lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (mine != null) {
            item(key = "me") {
                Column(
                    modifier = Modifier.width(65.dp).clickable { onOpen(mine) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(47.dp).storyRing(unseen = mine.id !in seen, count = mine.items.size)) {
                        UserAvatar(userPhoto, userName, 47.dp)
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "Your Story",
                        color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium,
                        lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        items(stories, key = { it.id }) { s ->
            Column(
                modifier = Modifier.width(65.dp).clickable { onOpen(s) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(47.dp).storyRing(unseen = s.id !in seen, count = s.items.size)) {
                    val res = s.avatarRes
                    if (res != null) Avatar(res, 47.dp) else UserAvatar(s.avatarUrl, s.name, 47.dp)
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    s.name,
                    color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium,
                    lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ---------------------------------------------------------------- full-screen viewer

private val GlassFill = Color(0x59000000)
private val GlassLine = Color(0x40FFFFFF)

@Composable
private fun SmileyIcon(iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val s = this.size.minDimension
        val sw = s * 0.075f
        drawCircle(Color.White, radius = s * 0.44f, style = Stroke(sw))
        drawCircle(Color.White, radius = s * 0.055f, center = Offset(s * 0.36f, s * 0.42f))
        drawCircle(Color.White, radius = s * 0.055f, center = Offset(s * 0.64f, s * 0.42f))
        drawArc(
            Color.White,
            startAngle = 25f,
            sweepAngle = 130f,
            useCenter = false,
            topLeft = Offset(s * 0.28f, s * 0.28f),
            size = Size(s * 0.44f, s * 0.44f),
            style = Stroke(sw, cap = StrokeCap.Round)
        )
    }
}

@Composable
private fun PlaneIcon(iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val w = this.size.width
        val h = this.size.height
        val p = Path().apply {
            moveTo(w * 0.06f, h * 0.08f)
            lineTo(w * 0.96f, h * 0.5f)
            lineTo(w * 0.06f, h * 0.92f)
            lineTo(w * 0.26f, h * 0.5f)
            close()
        }
        drawPath(p, Color.White)
    }
}

@Composable
private fun ThinClose(iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val s = this.size.minDimension
        val sw = s * 0.09f
        drawLine(Color.White, Offset(s * 0.15f, s * 0.15f), Offset(s * 0.85f, s * 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(Color.White, Offset(s * 0.85f, s * 0.15f), Offset(s * 0.15f, s * 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

/** Slides up a little and fades in when [key] changes (a new story page, a new comment). */
@Composable
private fun Modifier.riseIn(key: Any, delayMs: Int): Modifier {
    val p = remember(key) { Animatable(0f) }
    LaunchedEffect(key) {
        delay(delayMs.toLong())
        p.animateTo(1f, tween(400, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer {
        translationY = (1f - p.value) * 16.dp.toPx()
        alpha = p.value
    }
}

private val SoftShadow = TextStyle(shadow = Shadow(Color(0x73000000), Offset(0f, 1.5f), 5f))

/** Every time [trigger] goes up: a soft red glow spreads out from the like button and three small hearts drift up and fade. */
@Composable
private fun FloatingHearts(trigger: Int) {
    Box(Modifier.size(COMMENT_BAR_H)) {
        if (trigger > 0) {
            val p = remember(trigger) { Animatable(0f) }
            LaunchedEffect(trigger) { p.animateTo(1f, tween(1100, easing = FastOutSlowInEasing)) }
            val t = p.value
            if (t < 1f) {
                Canvas(Modifier.matchParentSize()) {
                    val rad = 14.dp.toPx() + 22.dp.toPx() * t
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFFFF3B5C).copy(alpha = (1f - t) * 0.4f), Color.Transparent),
                            center = Offset(this.size.width / 2f, this.size.height / 2f),
                            radius = rad
                        ),
                        radius = rad
                    )
                }
                listOf(-9f, 2f, 11f).forEachIndexed { i, dx ->
                    val d = ((t - i * 0.12f) / (1f - i * 0.12f)).coerceIn(0f, 1f)
                    if (d > 0f && d < 1f) {
                        Icon(
                            IHeartFill, null,
                            tint = if (i == 1) Color(0xFFFF3B5C) else Color(0xFFFF8FA9),
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(if (i == 1) 11.dp else 8.dp)
                                .graphicsLayer {
                                    translationY = -(8f + 40f * d).dp.toPx()
                                    translationX = (dx + sin(d * 3f) * 4f).dp.toPx()
                                    alpha = sin(d * Math.PI.toFloat()) * 0.85f
                                }
                        )
                    }
                }
            }
        }
    }
}

/** Glass-look chip showing one comment: avatar, who wrote it, and what they said. Same height and corner as the comment box. */
@Composable
private fun StoryCommentChip(
    name: String, text: String, avatarRes: Int?, avatarUrl: String?, modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .height(COMMENT_BAR_H)
            .clip(shape)
            .background(GlassFill)
            .border(1.dp, GlassLine, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(start = 7.dp, end = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(26.dp)) {
            if (avatarRes != null) Avatar(avatarRes, 26.dp) else UserAvatar(avatarUrl, name, 26.dp)
        }
        Spacer(Modifier.width(9.dp))
        Column(verticalArrangement = Arrangement.Center) {
            Text(
                name, color = Color(0xB3FFFFFF), fontSize = 8.5.sp, lineHeight = 10.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                text, color = Color.White, fontSize = 12.5.sp, lineHeight = 16.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Glass-look chip: gradient music badge, the song on one line, and a little moving equaliser. */
@Composable
private fun StoryMusicChip(label: String, playing: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    val accent = Color(0xFFFF5C8A)
    val inf = rememberInfiniteTransition(label = "equaliser")
    val b1 by inf.animateFloat(0.35f, 1f, infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse), label = "b1")
    val b2 by inf.animateFloat(1f, 0.3f, infiniteRepeatable(tween(430, easing = LinearEasing), RepeatMode.Reverse), label = "b2")
    val b3 by inf.animateFloat(0.5f, 0.95f, infiniteRepeatable(tween(610, easing = LinearEasing), RepeatMode.Reverse), label = "b3")
    val b4 by inf.animateFloat(0.9f, 0.4f, infiniteRepeatable(tween(570, easing = LinearEasing), RepeatMode.Reverse), label = "b4")
    Row(
        modifier
            .height(COMMENT_BAR_H)
            .clip(shape)
            .background(GlassFill)
            .border(1.dp, GlassLine, shape)
            .clickable(onClick = onToggle)
            .padding(start = 5.dp, end = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFFF3D81), Color(0xFFFF9A44)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (playing) Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(9.dp))
        Text(
            label, color = if (playing) Color.White else Color(0xB3FFFFFF), fontSize = 12.5.sp, lineHeight = 16.sp,
            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Spacer(Modifier.width(12.dp))
        Canvas(Modifier.size(width = 14.dp, height = 12.dp)) {
            val bar = this.size.width / 7f
            listOf(b1, b2, b3, b4).map { if (playing) it else 0.28f }.forEachIndexed { i, f ->
                val barH = this.size.height * f
                drawRoundRect(
                    if (playing) accent else accent.copy(alpha = 0.5f),
                    topLeft = Offset(i * 2f * bar, this.size.height - barH),
                    size = Size(bar, barH),
                    cornerRadius = CornerRadius(bar / 2f)
                )
            }
        }
    }
}

/** Comment box (smiley, text, gradient send button) in the glass look. */
@Composable
private fun StoryCommentField(
    text: String,
    onText: (String) -> Unit,
    onFocus: (Boolean) -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .height(COMMENT_BAR_H)
            .clip(shape)
            .background(GlassFill)
            .border(1.dp, GlassLine, shape)
            .padding(start = 8.dp, end = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(26.dp).clickable { if (text.length + 2 <= COMMENT_MAX_CHARS) onText(text + "🥰") },
            contentAlignment = Alignment.Center
        ) { SmileyIcon(21.dp) }
        Spacer(Modifier.width(7.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (text.isEmpty()) {
                Text("Comment something...", color = Color(0xB3FFFFFF), fontSize = 13.sp, maxLines = 1)
            }
            PasteSafeField(
                value = text,
                onValueChange = onText,
                maxChars = COMMENT_MAX_CHARS,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                modifier = Modifier.fillMaxWidth().onFocusChanged { onFocus(it.isFocused) }
            )
        }
        Box(
            Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFFF3D81), Color(0xFFFF9A44))))
                .clickable(onClick = onSend),
            contentAlignment = Alignment.Center
        ) { PlaneIcon(14.dp) }
    }
}

/** Heart with the like count under it, glass look. [pop] goes up on every tap, so every tap gives the heart a soft swell. */
@Composable
private fun StoryLikeButton(liked: Boolean, count: Int, pop: Int, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val anim = remember { Animatable(1f) }
    LaunchedEffect(pop) {
        if (pop > 0) {
            anim.snapTo(0f)
            anim.animateTo(1f, tween(520, easing = LinearEasing))
        }
    }
    Column(
        Modifier
            .size(COMMENT_BAR_H)
            .clip(shape)
            .background(GlassFill)
            .border(1.dp, GlassLine, shape)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            IHeartFill, null,
            tint = Color(0xFFFF3B5C),
            modifier = Modifier
                .size(18.dp)
                .graphicsLayer {
                    val t = anim.value
                    // a gentle swell and back, no jerk
                    val sc = 1f + 0.2f * sin(t * Math.PI.toFloat())
                    scaleX = sc
                    scaleY = sc
                }
        )
        Text(
            formatCount(count.toLong()),
            color = Color.White, fontSize = 9.5.sp, lineHeight = 11.sp, fontWeight = FontWeight.SemiBold
        )
    }
}

/** One comment shown over a story page. */
private data class StoryComment(val name: String, val text: String, val avatarRes: Int?, val avatarUrl: String?)

private val SheetInk = Color(0xFF1B2330)
private val SheetGrey = Color(0xFF8A93A3)
private val SheetSoft = Color(0xFFF3F6FA)

/**
 * A white panel that slides up from the bottom over a dimmed story. Tapping outside it, pressing Back, or swiping
 * its handle (the little bar on top) downwards closes it.
 */
@Composable
private fun StoryBottomSheet(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(260, easing = FastOutSlowInEasing), label = "sheet")
    var drag by remember { mutableStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    val dragSpec: AnimationSpec<Float> = if (dragging) snap() else tween(200, easing = FastOutSlowInEasing)
    val dragShown by animateFloatAsState(drag, dragSpec, label = "sheetDrag")
    LaunchedEffect(visible) {
        if (visible) {
            drag = 0f
            dragging = false
        }
    }
    BackHandler(enabled = visible) { onDismiss() }
    if (a > 0.001f) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f * a))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
            )
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .graphicsLayer { translationY = (1f - a) * size.height + dragShown }
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(Color.White)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {})
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(start = 16.dp, end = 16.dp, bottom = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // the handle: drag it down to close the sheet
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .pointerInput(Unit) {
                            detectVerticalDragGestures(
                                onDragStart = { dragging = true },
                                onVerticalDrag = { change, amount ->
                                    change.consume()
                                    drag = (drag + amount).coerceAtLeast(0f)
                                },
                                onDragEnd = {
                                    dragging = false
                                    if (drag > 80.dp.toPx()) onDismiss() else drag = 0f
                                },
                                onDragCancel = {
                                    dragging = false
                                    drag = 0f
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(width = 40.dp, height = 4.dp).clip(CircleShape).background(Color(0xFFD0D5DD)))
                }
                content()
            }
        }
    }
}

/** One option row inside a bottom sheet. */
@Composable
private fun SheetRow(icon: ImageVector, label: String, danger: Boolean = false, onClick: () -> Unit) {
    val tint = if (danger) Color(0xFFE5383B) else SheetInk
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, color = tint, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

/** A comment can have at most this many characters. */
private const val COMMENT_MAX_CHARS = 40

/** Height of the comment box; the like button uses the same height. */
private val COMMENT_BAR_H = 40.dp

/** How long each comment stays on screen, and the pause before the next one. */
private const val COMMENT_SHOW_MS = 2000L
private const val COMMENT_GAP_MS = 250L

/**
 * Tap = next story (then the next person's), press and hold = pause (one finger only), swipe down = close.
 * Pauses while you type a comment or have the menu open. Runs through every story in [stories] from [startIndex].
 * Comments and likes only live on this phone for now (stories are still a demo).
 */
@Composable
fun StoryViewer(
    stories: List<Story>,
    startIndex: Int,
    viewerName: String,
    viewerPhoto: String?,
    onSeen: (Story) -> Unit,
    onDelete: (storyId: String, itemIndex: Int) -> Unit,
    onMute: (storyId: String) -> Unit,
    onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val onCloseNow by rememberUpdatedState(onClose)
    val onSeenNow by rememberUpdatedState(onSeen)
    val onDeleteNow by rememberUpdatedState(onDelete)
    val onMuteNow by rememberUpdatedState(onMute)

    var userIdx by remember { mutableIntStateOf(startIndex.coerceIn(0, stories.lastIndex)) }
    var itemIdx by remember { mutableIntStateOf(0) }
    var restart by remember { mutableIntStateOf(0) }
    var holding by remember { mutableStateOf(false) }
    var typing by remember { mutableStateOf(false) }
    // bottom sheet: 0 = none, 1 = story options, 2 = one of my own comments (actions, or editing it)
    var sheet by remember { mutableIntStateOf(0) }
    var sheetComment by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf(false) }
    var editText by remember { mutableStateOf("") }
    val editFocus = remember { FocusRequester() }
    val hiddenComments = remember { mutableStateListOf<String>() }
    var closing by remember { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var draft by remember { mutableStateOf("") }
    // comments written on this phone (newest first) and how many times each page was liked (no limit)
    val sent = remember { mutableStateMapOf<String, List<String>>() }
    val likeTaps = remember { mutableStateMapOf<String, Int>() }
    val appear = remember { Animatable(0f) }
    var burst by remember { mutableIntStateOf(0) }
    val paused = holding || typing || sheet != 0
    // a long press only holds the progress bar; the song, the comments and all controls keep running as they are
    val chrome = 1f

    fun close(after: (() -> Unit)? = null) {
        if (closing) return
        closing = true
        scope.launch {
            appear.animateTo(0f, tween(180))
            after?.invoke()
            onCloseNow()
        }
    }

    fun next() {
        val cur = stories[userIdx]
        if (itemIdx < cur.items.lastIndex) {
            itemIdx++
        } else if (userIdx < stories.lastIndex) {
            userIdx++
            itemIdx = 0
        } else {
            close()
        }
    }

    fun prev() {
        if (itemIdx > 0) {
            itemIdx--
        } else if (userIdx > 0) {
            userIdx--
            itemIdx = 0
        } else {
            restart++
        }
    }

    fun sendComment() {
        val t = draft.trim()
        if (t.isNotEmpty()) {
            val k = "$userIdx:$itemIdx"
            sent[k] = listOf(t) + (sent[k] ?: emptyList())
            draft = ""
        }
        focus.clearFocus()
    }

    val story = stories[userIdx]
    val item = story.items[itemIdx.coerceIn(0, story.items.lastIndex)]
    val key = "$userIdx:$itemIdx"

    // every comment of this page, one after the other: each shows for a moment, fades away, then the next comes
    val comments = buildList<StoryComment> {
        sent[key]?.forEach { add(StoryComment(viewerName, it, null, viewerPhoto)) }
        val ct = item.commentText
        if (ct != null && "$key|$ct" !in hiddenComments) add(StoryComment(item.commentName ?: "", ct, item.commentAvatarRes, null))
    }
    var cIdx by remember(key) { mutableIntStateOf(0) }
    var cShow by remember(key) { mutableStateOf(false) }
    val commentSheet = sheet == 2
    LaunchedEffect(key, comments.size, commentSheet) {
        if (commentSheet) {
            // one of my comments is open in the sheet: keep it on screen and do not change it
            cIdx = sheetComment.coerceAtLeast(0)
            cShow = true
            return@LaunchedEffect
        }
        delay(260)
        // one comment: shown once, then gone. Two or more: they keep coming round again and again, never stopping
        do {
            for (i in comments.indices) {
                cIdx = i
                cShow = true
                delay(COMMENT_SHOW_MS)
                cShow = false
                delay(COMMENT_GAP_MS)
            }
        } while (comments.size > 1)
    }

    BackHandler { if (typing) focus.clearFocus() else close() }

    // status-bar icons turn white while the dark viewer is open
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = view.context.findActivity()?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, view) }
        val before = ctrl?.isAppearanceLightStatusBars ?: true
        ctrl?.isAppearanceLightStatusBars = false
        onDispose { ctrl?.isAppearanceLightStatusBars = before }
    }

    LaunchedEffect(Unit) { appear.animateTo(1f, tween(220)) }
    LaunchedEffect(userIdx) { onSeenNow(stories[userIdx]) }

    // a fresh progress value for every page; pausing keeps the value, resuming continues from it
    val progress = remember(userIdx, itemIdx, restart) { Animatable(0f) }
    LaunchedEffect(userIdx, itemIdx, restart, paused, closing) {
        if (!paused && !closing) {
            val left = ((1f - progress.value) * STORY_PAGE_MS).toInt().coerceAtLeast(1)
            progress.animateTo(1f, tween(left, easing = LinearEasing))
            next()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val a = appear.value
                alpha = a * (1f - (dragY / 1200f).coerceIn(0f, 0.6f))
                scaleX = 0.92f + 0.08f * a
                scaleY = 0.92f + 0.08f * a
                translationY = dragY.coerceAtLeast(0f)
            }
            .background(Color.Black)
            .pointerInput(Unit) {
                // One finger only. A tap goes to the next story. A finger that stays down holds the progress bar
                // until it is lifted. Any other finger is ignored while that happens.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = true)
                    val id = down.id
                    val slop = viewConfiguration.touchSlop
                    var lifted = false
                    val stillDown = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == id }
                            if (ch == null || ch.isConsumed) break
                            if (ch.changedToUpIgnoreConsumed()) {
                                lifted = true
                                break
                            }
                            if ((ch.position - down.position).getDistance() > slop) break
                        }
                    } == null
                    if (!stillDown) {
                        if (lifted) {
                            if (typing) focus.clearFocus() else next()
                        }
                        return@awaitEachGesture
                    }
                    holding = true
                    try {
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == id }
                            if (ch == null || !ch.pressed) break
                        }
                    } finally {
                        holding = false
                    }
                }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { holding = true },
                    onVerticalDrag = { change, dy ->
                        change.consume()
                        dragY += dy
                    },
                    onDragEnd = {
                        holding = false
                        if (dragY > 260f) close() else dragY = 0f
                    },
                    onDragCancel = {
                        holding = false
                        dragY = 0f
                    }
                )
            }
    ) {
        // ---- page content
        val bmp = rememberUriBitmap(item.imageUri?.let { Uri.parse(it) })
        val hasImage = item.imageRes != null || bmp != null
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(item.bgFrom), Color(item.bgTo))))
        ) {
            item.imageRes?.let {
                val painter = painterResource(it)
                val sz = painter.intrinsicSize
                val ratio = if (sz.width.isFinite() && sz.height.isFinite() && sz.height > 0f) sz.width / sz.height else 1f
                // portrait-ish pictures fill the whole screen, wide ones stay whole and centred
                if (ratio <= 0.8f) {
                    Image(
                        painter, null, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            val z = 1f + 0.06f * progress.value
                            scaleX = z
                            scaleY = z
                        }
                    )
                } else {
                    Image(
                        painter, null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().align(Alignment.Center).graphicsLayer {
                            val z = 1f + 0.06f * progress.value
                            scaleX = z
                            scaleY = z
                        }
                    )
                }
            }
            bmp?.let {
                val ratio = it.width.toFloat() / it.height.toFloat()
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = if (ratio <= 0.8f) ContentScale.Crop else ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        val z = 1f + 0.06f * progress.value
                        scaleX = z
                        scaleY = z
                    }
                )
            }
            item.text?.let { t ->
                if (hasImage) {
                    Text(
                        t,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(horizontal = 24.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x66000000))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                } else {
                    Text(
                        t,
                        color = Color.White,
                        fontSize = 26.sp,
                        lineHeight = 36.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(horizontal = 30.dp)
                    )
                }
            }
        }

        // soft dark fades so the white controls always read
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(170.dp)
                .graphicsLayer { alpha = chrome }
                .background(Brush.verticalGradient(listOf(Color(0x8C000000), Color.Transparent)))
        )
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(300.dp)
                .graphicsLayer { alpha = chrome }
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xB3000000))))
        )

        // ---- progress bars + header
        Column(
            Modifier
                .fillMaxWidth()
                .graphicsLayer { alpha = chrome }
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                story.items.forEachIndexed { i, _ ->
                    val f = when {
                        i < itemIdx -> 1f
                        i == itemIdx -> progress.value
                        else -> 0f
                    }
                    Box(
                        Modifier
                            .weight(1f)
                            .height(2.5.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.White.copy(alpha = 0.35f))
                    ) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f.coerceIn(0f, 1f)).background(Color.White))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp)) {
                    val res = story.avatarRes
                    if (res != null) Avatar(res, 42.dp) else UserAvatar(story.avatarUrl, story.name, 42.dp)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            story.name, color = Color.White, fontSize = 14.5.sp, lineHeight = 17.sp,
                            fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = SoftShadow,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (story.verified) {
                            Spacer(Modifier.width(6.dp))
                            Icon(IVerified, null, tint = Color.Unspecified, modifier = Modifier.size(13.2.dp))
                        }
                    }
                    Spacer(Modifier.height(0.3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val soft = Color(0xE6FFFFFF)
                        Text(
                            relTime(System.currentTimeMillis() - item.minutesAgo * 60_000L),
                            color = soft, fontSize = 11.7.sp, lineHeight = 12.sp, style = SoftShadow
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("•", color = soft, fontSize = 9.sp, lineHeight = 12.sp, style = SoftShadow)
                        Spacer(Modifier.width(4.dp))
                        Text("Public", color = soft, fontSize = 11.7.sp, lineHeight = 12.sp, style = SoftShadow)
                        Spacer(Modifier.width(5.dp))
                        Icon(Icons.Outlined.Public, null, tint = soft, modifier = Modifier.size(13.dp))
                    }
                }
                // three dots (opens the options sheet)
                Box(
                    Modifier.size(38.dp).clickable { sheet = 1 },
                    contentAlignment = Alignment.Center
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(3.5.dp)) {
                        repeat(3) { Box(Modifier.size(4.5.dp).clip(CircleShape).background(Color.White)) }
                    }
                }
                Box(
                    Modifier.size(38.dp).clickable { close() },
                    contentAlignment = Alignment.Center
                ) { ThinClose(24.dp) }
            }
        }

        // ---- bottom: comment, song, comment box + like
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .graphicsLayer { alpha = chrome }
                .navigationBarsPadding()
                .imePadding()
                .padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (comments.isNotEmpty()) {
                // fixed-height slot, so the song chip and the comment box never jump when a comment comes or goes
                Box(Modifier.fillMaxWidth().height(40.dp), contentAlignment = Alignment.BottomStart) {
                    val cur = comments.getOrNull(cIdx)
                    val cAlpha by animateFloatAsState(if (cShow) 1f else 0f, tween(350), label = "commentFade")
                    if (cur != null && cAlpha > 0.01f) {
                        StoryCommentChip(
                            cur.name, cur.text, cur.avatarRes, cur.avatarUrl,
                            Modifier.graphicsLayer {
                                alpha = cAlpha
                                translationY = (1f - cAlpha) * 12.dp.toPx()
                            },
                            onClick = {
                                sheetComment = cIdx
                                editing = false
                                sheet = 2
                            }
                        )
                    }
                }
            }
            item.music?.let {
                var musicOn by remember(key) { mutableStateOf(true) }
                StoryMusicChip(it, musicOn, { musicOn = !musicOn }, Modifier.riseIn("$key:m", 420))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                StoryCommentField(
                    text = draft,
                    onText = { draft = it },
                    onFocus = { typing = it },
                    onSend = { sendComment() },
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(10.dp))
                val taps = likeTaps[key] ?: 0
                Box {
                    StoryLikeButton(taps > 0, item.likes + taps, burst) {
                        likeTaps[key] = (likeTaps[key] ?: 0) + 1
                        burst++
                    }
                    FloatingHearts(burst)
                }
            }
        }

        // ---- bottom sheets
        val ctx = LocalContext.current
        val clipboard = LocalClipboardManager.current

        // 1) the three dots: options for the whole story
        StoryBottomSheet(visible = sheet == 1, onDismiss = { sheet = 0 }) {
            Text(story.name, color = SheetGrey, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            val storyText = item.text
            SheetRow(Icons.Outlined.Share, "Share story") {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, if (storyText != null) "${story.name}: $storyText" else "${story.name}'s story")
                }
                runCatching {
                    ctx.startActivity(Intent.createChooser(send, "Share story").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                sheet = 0
            }
            if (storyText != null) {
                SheetRow(Icons.Outlined.ContentCopy, "Copy text") {
                    clipboard.setText(AnnotatedString(storyText))
                    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                    sheet = 0
                }
            }
            if (story.mine) {
                SheetRow(Icons.Outlined.Delete, "Delete story", danger = true) {
                    sheet = 0
                    val sid = story.id
                    val idx = itemIdx
                    close { onDeleteNow(sid, idx) }
                }
            } else {
                SheetRow(Icons.Outlined.VisibilityOff, "Hide this story") {
                    sheet = 0
                    val sid = story.id
                    close { onMuteNow(sid) }
                }
                SheetRow(Icons.Outlined.Flag, "Report story", danger = true) {
                    Toast.makeText(ctx, "Thanks, we will look into it", Toast.LENGTH_SHORT).show()
                    sheet = 0
                }
            }
        }

        // 2) a comment: mine = edit / copy / delete, somebody else's = copy / reply / hide / report
        LaunchedEffect(sheet, editing) {
            if (sheet == 2 && editing) {
                delay(150)
                runCatching { editFocus.requestFocus() }
            }
        }
        StoryBottomSheet(visible = sheet == 2, onDismiss = { sheet = 0 }) {
            val cm = comments.getOrNull(sheetComment)
            val mineC = sheetComment < (sent[key]?.size ?: 0)
            if (cm != null) {
                if (!editing) {
                    Text(if (mineC) "Your comment" else cm.name, color = SheetGrey, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(SheetSoft)
                            .padding(horizontal = 14.dp, vertical = 11.dp)
                    ) {
                        Text(cm.text, color = SheetInk, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(6.dp))
                    if (mineC) {
                        SheetRow(Icons.Outlined.Edit, "Edit comment") {
                            editText = cm.text
                            editing = true
                        }
                    }
                    SheetRow(Icons.Outlined.ContentCopy, "Copy comment") {
                        clipboard.setText(AnnotatedString(cm.text))
                        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                        sheet = 0
                    }
                    if (mineC) {
                        SheetRow(Icons.Outlined.Delete, "Delete comment", danger = true) {
                            val list = (sent[key] ?: emptyList()).toMutableList()
                            if (sheetComment in list.indices) list.removeAt(sheetComment)
                            sent[key] = list
                            sheet = 0
                        }
                    } else {
                        SheetRow(Icons.Outlined.ChatBubbleOutline, "Reply") {
                            draft = cutToLimit("@${cm.name} ", COMMENT_MAX_CHARS)
                            sheet = 0
                        }
                        SheetRow(Icons.Outlined.VisibilityOff, "Hide comment") {
                            hiddenComments.add("$key|${cm.text}")
                            sheet = 0
                        }
                        SheetRow(Icons.Outlined.Flag, "Report comment", danger = true) {
                            Toast.makeText(ctx, "Thanks, we will look into it", Toast.LENGTH_SHORT).show()
                            sheet = 0
                        }
                    }
                } else {
                    Text("Edit comment", color = SheetGrey, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(COMMENT_BAR_H)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SheetSoft)
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PasteSafeField(
                            value = editText,
                            onValueChange = { editText = it },
                            maxChars = COMMENT_MAX_CHARS,
                            singleLine = true,
                            textStyle = TextStyle(color = SheetInk, fontSize = 14.sp),
                            cursorBrush = SolidColor(Color(0xFF0055FF)),
                            modifier = Modifier.fillMaxWidth().focusRequester(editFocus)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF0055FF), Color(0xFF00DDFF))))
                            .clickable {
                                val t = editText.trim()
                                if (t.isNotEmpty()) {
                                    val list = (sent[key] ?: emptyList()).toMutableList()
                                    if (sheetComment in list.indices) list[sheetComment] = t
                                    sent[key] = list
                                }
                                editing = false
                                sheet = 0
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Save", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { editing = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Cancel", color = SheetGrey, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // while one finger holds the story, every other touch is swallowed (no multi-touch)
        if (holding) {
            Box(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val e = awaitPointerEvent(PointerEventPass.Initial)
                            e.changes.forEach { it.consume() }
                        }
                    }
                }
            )
        }
    }
}

// ---------------------------------------------------------------- create a story

/** Write a text story on a gradient, or pick a photo (with an optional caption). Kept on this phone only for now. */
@Composable
fun StoryCreator(onClose: () -> Unit, onShare: (StoryItem) -> Unit) {
    var text by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var gradIdx by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) uri = it }
    val bmp = rememberUriBitmap(uri)
    val grad = StoryGradients[gradIdx]
    val canShare = text.isNotBlank() || uri != null

    BackHandler { onClose() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F8FE))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
            Text("New story", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (canShare) Blue else Color(0xFFC9D3E3))
                    .clickable(enabled = canShare) {
                        onShare(
                            StoryItem(
                                text = text.trim().ifBlank { null },
                                imageUri = uri?.toString(),
                                bgFrom = grad.first,
                                bgTo = grad.second,
                                minutesAgo = 0
                            )
                        )
                    }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) {
                Text("Share", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
        }

        // preview
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.verticalGradient(listOf(Color(grad.first), Color(grad.second))))
        ) {
            bmp?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            val hasImage = bmp != null
            Box(
                Modifier
                    .align(if (hasImage) Alignment.BottomCenter else Alignment.Center)
                    .padding(horizontal = 22.dp, vertical = if (hasImage) 18.dp else 0.dp)
            ) {
                if (text.isEmpty()) {
                    Text(
                        if (hasImage) "Write a caption..." else "Type something...",
                        color = Color(0xB3FFFFFF),
                        fontSize = if (hasImage) 16.sp else 26.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                PasteSafeField(
                    value = text,
                    onValueChange = { text = it },
                    maxChars = 160,
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = if (hasImage) 16.sp else 26.sp,
                        lineHeight = if (hasImage) 22.sp else 36.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    ),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // tools
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE1E9F5), RoundedCornerShape(12.dp))
                    .clickable { if (uri == null) picker.launch("image/*") else uri = null }
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            ) {
                Text(if (uri == null) "📷 Photo" else "✖ Remove photo", color = Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.width(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StoryGradients.forEachIndexed { i, g ->
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Brush.verticalGradient(listOf(Color(g.first), Color(g.second))))
                            .border(if (i == gradIdx) 2.dp else 0.dp, if (i == gradIdx) Blue else Color.Transparent, CircleShape)
                            .clickable { gradIdx = i }
                    )
                }
            }
        }
    }
}
