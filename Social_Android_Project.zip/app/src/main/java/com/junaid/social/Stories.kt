package com.junaid.social

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.launch

/** How long each story page stays on screen. */
private const val STORY_PAGE_MS = 5000

internal fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Draws a thin ring just outside the avatar (blue = not watched yet, grey = watched). Takes no layout space. */
private fun Modifier.storyRing(unseen: Boolean): Modifier = this.drawBehind {
    val stroke = 1.8.dp.toPx()
    val gap = 2.dp.toPx()
    val r = size.minDimension / 2f + gap + stroke / 2f
    val c = Offset(size.width / 2f, size.height / 2f)
    if (unseen) {
        drawCircle(
            brush = Brush.linearGradient(
                listOf(Color(0xFF2E8BFA), Color(0xFF0B63E0)),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height)
            ),
            radius = r, center = c, style = Stroke(stroke)
        )
    } else {
        drawCircle(color = Color(0xFFD3D9E2), radius = r, center = c, style = Stroke(stroke))
    }
}

// ---------------------------------------------------------------- row on the Social tab

/** 65dp slots. "Create" is always first, then "Your Story" (once you have one), then everyone else. Scrolls sideways. */
@Composable
fun StoriesRow(
    stories: List<Story>,
    mine: Story?,
    seen: List<String>,
    userName: String,
    userPhoto: String?,
    onCreate: () -> Unit,
    onOpen: (Story) -> Unit
) {
    LazyRow(modifier = Modifier.fillMaxWidth()) {
        item(key = "create") {
            Column(
                modifier = Modifier.width(65.dp).clickable(onClick = onCreate),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(47.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDCEBFD))
                        .border(1.2.dp, Color(0xFFA9C9F4), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(IPlus, null, tint = Blue, modifier = Modifier.size(21.dp))
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    "Create",
                    color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium,
                    lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (mine != null) {
            item(key = "me") {
                Column(
                    modifier = Modifier.width(65.dp).clickable { onOpen(mine) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(47.dp).storyRing(unseen = mine.id !in seen)) {
                        UserAvatar(userPhoto, userName, 47.dp)
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "Your Story",
                        color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium,
                        lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        items(stories, key = { it.id }) { s ->
            Column(
                modifier = Modifier.width(65.dp).clickable { onOpen(s) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(47.dp).storyRing(unseen = s.id !in seen)) {
                    val res = s.avatarRes
                    if (res != null) Avatar(res, 47.dp) else UserAvatar(s.avatarUrl, s.name, 47.dp)
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    s.name,
                    color = Ink, fontSize = 10.2.sp, fontWeight = FontWeight.Medium,
                    lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ---------------------------------------------------------------- full-screen viewer

private val GlassFill = Color(0x59000000)
private val GlassLine = Color(0x40FFFFFF)

@Composable
private fun SmileyIcon(iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val s = this.size.minDimension
        val sw = s * 0.075f
        drawCircle(Color.White, radius = s * 0.44f, style = Stroke(sw))
        drawCircle(Color.White, radius = s * 0.055f, center = Offset(s * 0.36f, s * 0.42f))
        drawCircle(Color.White, radius = s * 0.055f, center = Offset(s * 0.64f, s * 0.42f))
        drawArc(
            Color.White,
            startAngle = 25f,
            sweepAngle = 130f,
            useCenter = false,
            topLeft = Offset(s * 0.28f, s * 0.28f),
            size = Size(s * 0.44f, s * 0.44f),
            style = Stroke(sw, cap = StrokeCap.Round)
        )
    }
}

@Composable
private fun PlaneIcon(iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val w = this.size.width
        val h = this.size.height
        val p = Path().apply {
            moveTo(w * 0.06f, h * 0.08f)
            lineTo(w * 0.96f, h * 0.5f)
            lineTo(w * 0.06f, h * 0.92f)
            lineTo(w * 0.26f, h * 0.5f)
            close()
        }
        drawPath(p, Color.White)
    }
}

@Composable
private fun ThinClose(iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val s = this.size.minDimension
        val sw = s * 0.09f
        drawLine(Color.White, Offset(s * 0.15f, s * 0.15f), Offset(s * 0.85f, s * 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(Color.White, Offset(s * 0.85f, s * 0.15f), Offset(s * 0.15f, s * 0.85f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

/** Glass-look chip showing one comment: small avatar, who wrote it, and what they said. */
@Composable
private fun StoryCommentChip(name: String, text: String, avatarRes: Int?, avatarUrl: String?) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier
            .clip(shape)
            .background(GlassFill)
            .border(1.dp, GlassLine, shape)
            .padding(start = 6.dp, end = 14.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(26.dp).border(1.dp, Color(0x99FFFFFF), CircleShape).padding(2.dp)) {
            if (avatarRes != null) Avatar(avatarRes, 22.dp) else UserAvatar(avatarUrl, name, 22.dp)
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Text(name, color = Color(0xCCFFFFFF), fontSize = 9.5.sp, lineHeight = 11.sp, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text, color = Color.White, fontSize = 14.sp, lineHeight = 17.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(4.dp))
                Text("♥", color = Color(0xFFFF4D79), fontSize = 12.sp)
            }
        }
    }
}

/** Glass-look chip with the song name and a little moving equaliser. */
@Composable
private fun StoryMusicChip(label: String) {
    val shape = RoundedCornerShape(20.dp)
    val inf = rememberInfiniteTransition(label = "equaliser")
    val b1 by inf.animateFloat(0.35f, 1f, infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse), label = "b1")
    val b2 by inf.animateFloat(1f, 0.3f, infiniteRepeatable(tween(430, easing = LinearEasing), RepeatMode.Reverse), label = "b2")
    val b3 by inf.animateFloat(0.5f, 0.95f, infiniteRepeatable(tween(610, easing = LinearEasing), RepeatMode.Reverse), label = "b3")
    Row(
        Modifier
            .clip(shape)
            .background(GlassFill)
            .border(1.dp, GlassLine, shape)
            .padding(start = 11.dp, end = 13.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("♫", color = Color.White, fontSize = 18.sp, lineHeight = 20.sp)
        Spacer(Modifier.width(8.dp))
        Text(
            label, color = Color.White, fontSize = 12.5.sp, lineHeight = 16.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Spacer(Modifier.width(12.dp))
        Canvas(Modifier.size(width = 15.dp, height = 13.dp)) {
            val bar = this.size.width / 5f
            listOf(b1, b2, b3).forEachIndexed { i, f ->
                val barH = this.size.height * f
                drawRoundRect(
                    Color.White,
                    topLeft = Offset(i * 2f * bar, this.size.height - barH),
                    size = Size(bar, barH),
                    cornerRadius = CornerRadius(bar / 2f)
                )
            }
        }
    }
}

/** Comment box (smiley, text, gradient send button) in the glass look. */
@Composable
private fun StoryCommentField(
    text: String,
    onText: (String) -> Unit,
    onFocus: (Boolean) -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(21.dp)
    Row(
        modifier
            .height(42.dp)
            .clip(shape)
            .background(GlassFill)
            .border(1.dp, GlassLine, shape)
            .padding(start = 10.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(28.dp).clickable { onText(text + "😊") },
            contentAlignment = Alignment.Center
        ) { SmileyIcon(24.dp) }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (text.isEmpty()) {
                Text("Comment something...", color = Color(0xB3FFFFFF), fontSize = 14.sp, maxLines = 1)
            }
            BasicTextField(
                value = text,
                onValueChange = { if (it.length <= 120) onText(it) },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                modifier = Modifier.fillMaxWidth().onFocusChanged { onFocus(it.isFocused) }
            )
        }
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFFFF3D81), Color(0xFFFF9A44))))
                .clickable(onClick = onSend),
            contentAlignment = Alignment.Center
        ) { PlaneIcon(17.dp) }
    }
}

/** Heart with the like count under it, glass look. */
@Composable
private fun StoryLikeButton(liked: Boolean, count: Int, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .size(width = 50.dp, height = 48.dp)
            .clip(shape)
            .background(GlassFill)
            .border(1.dp, GlassLine, shape)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        PopIcon(
            if (liked) IHeartFill else IHeart,
            if (liked) Color(0xFFFF3B5C) else Color.White,
            22.dp,
            liked
        )
        Text(
            formatCount(count.toLong()),
            color = Color.White, fontSize = 10.5.sp, lineHeight = 12.sp, fontWeight = FontWeight.SemiBold
        )
    }
}

/**
 * Tap right = next page, tap left = previous, press and hold = pause, swipe down = close.
 * Pauses while you type a comment or have the menu open. Runs through every story in [stories] from [startIndex].
 * Comments and likes only live on this phone for now (stories are still a demo).
 */
@Composable
fun StoryViewer(
    stories: List<Story>,
    startIndex: Int,
    viewerName: String,
    viewerPhoto: String?,
    onSeen: (Story) -> Unit,
    onDelete: (storyId: String, itemIndex: Int) -> Unit,
    onMute: (storyId: String) -> Unit,
    onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val onCloseNow by rememberUpdatedState(onClose)
    val onSeenNow by rememberUpdatedState(onSeen)
    val onDeleteNow by rememberUpdatedState(onDelete)
    val onMuteNow by rememberUpdatedState(onMute)

    var userIdx by remember { mutableIntStateOf(startIndex.coerceIn(0, stories.lastIndex)) }
    var itemIdx by remember { mutableIntStateOf(0) }
    var restart by remember { mutableIntStateOf(0) }
    var holding by remember { mutableStateOf(false) }
    var typing by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var closing by remember { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var draft by remember { mutableStateOf("") }
    val sent = remember { mutableStateMapOf<String, String>() }
    val liked = remember { mutableStateMapOf<String, Boolean>() }
    val appear = remember { Animatable(0f) }
    val paused = holding || typing || menuOpen

    fun close(after: (() -> Unit)? = null) {
        if (closing) return
        closing = true
        scope.launch {
            appear.animateTo(0f, tween(180))
            after?.invoke()
            onCloseNow()
        }
    }

    fun next() {
        val cur = stories[userIdx]
        if (itemIdx < cur.items.lastIndex) {
            itemIdx++
        } else if (userIdx < stories.lastIndex) {
            userIdx++
            itemIdx = 0
        } else {
            close()
        }
    }

    fun prev() {
        if (itemIdx > 0) {
            itemIdx--
        } else if (userIdx > 0) {
            userIdx--
            itemIdx = 0
        } else {
            restart++
        }
    }

    fun sendComment() {
        val t = draft.trim()
        if (t.isNotEmpty()) {
            sent["$userIdx:$itemIdx"] = t
            draft = ""
        }
        focus.clearFocus()
    }

    val story = stories[userIdx]
    val item = story.items[itemIdx.coerceIn(0, story.items.lastIndex)]
    val key = "$userIdx:$itemIdx"

    BackHandler { if (typing) focus.clearFocus() else close() }

    // status-bar icons turn white while the dark viewer is open
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = view.context.findActivity()?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, view) }
        val before = ctrl?.isAppearanceLightStatusBars ?: true
        ctrl?.isAppearanceLightStatusBars = false
        onDispose { ctrl?.isAppearanceLightStatusBars = before }
    }

    LaunchedEffect(Unit) { appear.animateTo(1f, tween(220)) }
    LaunchedEffect(userIdx) { onSeenNow(stories[userIdx]) }

    // a fresh progress value for every page; pausing keeps the value, resuming continues from it
    val progress = remember(userIdx, itemIdx, restart) { Animatable(0f) }
    LaunchedEffect(userIdx, itemIdx, restart, paused, closing) {
        if (!paused && !closing) {
            val left = ((1f - progress.value) * STORY_PAGE_MS).toInt().coerceAtLeast(1)
            progress.animateTo(1f, tween(left, easing = LinearEasing))
            next()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val a = appear.value
                alpha = a * (1f - (dragY / 1200f).coerceIn(0f, 0.6f))
                scaleX = 0.92f + 0.08f * a
                scaleY = 0.92f + 0.08f * a
                translationY = dragY.coerceAtLeast(0f)
            }
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        holding = true
                        tryAwaitRelease()
                        holding = false
                    },
                    onTap = { o ->
                        if (typing) focus.clearFocus()
                        else if (o.x < size.width / 3f) prev()
                        else next()
                    }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { holding = true },
                    onVerticalDrag = { change, dy ->
                        change.consume()
                        dragY += dy
                    },
                    onDragEnd = {
                        holding = false
                        if (dragY > 260f) close() else dragY = 0f
                    },
                    onDragCancel = {
                        holding = false
                        dragY = 0f
                    }
                )
            }
    ) {
        // ---- page content
        val bmp = rememberUriBitmap(item.imageUri?.let { Uri.parse(it) })
        val hasImage = item.imageRes != null || bmp != null
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(item.bgFrom), Color(item.bgTo))))
        ) {
            item.imageRes?.let {
                val painter = painterResource(it)
                val sz = painter.intrinsicSize
                val ratio = if (sz.width.isFinite() && sz.height.isFinite() && sz.height > 0f) sz.width / sz.height else 1f
                // portrait-ish pictures fill the whole screen, wide ones stay whole and centred
                if (ratio <= 0.8f) {
                    Image(painter, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    Image(
                        painter, null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().align(Alignment.Center)
                    )
                }
            }
            bmp?.let {
                val ratio = it.width.toFloat() / it.height.toFloat()
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = if (ratio <= 0.8f) ContentScale.Crop else ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            item.text?.let { t ->
                if (hasImage) {
                    Text(
                        t,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(horizontal = 24.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x66000000))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                } else {
                    Text(
                        t,
                        color = Color.White,
                        fontSize = 26.sp,
                        lineHeight = 36.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(horizontal = 30.dp)
                    )
                }
            }
        }

        // soft dark fades so the white controls always read
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(170.dp)
                .background(Brush.verticalGradient(listOf(Color(0x8C000000), Color.Transparent)))
        )
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(300.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xB3000000))))
        )

        // ---- progress bars + header
        Column(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                story.items.forEachIndexed { i, _ ->
                    val f = when {
                        i < itemIdx -> 1f
                        i == itemIdx -> progress.value
                        else -> 0f
                    }
                    Box(
                        Modifier
                            .weight(1f)
                            .height(2.5.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.White.copy(alpha = 0.35f))
                    ) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f.coerceIn(0f, 1f)).background(Color.White))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).border(1.5.dp, Color.White, CircleShape).padding(2.5.dp)) {
                    val res = story.avatarRes
                    if (res != null) Avatar(res, 37.dp) else UserAvatar(story.avatarUrl, story.name, 37.dp)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            story.name, color = Color.White, fontSize = 15.5.sp, lineHeight = 19.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (story.verified) {
                            Spacer(Modifier.width(5.dp))
                            Icon(IVerified, null, tint = Color.Unspecified, modifier = Modifier.size(15.dp))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            relTime(System.currentTimeMillis() - item.minutesAgo * 60_000L) + " • Public",
                            color = Color(0xE6FFFFFF), fontSize = 12.5.sp, lineHeight = 15.sp, maxLines = 1
                        )
                        Spacer(Modifier.width(4.dp))
                        Icon(IGlobe, null, tint = Color(0xE6FFFFFF), modifier = Modifier.size(12.dp))
                    }
                }
                // three dots (menu)
                Box {
                    Box(
                        Modifier.size(38.dp).clickable { menuOpen = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(3.5.dp)) {
                            repeat(3) { Box(Modifier.size(4.5.dp).clip(CircleShape).background(Color.White)) }
                        }
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(if (story.mine) "Delete story" else "Hide this story") },
                            onClick = {
                                menuOpen = false
                                val sid = story.id
                                val idx = itemIdx
                                if (story.mine) close { onDeleteNow(sid, idx) } else close { onMuteNow(sid) }
                            }
                        )
                    }
                }
                Box(
                    Modifier.size(38.dp).clickable { close() },
                    contentAlignment = Alignment.Center
                ) { ThinClose(24.dp) }
            }
        }

        // ---- bottom: comment, song, comment box + like
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            val mine = sent[key]
            if (mine != null) {
                StoryCommentChip(viewerName, mine, null, viewerPhoto)
            } else if (item.commentText != null) {
                StoryCommentChip(item.commentName ?: "", item.commentText, item.commentAvatarRes, null)
            }
            item.music?.let { StoryMusicChip(it) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                StoryCommentField(
                    text = draft,
                    onText = { draft = it },
                    onFocus = { typing = it },
                    onSend = { sendComment() },
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(10.dp))
                val isLiked = liked[key] == true
                StoryLikeButton(isLiked, item.likes + (if (isLiked) 1 else 0)) { liked[key] = !isLiked }
            }
        }
    }
}

// ---------------------------------------------------------------- create a story

/** Write a text story on a gradient, or pick a photo (with an optional caption). Kept on this phone only for now. */
@Composable
fun StoryCreator(onClose: () -> Unit, onShare: (StoryItem) -> Unit) {
    var text by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var gradIdx by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) uri = it }
    val bmp = rememberUriBitmap(uri)
    val grad = StoryGradients[gradIdx]
    val canShare = text.isNotBlank() || uri != null

    BackHandler { onClose() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F8FE))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
            Text("New story", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (canShare) Blue else Color(0xFFC9D3E3))
                    .clickable(enabled = canShare) {
                        onShare(
                            StoryItem(
                                text = text.trim().ifBlank { null },
                                imageUri = uri?.toString(),
                                bgFrom = grad.first,
                                bgTo = grad.second,
                                minutesAgo = 0
                            )
                        )
                    }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) {
                Text("Share", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
        }

        // preview
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.verticalGradient(listOf(Color(grad.first), Color(grad.second))))
        ) {
            bmp?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            val hasImage = bmp != null
            Box(
                Modifier
                    .align(if (hasImage) Alignment.BottomCenter else Alignment.Center)
                    .padding(horizontal = 22.dp, vertical = if (hasImage) 18.dp else 0.dp)
            ) {
                if (text.isEmpty()) {
                    Text(
                        if (hasImage) "Write a caption..." else "Type something...",
                        color = Color(0xB3FFFFFF),
                        fontSize = if (hasImage) 16.sp else 26.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                BasicTextField(
                    value = text,
                    onValueChange = { if (it.length <= 160) text = it },
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = if (hasImage) 16.sp else 26.sp,
                        lineHeight = if (hasImage) 22.sp else 36.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    ),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // tools
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE1E9F5), RoundedCornerShape(12.dp))
                    .clickable { if (uri == null) picker.launch("image/*") else uri = null }
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            ) {
                Text(if (uri == null) "📷 Photo" else "✖ Remove photo", color = Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.width(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StoryGradients.forEachIndexed { i, g ->
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Brush.verticalGradient(listOf(Color(g.first), Color(g.second))))
                            .border(if (i == gradIdx) 2.dp else 0.dp, if (i == gradIdx) Blue else Color.Transparent, CircleShape)
                            .clickable { gradIdx = i }
                    )
                }
            }
        }
    }
}
