package com.junaid.social

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // The whole design is drawn on a 390dp-wide canvas and scaled to the real screen width
            val d = LocalDensity.current
            val w = LocalConfiguration.current.screenWidthDp
            val scale = w / 390f
            CompositionLocalProvider(LocalDensity provides Density(d.density * scale, 1f)) {
                ProvideTextStyle(TextStyle(fontFamily = OutfitFamily)) { SocialApp() }
            }
        }
    }
}

private fun toast(ctx: Context, msg: String) =
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SocialApp() {
    val ctx = LocalContext.current
    val posts = remember { mutableStateListOf<Post>().apply { addAll(samplePosts()) } }
    val stories = remember { sampleStories() }

    var filter by remember { mutableStateOf(FeedFilter.All) }
    var sortPopular by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var navIndex by remember { mutableStateOf(0) }
    var unread by remember { mutableStateOf(true) }

    var showCompose by remember { mutableStateOf(false) }
    var composeMode by remember { mutableStateOf("text") }
    var commentFor by remember { mutableStateOf<Long?>(null) }
    var showNotifs by remember { mutableStateOf(false) }
    var storyOpen by remember { mutableStateOf<Story?>(null) }

    fun update(id: Long, f: (Post) -> Post) {
        val i = posts.indexOfFirst { it.id == id }
        if (i >= 0) posts[i] = f(posts[i])
    }

    val actions = remember {
        PostActions(
            like = { id -> update(id) { it.copy(liked = !it.liked, likes = it.likes + if (it.liked) -1 else 1) } },
            comment = { id -> commentFor = id },
            share = { id ->
                val p = posts.firstOrNull { it.id == id }
                if (p != null) {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${p.author}: ${p.text}")
                    }
                    ctx.startActivity(Intent.createChooser(send, "Share"))
                    update(id) { it.copy(shares = it.shares + 1) }
                }
            },
            bookmark = { id ->
                update(id) { it.copy(bookmarked = !it.bookmarked) }
                val p = posts.firstOrNull { it.id == id }
                toast(ctx, if (p?.bookmarked == true) "সেভ করা হয়েছে" else "সেভ সরানো হয়েছে")
            },
            vote = { id, idx ->
                update(id) { p ->
                    val poll = p.poll ?: return@update p
                    if (poll.selected == idx) return@update p
                    val opts = poll.options.mapIndexed { i, o ->
                        when (i) {
                            idx -> o.copy(votes = o.votes + 1, fixedPct = null)
                            poll.selected -> o.copy(votes = (o.votes - 1).coerceAtLeast(0), fixedPct = null)
                            else -> o.copy(fixedPct = null)
                        }
                    }
                    p.copy(poll = poll.copy(options = opts, selected = idx))
                }
            },
            copy = { id ->
                val p = posts.firstOrNull { it.id == id }
                if (p != null) {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("post", p.text))
                    toast(ctx, "কপি হয়েছে")
                }
            },
            hide = { id -> update(id) { it.copy(hidden = true) }; toast(ctx, "পোস্ট লুকানো হয়েছে") },
            delete = { id -> posts.removeAll { it.id == id }; toast(ctx, "পোস্ট মুছে ফেলা হয়েছে") }
        )
    }

    val visible = posts
        .filter { !it.hidden }
        .filter {
            when (filter) {
                FeedFilter.All -> true
                FeedFilter.Following -> it.following
                FeedFilter.Text -> it.imageRes == null && it.imageUri == null && it.poll == null
                FeedFilter.Image -> it.imageRes != null || it.imageUri != null
                FeedFilter.Poll -> it.poll != null
            }
        }
        .filter {
            query.isBlank() || it.text.contains(query, true) || it.author.contains(query, true)
        }
        .let { l -> if (sortPopular) l.sortedByDescending { it.likes } else l.sortedByDescending { it.id.takeIf { id -> id > 4 } ?: (5 - it.id) } }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(0f to Color(0xFFE7F0FE), 0.3f to Color(0xFFF3F7FE), 1f to Color(0xFFFAFCFF)))
    ) {
        Column(Modifier.fillMaxSize()) {
            TopBar(
                searching = searching,
                query = query,
                unread = unread,
                onQuery = { query = it },
                onSearchToggle = { searching = !searching; if (!searching) query = "" },
                onBell = { showNotifs = true; unread = false },
                onProfile = { navIndex = 4; toast(ctx, "Profile") }
            )

            if (navIndex != 0) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(NavLabels[navIndex], fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                }
            } else {
                val listState = rememberLazyListState()
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = 70.dp)
                ) {
                    item {
                        Spacer(Modifier.height(19.dp))
                        StoriesRow(
                            stories,
                            onCreate = { composeMode = "image"; showCompose = true },
                            onStory = { storyOpen = it }
                        )
                    }
                    item {
                        Spacer(Modifier.height(18.dp))
                        ChipsRow(filter, sortPopular, { filter = it }, { sortPopular = it })
                        Spacer(Modifier.height(12.dp))
                    }
                    item {
                        Composer(
                            onText = { composeMode = "text"; showCompose = true },
                            onImage = { composeMode = "image"; showCompose = true },
                            onPoll = { composeMode = "poll"; showCompose = true }
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    items(visible, key = { it.id }) { p ->
                        PostCard(p, actions, Modifier.padding(start = 9.dp, end = 9.dp, bottom = 10.dp))
                    }
                    if (visible.isEmpty()) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                                Text("কোনো পোস্ট পাওয়া যায়নি", color = Grey)
                            }
                        }
                    }
                }
            }
            BottomNav(navIndex) { navIndex = it }
        }

        if (navIndex == 0) {
            Fab(
                onClick = { composeMode = "text"; showCompose = true },
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 11.dp, bottom = 62.dp)
            )
        }
    }

    // ---- create post dialog
    if (showCompose) {
        ComposeDialog(
            initialMode = composeMode,
            onDismiss = { showCompose = false },
            onPost = { text, uri, pollOptions ->
                val nid = (posts.maxOfOrNull { it.id } ?: 0) + 1
                posts.add(
                    0,
                    Post(
                        id = nid,
                        author = "Rakib Hasan",
                        avatarRes = R.drawable.a_rakib,
                        time = "Just now",
                        text = text,
                        imageUri = uri,
                        poll = if (pollOptions.size >= 2)
                            Poll(pollOptions.map { PollOption(it, 0) }, -1, 3) else null,
                        verified = true,
                        mine = true
                    )
                )
                showCompose = false
                toast(ctx, "পোস্ট করা হয়েছে")
            }
        )
    }

    // ---- comments sheet
    val cid = commentFor
    if (cid != null) {
        val post = posts.firstOrNull { it.id == cid }
        if (post != null) {
            ModalBottomSheet(onDismissRequest = { commentFor = null }, containerColor = Color.White) {
                var text by remember { mutableStateOf("") }
                Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                    Text("Comments (${post.commentCount})", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(10.dp))
                    Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                        if (post.comments.isEmpty()) Text("এখনো কোনো মন্তব্য নেই", color = Grey, fontSize = 13.sp)
                        post.comments.forEach { c ->
                            Column(Modifier.padding(vertical = 6.dp)) {
                                Text(c.author, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Ink)
                                Text(c.text, fontSize = 14.sp, color = Ink)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFFF3F6FA))
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (text.isEmpty()) Text("মন্তব্য লিখুন...", color = Grey, fontSize = 14.sp)
                            BasicTextField(
                                value = text,
                                onValueChange = { text = it },
                                textStyle = TextStyle(color = Ink, fontSize = 14.sp),
                                cursorBrush = SolidColor(Blue),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        TextButton(onClick = {
                            if (text.isNotBlank()) {
                                update(cid) {
                                    it.copy(
                                        comments = it.comments + Comment("Rakib Hasan", text.trim()),
                                        commentCount = it.commentCount + 1
                                    )
                                }
                                text = ""
                            }
                        }) { Text("Send", color = Blue, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }

    // ---- notifications
    if (showNotifs) {
        AlertDialog(
            onDismissRequest = { showNotifs = false },
            confirmButton = { TextButton({ showNotifs = false }) { Text("Close") } },
            title = { Text("Notifications") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Sadia Islam আপনার পোস্টে মন্তব্য করেছেন")
                    Text("Md. Arif আপনার পোস্ট পছন্দ করেছেন")
                    Text("Tania Akter একটি নতুন পোল শেয়ার করেছেন")
                }
            }
        )
    }

    // ---- story viewer
    val st = storyOpen
    if (st != null) {
        AlertDialog(
            onDismissRequest = { storyOpen = null },
            confirmButton = { TextButton({ storyOpen = null }) { Text("Close") } },
            title = { Text(st.name) },
            text = {
                androidx.compose.foundation.Image(
                    painter = painterResource(st.avatarRes),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                )
            }
        )
    }
}

@Composable
fun ComposeDialog(
    initialMode: String,
    onDismiss: () -> Unit,
    onPost: (String, Uri?, List<String>) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var pollOn by remember { mutableStateOf(initialMode == "poll") }
    val opts = remember { mutableStateListOf("", "") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri = it }
    val bmp = rememberUriBitmap(uri)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন পোস্ট") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 90.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF3F6FA))
                        .padding(12.dp)
                ) {
                    if (text.isEmpty()) Text("What's on your mind?", color = Grey, fontSize = 14.sp)
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        textStyle = TextStyle(color = Ink, fontSize = 15.sp),
                        cursorBrush = SolidColor(Blue),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (bmp != null) {
                    Spacer(Modifier.height(8.dp))
                    androidx.compose.foundation.Image(
                        bitmap = bmp,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().aspectRatio(773f / 303f).clip(RoundedCornerShape(10.dp))
                    )
                }
                if (pollOn) {
                    Spacer(Modifier.height(8.dp))
                    opts.forEachIndexed { i, v ->
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFF3F6FA))
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            if (v.isEmpty()) Text("অপশন ${i + 1}", color = Grey, fontSize = 13.sp)
                            BasicTextField(
                                value = v,
                                onValueChange = { opts[i] = it },
                                singleLine = true,
                                textStyle = TextStyle(color = Ink, fontSize = 14.sp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    if (opts.size < 5) {
                        TextButton({ opts.add("") }) { Text("+ অপশন যোগ করুন", color = Blue) }
                    }
                }
                Row {
                    TextButton({ picker.launch("image/*") }) { Text("📷 ছবি", color = Blue) }
                    TextButton({ pollOn = !pollOn }) { Text(if (pollOn) "✖ পোল বাদ" else "📊 পোল", color = Blue) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val o = if (pollOn) opts.filter { it.isNotBlank() } else emptyList()
                if (text.isNotBlank() || uri != null || o.size >= 2) onPost(text.trim(), uri, o)
            }) { Text("Post", color = Blue, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = Grey) } }
    )
}
