package com.junaid.social

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.runtime.key
import androidx.compose.foundation.horizontalScroll
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // The whole design is drawn on a 390dp-wide canvas and scaled to the real screen width
            val d = LocalDensity.current
            val w = LocalConfiguration.current.screenWidthDp
            val scale = w / 390f
            CompositionLocalProvider(
                LocalDensity provides Density(d.density * scale, 1f),
                LocalIndication provides NoIndication
            ) {
                ProvideTextStyle(TextStyle(fontFamily = OutfitFamily)) { AuthGate() }
            }
        }
    }
}

private fun toast(ctx: Context, msg: String) =
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SocialApp(user: User, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val stories = remember { sampleStories() }
    // DEMO: the signed-in user's own stories live only on this phone until stories go online
    val myStoryItems = remember { mutableStateListOf<StoryItem>() }
    val seenStories = remember { mutableStateListOf<String>() }
    var viewerStart by remember { mutableStateOf<Int?>(null) }
    var showStoryCreator by remember { mutableStateOf(false) }
    val myStory = if (myStoryItems.isEmpty()) null
    else Story(id = "me", name = "Your Story", avatarUrl = user.photo, items = myStoryItems.toList(), mine = true)
    val viewerList = listOfNotNull(myStory) + stories

    // ---- live data from Firebase
    var docs by remember { mutableStateOf<List<PostDoc>>(emptyList()) }
    var me by remember { mutableStateOf(MeState()) }
    var loaded by remember { mutableStateOf(false) }
    var feedError by remember { mutableStateOf<String?>(null) }
    DisposableEffect(user.uid) {
        Repo.ensureUser(user)
        val r1 = Repo.listenPosts(
            onData = { docs = it; loaded = true; feedError = null },
            onErr = { feedError = it; loaded = true }
        )
        val r2 = Repo.listenMe(user.uid) { me = it }
        onDispose { r1.remove(); r2.remove() }
    }
    val posts = remember(docs, me) { Repo.buildPosts(docs, me, user.uid) }

    // TEST ONLY (DEBUG_TOOLS): fake name / time / verified badge, kept on this phone only
    val debugOv = remember { mutableStateMapOf<String, DebugOv>() }
    var debugNameFor by remember { mutableStateOf<String?>(null) }
    var debugTimeFor by remember { mutableStateOf<String?>(null) }
    val shown = posts.map { p ->
        val o = debugOv[p.id]
        if (o == null) p else p.copy(
            author = o.name ?: p.author,
            createdAt = o.createdAt ?: p.createdAt,
            verified = o.verified ?: p.verified
        )
    }

    var filter by remember { mutableStateOf(FeedFilter.All) }
    var sortPopular by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var navIndex by remember { mutableStateOf(0) }
    val listState = rememberLazyListState()
    var unread by remember { mutableStateOf(false) }

    var showCompose by remember { mutableStateOf(false) }
    var composeMode by remember { mutableStateOf("text") }
    var fabOpen by remember { mutableStateOf(false) }
    var gallery by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }
    BackHandler(enabled = fabOpen) { fabOpen = false }
    var commentFor by remember { mutableStateOf<String?>(null) }
    var showNotifs by remember { mutableStateOf(false) }

    val onErr = { m: String -> toast(ctx, if (m.contains("PERMISSION", true)) "অনুমতি নেই" else "ব্যর্থ হয়েছে, ইন্টারনেট দেখুন") }

    val actions = PostActions(
        like = { id ->
            val p = posts.firstOrNull { it.id == id }
            if (p != null) Repo.toggleLike(user.uid, id, p.liked, onErr)
        },
        comment = { id -> commentFor = id },
        openImages = { list, i -> gallery = list to i },
        share = { id ->
            val p = posts.firstOrNull { it.id == id }
            if (p != null) {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "${p.author}: ${p.text}")
                }
                // the count goes up in ShareReceiver, only after an app was really picked
                val done = Intent(ctx, ShareReceiver::class.java).putExtra(ShareReceiver.EXTRA_POST_ID, id)
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val pi = PendingIntent.getBroadcast(ctx, id.hashCode(), done, flags)
                ctx.startActivity(Intent.createChooser(send, "Share", pi.intentSender))
            }
        },
        bookmark = { id ->
            val p = posts.firstOrNull { it.id == id }
            if (p != null) {
                Repo.toggleBookmark(user.uid, id, p.bookmarked)
                toast(ctx, if (!p.bookmarked) "সেভ করা হয়েছে" else "সেভ সরানো হয়েছে")
            }
        },
        vote = { id, idx -> Repo.vote(user.uid, id, idx, onErr) },
        copy = { id ->
            val p = posts.firstOrNull { it.id == id }
            if (p != null) {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("post", p.text))
                toast(ctx, "কপি হয়েছে")
            }
        },
        hide = { id -> Repo.hide(user.uid, id); toast(ctx, "পোস্ট লুকানো হয়েছে") },
        delete = { id -> Repo.delete(id, onErr); toast(ctx, "পোস্ট মুছে ফেলা হয়েছে") },
        debugName = { id -> debugNameFor = id },
        debugTime = { id -> debugTimeFor = id },
        debugVerified = { id ->
            val p = shown.firstOrNull { it.id == id }
            if (p != null) debugOv[id] = (debugOv[id] ?: DebugOv()).copy(verified = !p.verified)
        },
        follow = { id ->
            val p = posts.firstOrNull { it.id == id }
            if (p != null) {
                Repo.toggleFollow(user.uid, p.authorUid, p.following)
                toast(ctx, if (!p.following) "ফলো করা হয়েছে" else "আনফলো করা হয়েছে")
            }
        }
    )

    val visible = shown
        .filter { it.id !in me.hidden }
        .filter {
            when (filter) {
                FeedFilter.All -> true
                FeedFilter.Following -> it.following || it.mine
                FeedFilter.Text -> it.pictures.isEmpty() && it.imageUrl == null && it.poll == null
                FeedFilter.Image -> it.pictures.isNotEmpty() || it.imageUrl != null
                FeedFilter.Poll -> it.poll != null
            }
        }
        .filter {
            query.isBlank() || it.text.contains(query, true) || it.author.contains(query, true)
        }
        .let { l -> if (sortPopular) l.sortedByDescending { it.likes } else l }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0f to Color(0xFFE9F1FE),
                    0.2f to Color(0xFFEFF5FE),
                    0.4f to Color(0xFFF4F8FE),
                    0.6f to Color(0xFFF6F9FF),
                    0.8f to Color(0xFFF8FBFF),
                    1f to Color(0xFFFAFCFF)
                )
            )
    ) {
        Column(Modifier.fillMaxSize()) {
            TopBar(
                searching = searching,
                query = query,
                unread = unread,
                userName = user.name,
                userPhoto = user.photo,
                onQuery = { query = it },
                onSearchToggle = { searching = !searching; if (!searching) query = "" },
                onBell = { showNotifs = true; unread = false },
                onProfile = { navIndex = 4; toast(ctx, "Profile") }
            )

            Crossfade(
                targetState = navIndex,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                animationSpec = tween(300, easing = FastOutSlowInEasing),
                label = "page"
            ) { page ->
            if (page != 0) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (page == 4) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(user.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text(user.email, fontSize = 13.sp, color = Grey, modifier = Modifier.padding(top = 4.dp))
                            Spacer(Modifier.height(24.dp))
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFFF3F6FA))
                                    .clickable { onLogout() }
                                    .padding(horizontal = 22.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(ILogout, null, tint = Color(0xFFE5484D), modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(10.dp))
                                Text("Sign out", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE5484D))
                            }
                        }
                    } else {
                        Text(NavLabels[page], fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 70.dp)
                ) {
                    item {
                        Spacer(Modifier.height(19.dp))
                        StoriesRow(
                            stories = stories,
                            mine = myStory,
                            seen = seenStories,
                            userName = user.name,
                            userPhoto = user.photo,
                            onCreate = { showStoryCreator = true },
                            onOpen = { s -> viewerStart = viewerList.indexOfFirst { it.id == s.id }.coerceAtLeast(0) }
                        )
                    }
                    item {
                        Spacer(Modifier.height(18.dp))
                        ChipsRow(filter, sortPopular, { filter = it }, { sortPopular = it })
                        Spacer(Modifier.height(12.5.dp))
                    }
                    item {
                        Composer(
                            userName = user.name,
                            userPhoto = user.photo,
                            onText = { composeMode = "text"; showCompose = true },
                            onImage = { composeMode = "image"; showCompose = true },
                            onPoll = { composeMode = "poll"; showCompose = true }
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    items(visible, key = { it.id }, contentType = { "post" }) { p ->
                        PostCard(p, actions, Modifier.padding(start = 9.dp, end = 9.dp, bottom = 10.dp))
                    }
                    if (visible.isEmpty()) {
                        item {
                            Box(
                                Modifier.fillMaxWidth().fillParentMaxHeight(0.64f),
                                contentAlignment = Alignment.Center
                            ) {
                                when {
                                    !loaded -> Text("Loading...", color = Grey)
                                    feedError != null -> Text(
                                        "Couldn't load the feed. Check your internet and Firestore rules.",
                                        color = Grey,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 40.dp)
                                    )
                                    else -> EmptyFeedState(Modifier.padding(top = 56.dp))
                                }
                            }
                        }
                    }
                }
            }
            }
            BottomNav(navIndex) { navIndex = it; fabOpen = false }
        }

        // soft dim behind the + menu; tapping it closes the menu
        AnimatedVisibility(
            visible = fabOpen && navIndex == 0,
            enter = fadeIn(tween(240)),
            exit = fadeOut(tween(220))
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x330B1B33))
                    .clickable { fabOpen = false }
            )
        }

        AnimatedVisibility(
            visible = navIndex == 0,
            enter = fadeIn(tween(200)) + scaleIn(tween(250), initialScale = 0.6f),
            exit = fadeOut(tween(150)) + scaleOut(tween(180), targetScale = 0.6f),
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 11.dp, bottom = 58.dp)
        ) {
            FabMenu(
                open = fabOpen,
                onToggle = { fabOpen = !fabOpen },
                onPick = { mode ->
                    fabOpen = false
                    composeMode = mode
                    showCompose = true
                }
            )
        }

        // ---- story viewer / story creator (full screen, above everything)
        val vs = viewerStart
        if (vs != null && viewerList.isNotEmpty()) {
            StoryViewer(
                stories = viewerList,
                startIndex = vs,
                onSeen = { s -> if (s.id !in seenStories) seenStories.add(s.id) },
                onClose = { viewerStart = null }
            )
        }
        val gal = gallery
        if (gal != null) {
            ImageGalleryViewer(images = gal.first, startIndex = gal.second, onClose = { gallery = null })
        }
        if (showStoryCreator) {
            StoryCreator(
                onClose = { showStoryCreator = false },
                onShare = { item ->
                    myStoryItems.add(item)
                    seenStories.remove("me")
                    showStoryCreator = false
                    toast(ctx, "Story added")
                }
            )
        }
    }

    // ---- create post dialog
    if (showCompose) {
        ComposeDialog(
            initialMode = composeMode,
            onDismiss = { showCompose = false },
            onPost = { text, uris, pollOptions ->
                showCompose = false
                toast(ctx, "পোস্ট করা হচ্ছে...")
                scope.launch {
                    // all pictures must fit in one 1 MB document: the more pictures, the smaller each one
                    val n = uris.size
                    val perPicture = if (n == 0) 600_000 else minOf(600_000, 660_000 / n)
                    val side = when {
                        n <= 1 -> 1080
                        n <= 3 -> 960
                        n <= 6 -> 800
                        else -> 640
                    }
                    val packed = withContext(Dispatchers.IO) {
                        uris.map { u ->
                            try { compressImage(ctx, u, perPicture, side) } catch (e: Exception) { null }
                        }
                    }
                    if (packed.any { it == null }) {
                        toast(ctx, "ছবি লোড করা যায়নি")
                    } else {
                        val pics = packed.filterNotNull()
                        if (pics.sumOf { it.length } > 930_000) {
                            toast(ctx, "Photos are too large. Please pick fewer.")
                        } else {
                            Repo.createPost(
                                user, me.verified, text, pics, pollOptions,
                                onOk = { toast(ctx, "পোস্ট করা হয়েছে") },
                                onErr = { onErr(it) }
                            )
                        }
                    }
                }
            }
        )
    }

    // ---- comments sheet
    val cid = commentFor
    if (cid != null) {
        val post = posts.firstOrNull { it.id == cid }
        if (post != null) {
            ModalBottomSheet(onDismissRequest = { commentFor = null }, containerColor = Color.White) {
                var text by remember { mutableStateOf("") }
                var comments by remember { mutableStateOf<List<Comment>>(emptyList()) }
                DisposableEffect(cid) {
                    val reg = Repo.listenComments(cid) { comments = it }
                    onDispose { reg.remove() }
                }
                Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
                    Text("Comments (${post.commentCount})", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(10.dp))
                    Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                        if (comments.isEmpty()) Text("এখনো কোনো মন্তব্য নেই", color = Grey, fontSize = 13.sp)
                        comments.forEach { c ->
                            Column(Modifier.padding(vertical = 6.dp)) {
                                Text(c.author, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Ink)
                                Text(c.text, fontSize = 14.sp, color = Ink)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFFF3F6FA))
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (text.isEmpty()) Text("মন্তব্য লিখুন...", color = Grey, fontSize = 14.sp)
                            BasicTextField(
                                value = text,
                                onValueChange = { text = it },
                                textStyle = TextStyle(color = Ink, fontSize = 14.sp),
                                cursorBrush = SolidColor(Blue),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        TextButton(onClick = {
                            if (text.isNotBlank()) {
                                Repo.addComment(user, cid, text.trim(), onErr)
                                text = ""
                            }
                        }) { Text("Send", color = Blue, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }

    // ---- TEST ONLY dialogs
    val dn = debugNameFor
    if (dn != null) {
        var nameText by remember(dn) { mutableStateOf(shown.firstOrNull { it.id == dn }?.author ?: "") }
        AlertDialog(
            onDismissRequest = { debugNameFor = null },
            confirmButton = {
                TextButton({
                    if (nameText.isNotBlank()) debugOv[dn] = (debugOv[dn] ?: DebugOv()).copy(name = nameText.trim())
                    debugNameFor = null
                }) { Text("OK", color = Blue, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton({ debugNameFor = null }) { Text("Cancel") } },
            title = { Text("[টেস্ট] পোস্টদাতার নাম") },
            text = { OutlinedTextField(value = nameText, onValueChange = { nameText = it }, singleLine = true) }
        )
    }
    val dt = debugTimeFor
    if (dt != null) {
        val opts = listOf(
            "Just now" to 0L, "5 min ago" to 5L * 60_000, "1 hour ago" to 3_600_000L,
            "2 hours ago" to 2L * 3_600_000, "5 hours ago" to 5L * 3_600_000,
            "1 day ago" to 24L * 3_600_000, "3 days ago" to 72L * 3_600_000
        )
        AlertDialog(
            onDismissRequest = { debugTimeFor = null },
            confirmButton = { TextButton({ debugTimeFor = null }) { Text("Close") } },
            title = { Text("[টেস্ট] পোস্টের সময়") },
            text = {
                Column {
                    opts.forEach { (label, ago) ->
                        Text(
                            label,
                            fontSize = 15.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    debugOv[dt] = (debugOv[dt] ?: DebugOv()).copy(createdAt = System.currentTimeMillis() - ago)
                                    debugTimeFor = null
                                }
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            }
        )
    }

    // ---- notifications
    if (showNotifs) {
        AlertDialog(
            onDismissRequest = { showNotifs = false },
            confirmButton = { TextButton({ showNotifs = false }) { Text("Close") } },
            title = { Text("Notifications") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("কোনো নতুন নোটিফিকেশন নেই")
                }
            }
        )
    }

}

@Composable
fun ComposeDialog(
    initialMode: String,
    onDismiss: () -> Unit,
    onPost: (String, List<Uri>, List<String>) -> Unit
) {
    var text by remember { mutableStateOf("") }
    val uris = remember { mutableStateListOf<Uri>() }
    var pollOn by remember { mutableStateOf(initialMode == "poll") }
    val opts = remember { mutableStateListOf("", "") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { picked ->
        for (u in picked) if (uris.size < MAX_POST_PHOTOS && u !in uris) uris.add(u)
    }
    val firstBmp = rememberUriBitmap(uris.firstOrNull())
    LaunchedEffect(Unit) { if (initialMode == "image") picker.launch("image/*") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন পোস্ট") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 90.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF3F6FA))
                        .padding(12.dp)
                ) {
                    if (text.isEmpty()) Text("What's on your mind?", color = Grey, fontSize = 14.sp)
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        textStyle = TextStyle(color = Ink, fontSize = 15.sp),
                        cursorBrush = SolidColor(Blue),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (uris.size == 1 && firstBmp != null) {
                    Spacer(Modifier.height(8.dp))
                    FramedPicture(firstBmp, corner = 10.dp)
                }
                if (uris.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        uris.toList().forEach { u -> key(u) { PickedThumb(u) { uris.remove(u) } } }
                    }
                    Text(
                        "${uris.size}/$MAX_POST_PHOTOS photos",
                        color = Grey, fontSize = 11.5.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                if (pollOn) {
                    Spacer(Modifier.height(8.dp))
                    opts.forEachIndexed { i, v ->
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFF3F6FA))
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            if (v.isEmpty()) Text("অপশন ${i + 1}", color = Grey, fontSize = 13.sp)
                            BasicTextField(
                                value = v,
                                onValueChange = { opts[i] = it },
                                singleLine = true,
                                textStyle = TextStyle(color = Ink, fontSize = 14.sp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    if (opts.size < 5) {
                        TextButton({ opts.add("") }) { Text("+ অপশন যোগ করুন", color = Blue) }
                    }
                }
                Row {
                    TextButton({ picker.launch("image/*") }) { Text("📷 ছবি", color = Blue) }
                    TextButton({ pollOn = !pollOn }) { Text(if (pollOn) "✖ পোল বাদ" else "📊 পোল", color = Blue) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val o = if (pollOn) opts.filter { it.isNotBlank() } else emptyList()
                if (text.isNotBlank() || uris.isNotEmpty() || o.size >= 2) onPost(text.trim(), uris.toList(), o)
            }) { Text("Post", color = Blue, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = Grey) } }
    )
}


@Composable
fun AuthGate() {
    val ctx = LocalContext.current
    val store = remember { AuthStore(ctx) }
    var user by remember { mutableStateOf(store.currentUser()) }
    val u = user
    if (u == null) {
        AuthScreen(store) { logged, keep ->
            store.setKeep(keep)
            user = logged
        }
    } else {
        SocialApp(u) {
            store.signOut()
            user = null
        }
    }
}

/** TEST ONLY: on-screen overrides for one post (not saved anywhere). */
data class DebugOv(val name: String? = null, val createdAt: Long? = null, val verified: Boolean? = null)
