GitHub থেকে APK বানানোর নিয়ম:
1) সব ফাইল/ফোল্ডার GitHub রিপোর মূল (root) জায়গায় তুলুন (app ফোল্ডার, settings.gradle.kts ইত্যাদি)।
2) .github/workflows/build.yml ফাইল না গেলে, build.yml.txt এর লেখা কপি করে
   GitHub এ "Add file > Create new file" দিয়ে নাম দিন: .github/workflows/build.yml
3) Actions ট্যাব > Build APK > Run workflow। শেষে Artifacts থেকে APK নামান।
