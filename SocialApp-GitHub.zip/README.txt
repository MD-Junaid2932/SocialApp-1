Social App - GitHub দিয়ে APK বানানো
1) এই zip টি সরাসরি GitHub রিপোতে আপলোড করুন (Add file > Upload files)।
2) Add file > Create new file: নাম  .github/workflows/build.yml
   ভেতরে build.yml.txt এর লেখা পেস্ট করে Commit করুন।
3) Actions > Build APK > Run workflow। শেষে Artifacts থেকে APK নামান।
